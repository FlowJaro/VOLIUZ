/**
 * VOLIUZ HUD - Popup Controller (popup.js)
 * Control de estado de la extensión y comunicación con la pestaña activa.
 */

document.addEventListener('DOMContentLoaded', async () => {
  let activeTab = null;
  const toggleExtension = document.getElementById('toggle-extension');
  const statusDot = document.getElementById('status-dot');
  const statusText = document.getElementById('status-text');
  const statusStoreName = document.getElementById('status-store-name');
  const statusDetail = document.getElementById('status-detail');

  const telemetryCard = document.getElementById('quick-telemetry-card');
  const quickTitle = document.getElementById('quick-prod-title');
  const quickCo2 = document.getElementById('quick-co2-val');
  const quickRec = document.getElementById('quick-rec-val');
  const quickSaving = document.getElementById('quick-saving-val');

  const btnToggleHud = document.getElementById('btn-toggle-hud');
  const btnReanalyze = document.getElementById('btn-reanalyze');

  const toggleAi = document.getElementById('toggle-ai');
  const inputAiKey = document.getElementById('input-ai-key');
  const btnSaveAiKey = document.getElementById('btn-save-ai-key');
  const aiConfigStatus = document.getElementById('ai-config-status');

  const btnTheme = document.getElementById('btn-theme');
  const btnCopySummary = document.getElementById('btn-copy-summary');
  const btnRefreshStatus = document.getElementById('btn-refresh-status');
  const toastElement = document.getElementById('popup-toast');

  let lastAnalysis = null;
  let toastTimer = null;

  /**
   * Muestra un aviso breve en la parte inferior del popup.
   */
  function showToast(message) {
    if (!toastElement) return;
    toastElement.textContent = message;
    toastElement.classList.add('show');
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      toastElement.classList.remove('show');
    }, 2400);
  }

  /**
   * Aplica el tema al documento y actualiza el botón del header.
   */
  function applyTheme(theme) {
    const isDark = theme === 'dark';
    document.documentElement.setAttribute(
      'data-theme',
      isDark ? 'dark' : 'light'
    );
    if (!btnTheme) return;
    const label = isDark ? 'Cambiar a modo claro' : 'Cambiar a modo oscuro';
    btnTheme.title = label;
    btnTheme.setAttribute('aria-label', label);
    btnTheme.setAttribute('aria-pressed', isDark ? 'true' : 'false');
  }

  // 1. Cargar estado maestro de storage
  chrome.storage.local.get(['extensionEnabled'], (result) => {
    if (chrome.runtime.lastError) {
      statusText.textContent = 'Estado no disponible';
      statusDetail.textContent = 'No se pudo leer la preferencia de la extensión.';
      return;
    }
    const isEnabled = result.extensionEnabled !== false;
    toggleExtension.checked = isEnabled;
    updateUIState(isEnabled);
  });

  // 1.1 Cargar tema guardado (claro por defecto).
  chrome.storage.local.get(['voliuzTheme'], (result) => {
    if (chrome.runtime.lastError) {
      applyTheme('light');
      return;
    }
    applyTheme(result.voliuzTheme === 'dark' ? 'dark' : 'light');
  });

  // 1.2 Alternar tema y sincronizarlo con el HUD de todas las pestañas.
  if (btnTheme) {
    btnTheme.addEventListener('click', () => {
      const nextTheme =
        document.documentElement.getAttribute('data-theme') === 'dark'
          ? 'light'
          : 'dark';
      applyTheme(nextTheme);
      chrome.storage.local.set({ voliuzTheme: nextTheme }, () => {
        if (chrome.runtime.lastError) {
          showToast('No se pudo guardar el tema');
          return;
        }
        showToast(
          nextTheme === 'dark'
            ? 'Modo oscuro activado'
            : 'Modo claro activado'
        );
      });
    });
  }

  // Mantiene el popup sincronizado si el tema cambia desde el HUD.
  if (chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName !== 'local' || !changes.voliuzTheme) return;
      applyTheme(changes.voliuzTheme.newValue === 'dark' ? 'dark' : 'light');
    });
  }

  // 2. Alternar estado maestro
  toggleExtension.addEventListener('change', () => {
    const isEnabled = toggleExtension.checked;
    chrome.storage.local.set({ extensionEnabled: isEnabled }, () => {
      if (chrome.runtime.lastError) {
        statusDetail.textContent = 'No se pudo guardar la preferencia de la extensión.';
      }
    });
    updateUIState(isEnabled);
    if (activeTab && activeTab.id) {
      chrome.tabs.sendMessage(activeTab.id, { action: 'setEnabled', enabled: isEnabled }, () => {
        if (chrome.runtime.lastError) {
          statusDetail.textContent = 'El cambio se guardó, pero la página debe recargarse para aplicar el panel.';
        }
      });
    }
  });

  // 2.1 Configuración de IA (Gemini)
  function updateAiStatus() {
    if (!chrome.runtime || typeof chrome.runtime.sendMessage !== 'function') return;
    chrome.runtime.sendMessage({ action: 'voliuz:getAiStatus' }, (response) => {
      if (chrome.runtime.lastError || !response || !response.success) {
        if (aiConfigStatus) {
          aiConfigStatus.textContent = 'Estado de IA: no disponible';
          aiConfigStatus.className = 'ai-config-status muted';
        }
        return;
      }
      if (!aiConfigStatus) return;

      if (!response.enabled) {
        aiConfigStatus.textContent = 'Estado de IA: desactivada';
        aiConfigStatus.className = 'ai-config-status muted';
      } else if (response.backend) {
        aiConfigStatus.textContent = `Estado de IA: backend (${response.model})`;
        aiConfigStatus.className = 'ai-config-status ok';
      } else if (response.configured) {
        aiConfigStatus.textContent = `Estado de IA: clave configurada (${response.model})`;
        aiConfigStatus.className = 'ai-config-status ok';
      } else {
        aiConfigStatus.textContent =
          'Estado de IA: sin clave ni backend. Pega la clave y pulsa Guardar.';
        aiConfigStatus.className = 'ai-config-status muted';
      }
    });
  }

  chrome.storage.local.get(
    ['voliuzAiEnabled', 'voliuzGeminiApiKey'],
    (result) => {
      if (chrome.runtime.lastError) {
        updateAiStatus();
        return;
      }
      if (toggleAi) toggleAi.checked = result.voliuzAiEnabled !== false;
      if (result.voliuzGeminiApiKey && inputAiKey) {
        inputAiKey.placeholder = 'Clave guardada (escribe para reemplazar)';
      }
      updateAiStatus();
    }
  );

  if (toggleAi) {
    toggleAi.addEventListener('change', () => {
      chrome.storage.local.set(
        { voliuzAiEnabled: toggleAi.checked },
        () => {
          void chrome.runtime.lastError;
          updateAiStatus();
        }
      );
    });
  }

  function saveAiKey() {
    const value = inputAiKey ? inputAiKey.value.trim() : '';
    chrome.storage.local.set({ voliuzGeminiApiKey: value }, () => {
      if (chrome.runtime.lastError) {
        if (aiConfigStatus) aiConfigStatus.textContent = 'No se pudo guardar la clave';
        showToast('No se pudo guardar la clave');
        return;
      }
      if (inputAiKey) {
        inputAiKey.value = '';
        inputAiKey.placeholder = value
          ? 'Clave guardada (escribe para reemplazar)'
          : 'Clave de Gemini (opcional)';
      }
      updateAiStatus();
      showToast(value ? 'Clave de Gemini guardada' : 'Clave de Gemini eliminada');
    });
  }

  if (btnSaveAiKey) {
    btnSaveAiKey.addEventListener('click', saveAiKey);
  }

  if (inputAiKey) {
    inputAiKey.addEventListener('keydown', (event) => {
      if (event.key !== 'Enter') return;
      event.preventDefault();
      saveAiKey();
    });
  }

  // 3. Obtener pestaña activa
  try {
    [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
  } catch (error) {
    statusDot.className = 'pulse-dot inactive';
    statusText.textContent = 'Sin pestaña activa';
    statusDetail.textContent = 'No se pudo acceder a la pestaña actual.';
  }

  // Re-evaluar con la pestaña ya resuelta (la lectura de storage es asíncrona).
  updateUIState(toggleExtension.checked);

  function isML(url = '') {
    return /^https:\/\/([a-z0-9-]+\.)?mercadolibre\.com\.co(\/|$)/i.test(
      String(url || '')
    );
  }

  function updateUIState(isEnabled) {
    lastAnalysis = null;

    if (!isEnabled) {
      statusDot.className = 'pulse-dot inactive';
      statusText.textContent = 'Extensión en pausa';
      statusDetail.textContent = 'Activa el interruptor superior para reanudar el análisis telemétrico.';
      telemetryCard.classList.add('hidden');
      return;
    }

    if (!activeTab || !activeTab.url) {
      statusDot.className = 'pulse-dot inactive';
      statusText.textContent = 'Sin pestaña activa';
      statusDetail.textContent = 'Abre Mercado Libre para comenzar a explorar huellas de carbono.';
      return;
    }

    if (isML(activeTab.url)) {
      statusDot.className = 'pulse-dot';
      statusText.textContent = 'Tienda vinculada';
      statusStoreName.textContent = 'Mercado Libre';
      statusDetail.textContent = 'Ficha de producto identificada. Telemetría lista en el lateral derecho.';

      // Consultar estado en tiempo real al content.js
      chrome.tabs.sendMessage(activeTab.id, { action: 'getStatus' }, (response) => {
        if (chrome.runtime.lastError || !response) {
          // El content script puede no haberse inyectado aún
          statusText.textContent = 'Sin ficha de producto';
          statusDetail.textContent = 'El panel no está disponible en esta página. Recárgala si acabas de instalar la extensión.';
          telemetryCard.classList.add('hidden');
          return;
        }

        if (response.hasAnalysis && response.impact) {
          lastAnalysis = response;
          telemetryCard.classList.remove('hidden');
          quickTitle.textContent = response.product?.title || 'Producto detectado';
          quickCo2.textContent = response.impact.available
            ? response.impact.dataBasis === 'ai_inferred'
              ? `~${response.impact.formattedCO2e || '—'}`
              : response.impact.formattedCO2e || '—'
            : '—';
          quickRec.textContent = response.impact.recyclability?.level || 'No disponible';
          quickSaving.textContent = response.alternative?.comparisonAvailable
            ? `-${response.alternative.reductionPercent}%`
            : 'No disponible';

          if (response.impact.available) {
            statusDetail.textContent =
              response.impact.dataBasis === 'ai_inferred'
                ? 'Estimación parcial: composición inferida por IA. Revisa el HUD para ver incertidumbre y limitaciones.'
                : 'Estimación preliminar disponible. Revisa el HUD para ver supuestos y limitaciones.';
          } else {
            statusDetail.textContent =
              response.impact.reason ||
              'Información insuficiente para estimar la huella.';
          }

          btnToggleHud.querySelector('span:last-child').textContent = response.isPanelOpen
            ? 'Ocultar Panel Lateral'
            : 'Abrir Panel Lateral (HUD)';
          return;
        }

        // Dominio correcto pero sin ficha de producto (portada, listado, etc.)
        statusText.textContent = 'Sin ficha de producto';
        statusDetail.textContent = 'Abre una publicación de Mercado Libre para activar la telemetría ambiental.';
        telemetryCard.classList.add('hidden');
      });

    } else {
      statusDot.className = 'pulse-dot inactive';
      statusText.textContent = 'Tienda no compatible';
      statusStoreName.textContent = 'Inactivo';
      statusDetail.textContent = 'Navega a un producto en mercadolibre.com.co para activar el cockpit telemétrico.';
      telemetryCard.classList.add('hidden');
    }
  }

  // 4. Botón Toggle HUD
  btnToggleHud.addEventListener('click', () => {
    if (!activeTab || !activeTab.id) return;
    chrome.tabs.sendMessage(activeTab.id, { action: 'toggleHUD' }, (res) => {
      if (chrome.runtime.lastError) {
        statusDetail.textContent = 'El panel no está disponible en esta página. Recárgala e inténtalo de nuevo.';
        return;
      }
      if (res && res.success) {
        btnToggleHud.querySelector('span:last-child').textContent = res.isPanelOpen
          ? 'Ocultar Panel Lateral'
          : 'Abrir Panel Lateral (HUD)';
      }
    });
  });

  // 5. Botón Re-analizar
  btnReanalyze.addEventListener('click', () => {
    if (!activeTab || !activeTab.id) return;
    chrome.tabs.sendMessage(activeTab.id, { action: 'reanalyze' }, () => {
      if (chrome.runtime.lastError) {
        statusDetail.textContent = 'No se pudo iniciar el análisis en esta página.';
        showToast('No se pudo iniciar el análisis');
        return;
      }
      showToast('Análisis solicitado');
      setTimeout(() => updateUIState(toggleExtension.checked), 400);
    });
  });

  // 6. Copiar un resumen legible del último análisis.
  function buildSummary() {
    if (!lastAnalysis || !lastAnalysis.impact) return '';
    const product = lastAnalysis.product || {};
    const impact = lastAnalysis.impact || {};
    const alternative = lastAnalysis.alternative || {};
    const inferred = impact.dataBasis === 'ai_inferred';
    const lines = [`VOLIUZ · ${product.title || 'Producto detectado'}`];

    if (impact.available) {
      const co2 = inferred
        ? `~${impact.formattedCO2e || '—'}`
        : impact.formattedCO2e || '—';
      lines.push(
        `Huella estimada: ${co2} (${inferred ? 'composición inferida por IA' : 'datos declarados'})`
      );
    } else {
      lines.push(
        `Huella: no disponible${impact.reason ? ` — ${impact.reason}` : ''}`
      );
    }

    if (impact.recyclability && impact.recyclability.level) {
      lines.push(`Reciclaje: ${impact.recyclability.level}`);
    }
    if (alternative.comparisonAvailable) {
      lines.push(`Alternativa: -${alternative.reductionPercent}% CO₂e`);
    }

    lines.push('Estimación preliminar; no es una certificación ambiental.');
    return lines.join('\n');
  }

  async function copySummary() {
    const text = buildSummary();
    if (!text) {
      showToast('Abre una ficha de producto para copiar el resumen');
      return;
    }
    try {
      await navigator.clipboard.writeText(text);
      showToast('Resumen copiado al portapapeles');
    } catch (error) {
      try {
        const area = document.createElement('textarea');
        area.value = text;
        area.setAttribute('readonly', '');
        area.style.position = 'fixed';
        area.style.opacity = '0';
        document.body.appendChild(area);
        area.select();
        document.execCommand('copy');
        area.remove();
        showToast('Resumen copiado al portapapeles');
      } catch (fallbackError) {
        showToast('No se pudo copiar el resumen');
      }
    }
  }

  if (btnCopySummary) {
    btnCopySummary.addEventListener('click', copySummary);
  }

  // 7. Actualizar manualmente el estado que muestra el popup.
  if (btnRefreshStatus) {
    btnRefreshStatus.addEventListener('click', () => {
      updateUIState(toggleExtension.checked);
      showToast('Estado actualizado');
    });
  }

});
