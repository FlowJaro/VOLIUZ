/**
 * VOLIUZ - Base de conocimiento ambiental (curada)
 *
 * Fuente: texto entregado por el equipo de VOLIUZ el 2026-11-13.
 *
 * Reglas de uso:
 *   - Este módulo es contexto cualitativo, NO un motor de cálculo.
 *   - Las cifras externas (litros de agua, porcentajes globales, etc.)
 *     describen tendencias de industria y no el producto analizado.
 *   - No reemplaza los factores de emisión de modules/co2Calculator.js.
 *   - No infiere la composición de un producto: esa tarea corresponde
 *     al flujo de IA y a los datos declarados por el vendedor.
 *   - Las referencias [1], [2] y [3] del texto original no incluyen
 *     bibliografía, por lo que las cifras quedan marcadas como no
 *     verificadas hasta que se agreguen las fuentes.
 *
 * Este archivo no está conectado todavía a la interfaz del chat.
 */

(function (root, factory) {
  if (typeof module === "object" && module.exports) {
    module.exports = factory();
  } else {
    root.VoliuzEnvironmentalKnowledge = factory();
  }
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";

  const VERSION = "1.0.0";
  const UPDATED_AT = "2026-11-13";

  /**
   * Taxonomía de materiales.
   * Cada grupo conserva ejemplos y usos habituales del texto original.
   */
  const MATERIAL_CATEGORIES = [
    {
      id: "natural",
      label: "Materiales de origen natural",
      description:
        "Provienen directamente de la naturaleza con procesos mínimos de transformación.",
      groups: [
        {
          id: "madera",
          label: "Madera y derivados",
          examples: ["roble", "pino", "MDF", "bambú", "corcho", "ratán"],
          commonUses: ["muebles", "decoración", "utensilios de cocina"]
        },
        {
          id: "fibras-naturales",
          label: "Fibras textiles naturales",
          examples: ["algodón", "lino", "lana", "seda", "cáñamo"],
          commonUses: ["prendas de vestir", "ropa de cama", "tapicería"]
        },
        {
          id: "piedra-ceramica-vidrio",
          label: "Piedra, cerámica y vidrio",
          examples: ["mármol", "granito", "porcelana", "arcilla", "barro", "cristal"],
          commonUses: ["menaje del hogar", "artículos decorativos", "construcción"]
        },
        {
          id: "cuero",
          label: "Cuero y pieles",
          examples: ["cuero genuino", "gamuza", "nobuk"],
          commonUses: ["calzado", "marroquinería", "accesorios", "mobiliario"]
        }
      ]
    },
    {
      id: "metalicos",
      label: "Materiales metálicos",
      description:
        "Se caracterizan por su durabilidad, conductividad y peso.",
      groups: [
        {
          id: "metales-ferrosos",
          label: "Metales ferrosos",
          examples: ["hierro forjado", "hierro fundido", "acero inoxidable"],
          commonUses: ["herramientas", "electrodomésticos", "baterías de cocina", "estructuras de muebles"]
        },
        {
          id: "metales-no-ferrosos",
          label: "Metales no ferrosos",
          examples: ["aluminio", "cobre", "latón", "bronce"],
          commonUses: ["electrónica", "ferretería ligera", "grifería", "artículos de diseño"]
        },
        {
          id: "metales-preciosos",
          label: "Metales preciosos",
          examples: ["oro", "plata", "platino"],
          commonUses: ["joyería", "relojería de alta gama"]
        }
      ]
    },
    {
      id: "sinteticos",
      label: "Materiales sintéticos y polímeros",
      description:
        "Fabricados mediante procesos químicos; populares por su bajo costo y versatilidad.",
      groups: [
        {
          id: "plasticos",
          label: "Plásticos rígidos y flexibles",
          examples: ["polipropileno (PP)", "policarbonato (PC)", "ABS", "PVC", "silicona"],
          commonUses: ["juguetes", "envases", "carcasas de tecnología", "accesorios de cocina"]
        },
        {
          id: "fibras-sinteticas",
          label: "Fibras textiles sintéticas",
          examples: ["poliéster", "nailon", "elastano (spandex)", "acrílico"],
          commonUses: ["ropa deportiva", "equipamiento para exteriores", "textiles económicos"]
        },
        {
          id: "cuero-sintetico",
          label: "Cuero sintético y resinas",
          examples: ["poliuretano (PU)", "polipiel", "resina epóxica"],
          commonUses: ["alternativas veganas en moda", "piezas decorativas moldeadas"]
        }
      ]
    },
    {
      id: "compuestos",
      label: "Materiales compuestos y técnicos",
      description:
        "Combinan dos o más materiales para lograr resistencia o ligereza.",
      groups: [
        {
          id: "fibras-tecnicas",
          label: "Fibra de carbono y fibra de vidrio",
          examples: ["fibra de carbono", "fibra de vidrio"],
          commonUses: ["artículos deportivos de alto rendimiento", "repuestos automotrices", "equipamiento industrial"]
        },
        {
          id: "papel-carton",
          label: "Papel, cartón y celulosa",
          examples: ["papel kraft", "cartón corrugado", "papel reciclado"],
          commonUses: ["papelería", "libros", "embalajes", "artículos desechables ecológicos"]
        }
      ]
    }
  ];

  /**
   * Métricas de ciclo de vida por dominio.
   *
   * usableForProductCalculation: false en todas. Son marcos de referencia,
   * no factores de emisión ni valores aplicables a un producto concreto.
   */
  const LIFECYCLE_METRICS = {
    textiles: {
      id: "textiles",
      label: "Productos textiles",
      description:
        "Indicadores para evaluar el impacto desde la extracción de la materia prima hasta el fin de vida de la prenda.",
      usableForProductCalculation: false,
      metrics: [
        {
          id: "huella-hidrica",
          label: "Huella hídrica",
          description:
            "Mide el agua dulce consumida en el cultivo de materias primas y en los procesos húmedos de fabricación.",
          indicators: [
            "Consumo de agua dulce en riego, hilatura, teñido, estampación y acabados.",
            "Calidad y contaminación del agua: DBO, DQO, metales pesados y residuos de tintes."
          ],
          externalReferences: [
            {
              statement:
                "Se estima que una camiseta de algodón requiere unos 2.000 litros de agua y unos jeans cerca de 7.500 litros.",
              sourceRefs: [1, 2],
              verified: false
            },
            {
              statement:
                "El procesamiento textil se asocia con cerca del 20% de la contaminación mundial del agua potable.",
              sourceRefs: [1, 2],
              verified: false
            }
          ]
        },
        {
          id: "huella-carbono",
          label: "Huella de carbono y cambio climático",
          description:
            "Emisiones de gases de efecto invernadero medidas en CO₂ equivalente a lo largo de la cadena de suministro.",
          indicators: [
            "Emisiones de GEI en toda la cadena de suministro."
          ],
          externalReferences: [
            {
              statement:
                "La industria textil generaría aproximadamente el 10% de las emisiones globales de carbono.",
              sourceRefs: [1, 2, 3],
              verified: false
            }
          ]
        },
        {
          id: "microplasticos",
          label: "Emisión de microplásticos",
          description:
            "Mide las microfibras sintéticas liberadas durante el uso y el lavado de prendas.",
          indicators: [
            "Liberación de microfibras de poliéster, nailon o acrílico."
          ],
          externalReferences: [
            {
              statement:
                "Una carga de ropa podría liberar entre 700.000 y 1.000.000 de microfibras.",
              sourceRefs: [1, 2],
              verified: false
            }
          ]
        },
        {
          id: "recursos",
          label: "Agotamiento de recursos y materias primas",
          description:
            "Evalúa la proporción de materiales vírgenes frente a reciclados y la ocupación de suelo.",
          indicators: [
            "Porcentaje de fibras renovables, orgánicas o recicladas frente a sintéticas vírgenes.",
            "Ocupación de suelo para cultivo de fibras naturales o extracción de recursos."
          ],
          externalReferences: [
            {
              statement:
                "Se estima que el 97% de los materiales textiles son vírgenes y solo un 2% reciclados.",
              sourceRefs: [1],
              verified: false
            }
          ]
        },
        {
          id: "residuos",
          label: "Generación y gestión de residuos",
          description:
            "Rastrea el aprovechamiento posindustrial y posconsumo de retales y prendas desechadas.",
          indicators: [
            "Tasa de reciclaje, reutilización, vertedero e incineración."
          ],
          externalReferences: [
            {
              statement:
                "Más del 70% de la ropa acabaría enterrada o quemada y menos del 1% se reciclaría en ropa nueva.",
              sourceRefs: [1, 2],
              verified: false
            }
          ]
        }
      ]
    },
    electronics: {
      id: "electronics",
      label: "Productos eléctricos o electrónicos",
      description:
        "Indicadores para evaluar el impacto desde la extracción de materias primas hasta el uso y el descarte.",
      usableForProductCalculation: false,
      metrics: [
        {
          id: "huella-carbono-alcances",
          label: "Huella de carbono (alcances 1, 2 y 3)",
          description:
            "Emisiones de GEI expresadas en toneladas de CO₂ equivalente, clasificadas por alcance.",
          indicators: [
            "Alcance 1: emisiones directas de instalaciones o vehículos propios.",
            "Alcance 2: emisiones indirectas por electricidad y energía adquiridas.",
            "Alcance 3: emisiones indirectas de la cadena de valor."
          ],
          externalReferences: [
            {
              statement:
                "En tecnología, entre el 70% y el 90% de las emisiones del alcance 3 suele originarse en la fabricación de componentes y en el uso del producto.",
              sourceRefs: [1, 2, 3],
              verified: false
            }
          ]
        },
        {
          id: "energia",
          label: "Consumo y eficiencia energética",
          description:
            "Cuantifica la energía consumida durante el funcionamiento del dispositivo o en centros de datos.",
          indicators: [
            "Consumo en kWh o gigajulios durante el uso.",
            "Eficiencia computacional, por ejemplo FLOPs por vatio en inteligencia artificial."
          ],
          externalReferences: []
        },
        {
          id: "residuos-circularidad",
          label: "Gestión de residuos y circularidad",
          description:
            "Evalúa materiales reciclables, reciclados y la generación de desechos electrónicos.",
          indicators: [
            "Porcentaje de materiales reciclables y reciclados.",
            "Generación de e-waste y adherencia a estándares como TCO Certified."
          ],
          externalReferences: []
        },
        {
          id: "agua",
          label: "Consumo y estrés hídrico",
          description:
            "Mide el agua usada directa e indirectamente en minería, semiconductores y refrigeración de infraestructura.",
          indicators: [
            "Litros o metros cúbicos de agua en extracción, fabricación y refrigeración."
          ],
          externalReferences: []
        },
        {
          id: "recursos-criticos",
          label: "Agotamiento de recursos y materiales críticos",
          description:
            "Rastrea minerales raros y recursos no renovables, su recuperación y toxicidad.",
          indicators: [
            "Uso de tierras raras, cobalto, oro o litio.",
            "Viabilidad de recuperación y toxicidad química asociada."
          ],
          externalReferences: []
        }
      ]
    }
  };

  /**
   * El texto original incluía el encabezado "PRODUCTOS SEGÚN SU MATERIAL"
   * sin contenido. No se inventa el mapeo: queda vacío hasta recibirlo.
   */
  const PRODUCT_MATERIAL_MAPPING = [];

  /**
   * Las referencias [1], [2] y [3] no tienen bibliografía en el texto.
   * No se deben citar como fuentes verificables hasta completarlas.
   */
  const SOURCES = [];

  const USAGE_POLICY = [
    "Usar esta base solo para explicar categorías, materiales e indicadores de ciclo de vida.",
    "No aplicar cifras generales de industria a un producto específico.",
    "No usar estas cifras para reemplazar los factores de emisión del motor de cálculo.",
    "Etiquetar cualquier cifra externa como contexto no verificado y sin fuente bibliográfica completa.",
    "No inferir la composición del producto a partir de esta base.",
    "Si faltan datos, indicarlo en lugar de completar con supuestos."
  ];

  const DOMAIN_KEYS = ["textiles", "electronics"];

  /**
   * Palabras clave para elegir el dominio de ciclo de vida más probable.
   * Son heurísticas de contexto, no una clasificación oficial del producto.
   */
  const DOMAIN_SIGNALS = {
    textiles: [
      "textil",
      "prenda",
      "ropa",
      "moda",
      "camiseta",
      "camisa",
      "blusa",
      "top",
      "pantalon",
      "jean",
      "vestido",
      "falda",
      "short",
      "chaqueta",
      "abrigo",
      "buzo",
      "hoodie",
      "sudadera",
      "sueter",
      "sweater",
      "medias",
      "pijama",
      "uniforme",
      "delantal",
      "sabana",
      "cobija",
      "manta",
      "cortina",
      "tapiceria",
      "mochila",
      "calzado",
      "zapatos",
      "zapatillas",
      "tenis",
      "botas",
      "algodon",
      "poliester",
      "nailon",
      "lino",
      "lana",
      "seda",
      "canamo",
      "spandex",
      "elastano",
      "acrilico"
    ],
    electronics: [
      "electronico",
      "electronica",
      "celular",
      "smartphone",
      "telefono",
      "laptop",
      "portatil",
      "computador",
      "computadora",
      "tablet",
      "audifonos",
      "auriculares",
      "parlante",
      "altavoz",
      "bocina",
      "televisor",
      "smart tv",
      "monitor",
      "teclado",
      "mouse",
      "camara",
      "consola",
      "videojuego",
      "cargador",
      "bateria",
      "power bank",
      "bluetooth",
      "usb",
      "hdmi",
      "nevera",
      "refrigerador",
      "lavadora",
      "microondas",
      "licuadora",
      "aspiradora",
      "ventilador",
      "aire acondicionado",
      "router",
      "modem",
      "smartwatch",
      "reloj inteligente",
      "drone",
      "impresora",
      "disco duro",
      "tarjeta grafica",
      "procesador"
    ]
  };

  function normalizeText(value) {
    return String(value ?? "")
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .trim();
  }

  /**
   * Busca un material por ejemplo, identificador o etiqueta de grupo.
   * Devuelve la categoría y el grupo encontrado, o null.
   */
  function findMaterialCategory(materialName) {
    const target = normalizeText(materialName);
    if (!target) return null;

    for (const category of MATERIAL_CATEGORIES) {
      for (const group of category.groups) {
        const matchesGroup =
          normalizeText(group.id) === target ||
          normalizeText(group.label) === target;
        const matchesExample = group.examples.some(
          (example) => normalizeText(example) === target
        );
        if (matchesGroup || matchesExample) {
          return { category, group };
        }
      }
    }

    return null;
  }

  function getLifecycleMetrics(domain) {
    const key = normalizeText(domain);
    const entry = LIFECYCLE_METRICS[key];
    return entry || null;
  }

  function normalizeDomainList(domains) {
    const list = Array.isArray(domains) ? domains : [domains];
    const keys = [];

    list.forEach((domain) => {
      const key = normalizeText(domain);
      if (LIFECYCLE_METRICS[key] && keys.indexOf(key) === -1) {
        keys.push(key);
      }
    });

    return keys.slice(0, 2);
  }

  /**
   * Elige el dominio de ciclo de vida más probable a partir de texto libre.
   * Devuelve null cuando no hay señales suficientes.
   */
  function detectDomain(text) {
    const source = normalizeText(text);
    if (!source) return null;

    let best = null;
    let bestScore = 0;

    DOMAIN_KEYS.forEach((key) => {
      const signals = DOMAIN_SIGNALS[key] || [];
      const score = signals.reduce((total, signal) => {
        if (!source.includes(signal)) return total;
        return total + 1 + signal.length / 20;
      }, 0);

      if (score > bestScore) {
        best = key;
        bestScore = score;
      }
    });

    return best;
  }

  /**
   * Contexto de chat: taxonomía una sola vez y métricas de uno o dos dominios.
   * No incluye mapeos producto-material ni cifras presentadas como datos del
   * producto analizado.
   */
  function buildChatContext(domains) {
    const keys = normalizeDomainList(domains);
    if (keys.length === 0) return "";

    const metrics = keys
      .map((key) => formatMetrics(key))
      .filter(Boolean)
      .join("\n\n");

    if (!metrics) return "";

    return [
      `BASE DE CONOCIMIENTO AMBIENTAL VOLIUZ (versión ${VERSION}, ${UPDATED_AT}).`,
      "",
      "POLÍTICA DE USO:",
      ...USAGE_POLICY.map((rule, index) => `${index + 1}. ${rule}`),
      "",
      "TAXONOMÍA DE MATERIALES (referencia única; no implica que el producto use estos materiales):",
      formatMaterialCatalog(),
      "",
      `MÉTRICAS DE CICLO DE VIDA (${keys
        .map((key) => LIFECYCLE_METRICS[key].label)
        .join(" · ")}):`,
      metrics
    ].join("\n");
  }

  function formatMaterialCatalog() {
    return MATERIAL_CATEGORIES.map((category) => {
      const groups = category.groups
        .map(
          (group) =>
            `- ${group.label}: ${group.examples.join(", ")}. Usos: ${group.commonUses.join(", ")}.`
        )
        .join("\n");
      return `${category.label}\n${category.description}\n${groups}`;
    }).join("\n\n");
  }

  function formatMetrics(domain) {
    const entry = getLifecycleMetrics(domain);
    if (!entry) return "";

    const metrics = entry.metrics
      .map((metric) => {
        const indicators = metric.indicators
          .map((indicator) => `  - ${indicator}`)
          .join("\n");
        const references =
          metric.externalReferences.length > 0
            ? metric.externalReferences
                .map(
                  (reference) =>
                    `  - Dato externo no verificado: ${reference.statement}`
                )
                .join("\n")
            : "  - Sin cifras externas asociadas.";

        return `${metric.label}\n${metric.description}\n${indicators}\n${references}`;
      })
      .join("\n\n");

    return `${entry.label}\n${entry.description}\n\n${metrics}`;
  }

  /**
   * Construye el contexto que se puede enviar a un modelo de lenguaje.
   * Incluye reglas explícitas para evitar que las cifras se usen como datos
   * del producto o como factores de emisión.
   */
  function buildPromptContext(domain) {
    const metrics = formatMetrics(domain);
    if (!metrics) return "";

    return [
      `BASE DE CONOCIMIENTO AMBIENTAL VOLIUZ (versión ${VERSION}, ${UPDATED_AT}).`,
      "",
      "POLÍTICA DE USO:",
      ...USAGE_POLICY.map((rule, index) => `${index + 1}. ${rule}`),
      "",
      "TAXONOMÍA DE MATERIALES:",
      formatMaterialCatalog(),
      "",
      "MÉTRICAS DE CICLO DE VIDA:",
      metrics
    ].join("\n");
  }

  return {
    VERSION,
    UPDATED_AT,
    MATERIAL_CATEGORIES,
    LIFECYCLE_METRICS,
    PRODUCT_MATERIAL_MAPPING,
    SOURCES,
    USAGE_POLICY,
    DOMAIN_KEYS,
    findMaterialCategory,
    getLifecycleMetrics,
    normalizeDomainList,
    detectDomain,
    buildPromptContext,
    buildChatContext
  };
});
