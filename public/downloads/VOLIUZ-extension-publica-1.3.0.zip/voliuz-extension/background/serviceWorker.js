/**
 * VOLIUZ - Background Service Worker (MV3)
 *
 * Responsabilidades:
 *   1. Inicializar preferencias con valores por defecto.
 *   2. Mostrar una insignia solo en pestañas de Mercado Libre Colombia.
 *   3. Responder consultas de estado de la extensión.
 *   4. Solicitar a Gemini una composición inferida cuando el content script
 *      la necesite, aplicando caché y deduplicación de solicitudes.
 *
 * La clave de API nunca se incluye en este archivo: se resuelve en tiempo de
 * ejecución desde chrome.storage.local o desde config/gemini.config.js
 * (generado por scripts/build-env.js a partir de .env y excluido de Git).
 */

'use strict';

const ML_URL_PATTERN =
  /^https:\/\/([a-z0-9-]+\.)?mercadolibre\.com\.co(\/|$)/i;

const BADGE_TEXT = 'CO₂';
const BADGE_BACKGROUND = '#063a6e';
const BADGE_TEXT_COLOR = '#bcf500';

const CACHE_TTL_MS = 24 * 60 * 60 * 1000;
const NEGATIVE_TTL_MS = 5 * 60 * 1000;
const MAX_CACHE_ENTRIES = 40;
const MAX_PRODUCT_TEXT = 4000;

// Chat: límites de entrada y ventana de rate limit por pestaña.
const MAX_CHAT_QUESTION = 500;
const MAX_CHAT_HISTORY_MESSAGES = 8;
const MAX_CHAT_TEXT = 14000;
const CHAT_RATE_LIMIT_MAX = 8;
const CHAT_RATE_WINDOW_MS = 60 * 1000;

function loadModules() {
  try {
    importScripts(chrome.runtime.getURL('modules/geminiClient.js'));
  } catch (error) {
    console.error('[VOLIUZ Background] No se pudo cargar el cliente de Gemini.');
  }

  try {
    importScripts(chrome.runtime.getURL('modules/environmentalKnowledge.js'));
  } catch (error) {
    console.error('[VOLIUZ Background] No se pudo cargar la base ambiental.');
  }

  try {
    importScripts(chrome.runtime.getURL('modules/backendClient.js'));
  } catch (error) {
    console.error('[VOLIUZ Background] No se pudo cargar el cliente del backend.');
  }

  try {
    importScripts(chrome.runtime.getURL('config/gemini.config.js'));
  } catch (error) {
    // Sin configuración generada: se usará la clave guardada desde el popup.
  }
}

loadModules();

function isMercadoLibreUrl(url = '') {
  return ML_URL_PATTERN.test(String(url || ''));
}

function initializeStorage() {
  chrome.storage.local.get(
    [
      'extensionEnabled',
      'autoOpenHUD',
      'targetStore',
      'installedAt',
      'voliuzAiEnabled'
    ],
    (stored) => {
      if (chrome.runtime.lastError) {
        console.warn('[VOLIUZ Background] No se pudieron leer las preferencias.');
        return;
      }

      chrome.storage.local.set(
        {
          extensionEnabled: stored.extensionEnabled !== false,
          autoOpenHUD: stored.autoOpenHUD !== false,
          targetStore: stored.targetStore || 'Mercado Libre Colombia',
          installedAt: stored.installedAt || Date.now(),
          voliuzAiEnabled: stored.voliuzAiEnabled !== false,
          version: chrome.runtime.getManifest().version
        },
        () => {
          if (chrome.runtime.lastError) {
            console.warn('[VOLIUZ Background] No se pudieron guardar las preferencias.');
          }
        }
      );
    }
  );
}

function ignoreClosedTab() {
  // Leer lastError evita advertencias cuando la pestaña ya se cerró.
  void chrome.runtime.lastError;
}

function updateBadge(tabId, url) {
  if (!Number.isInteger(tabId)) return;

  if (isMercadoLibreUrl(url)) {
    chrome.action.setBadgeText({ tabId, text: BADGE_TEXT }, ignoreClosedTab);
    chrome.action.setBadgeBackgroundColor(
      {
        tabId,
        color: BADGE_BACKGROUND
      },
      ignoreClosedTab
    );
    if (chrome.action.setBadgeTextColor) {
      chrome.action.setBadgeTextColor(
        { tabId, color: BADGE_TEXT_COLOR },
        ignoreClosedTab
      );
    }
    return;
  }

  chrome.action.setBadgeText({ tabId, text: '' }, ignoreClosedTab);
}

chrome.runtime.onInstalled.addListener(initializeStorage);
chrome.runtime.onStartup.addListener(initializeStorage);

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'complete') return;
  updateBadge(tabId, tab && tab.url);
});

chrome.tabs.onActivated.addListener(({ tabId }) => {
  chrome.tabs.get(tabId, (tab) => {
    if (chrome.runtime.lastError || !tab) return;
    updateBadge(tabId, tab.url);
  });
});

/* --------------------------------------------------------------------------
   Gemini: configuración, caché y deduplicación
   -------------------------------------------------------------------------- */

const memoryCache = new Map();
const inFlightRequests = new Map();

function getGeneratedConfig() {
  const config =
    typeof self !== 'undefined' && self.VOLIUZ_GEMINI_CONFIG
      ? self.VOLIUZ_GEMINI_CONFIG
      : {};
  return config && typeof config === 'object' ? config : {};
}

function readAiSettings(callback) {
  chrome.storage.local.get(
    [
      'voliuzGeminiApiKey',
      'voliuzGeminiModel',
      'voliuzAiEnabled',
      'voliuzGeminiUseImage',
      'voliuzBackendUrl'
    ],
    (stored) => {
      if (chrome.runtime.lastError) {
        stored = {};
      }
      const generated = getGeneratedConfig();
      const apiKey = String(
        stored.voliuzGeminiApiKey || generated.apiKey || ''
      ).trim();
      const model = String(
        stored.voliuzGeminiModel || generated.model || 'gemini-3.6-flash'
      ).trim();
      const enabled = stored.voliuzAiEnabled !== false;
      const useImage =
        stored.voliuzGeminiUseImage !== undefined
          ? stored.voliuzGeminiUseImage === true
          : generated.useImage === true;
      const backendUrl = self.VoliuzBackendClient
        ? self.VoliuzBackendClient.normalizeBaseUrl(
            stored.voliuzBackendUrl || generated.backendUrl || ''
          )
        : '';

      callback({
        apiKey,
        model,
        enabled,
        useImage,
        backendUrl,
        configured: Boolean(apiKey),
        available: Boolean(apiKey) || Boolean(backendUrl),
        mode: backendUrl ? 'backend' : 'direct'
      });
    }
  );
}

function cacheKey(signature) {
  return `voliuzAiCache:${signature}`;
}

function getMemoryEntry(signature) {
  const entry = memoryCache.get(signature);
  if (!entry) return null;
  if (Date.now() - entry.timestamp > entry.ttl) {
    memoryCache.delete(signature);
    return null;
  }
  return entry;
}

function rememberEntry(signature, entry) {
  memoryCache.set(signature, entry);
  if (memoryCache.size <= MAX_CACHE_ENTRIES) return;

  const oldest = Array.from(memoryCache.entries()).sort(
    (a, b) => a[1].timestamp - b[1].timestamp
  )[0];
  if (oldest) memoryCache.delete(oldest[0]);
}

function loadPersistentEntry(signature, callback) {
  chrome.storage.local.get([cacheKey(signature)], (stored) => {
    if (chrome.runtime.lastError) {
      callback(null);
      return;
    }
    const entry = stored[cacheKey(signature)];
    if (
      entry &&
      entry.data &&
      Date.now() - entry.timestamp <= CACHE_TTL_MS
    ) {
      rememberEntry(signature, {
        ...entry,
        ttl: CACHE_TTL_MS
      });
      callback(entry);
      return;
    }
    callback(null);
  });
}

function savePersistentEntry(signature, entry) {
  const payload = {};
  payload[cacheKey(signature)] = {
    data: entry.data,
    cached: true,
    timestamp: entry.timestamp
  };
  chrome.storage.local.set(payload, () => {
    void chrome.runtime.lastError;
  });
}

function sanitizeProductForPrompt(product = {}) {
  const text = (value, max) =>
    String(value == null ? '' : value)
      .replace(/<[^>]*>/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, max);

  return {
    url: text(product.url, 500),
    title: text(product.title, 220),
    category: text(product.category, 160),
    descriptionText: text(product.descriptionText, 3000),
    imageUrl: text(product.image, 700),
    features: Array.isArray(product.features)
      ? product.features.map((item) => text(item, 160)).slice(0, 25)
      : [],
    materialMentions: Array.isArray(product.materialMentions)
      ? product.materialMentions.map((item) => text(item, 60)).slice(0, 15)
      : [],
    materials: Array.isArray(product.materials)
      ? product.materials
          .filter((material) => material && material.name)
          .map((material) => ({
            name: text(material.name, 60),
            percentage:
              material.percentage == null ? null : Number(material.percentage)
          }))
          .slice(0, 12)
      : [],
    rawMaterials: text(product.rawMaterials, 800),
    currency: text(product.currency, 8)
  };
}

function isImageFetchable(url) {
  try {
    const parsed = new URL(String(url || ''));
    return (
      parsed.protocol === 'https:' &&
      (/(^|\.)mlstatic\.com$/i.test(parsed.hostname) ||
        /(^|\.)mercadolibre\.com\.co$/i.test(parsed.hostname))
    );
  } catch (error) {
    return false;
  }
}

function arrayBufferToBase64(buffer) {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  const chunkSize = 0x8000;
  for (let index = 0; index < bytes.length; index += chunkSize) {
    binary += String.fromCharCode.apply(
      null,
      bytes.subarray(index, index + chunkSize)
    );
  }
  return btoa(binary);
}

async function loadImageInline(imageUrl) {
  if (!isImageFetchable(imageUrl)) return null;

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 6000);

  try {
    const response = await fetch(imageUrl, {
      method: 'GET',
      signal: controller.signal,
      cache: 'force-cache'
    });
    if (!response.ok) return null;

    const type = response.headers.get('content-type') || 'image/jpeg';
    if (!/^image\//i.test(type)) return null;

    const buffer = await response.arrayBuffer();
    if (!buffer || buffer.byteLength === 0 || buffer.byteLength > 3.5 * 1024 * 1024) {
      return null;
    }

    return {
      mimeType: type.split(';')[0],
      data: arrayBufferToBase64(buffer)
    };
  } catch (error) {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

function buildFailure(error, signature, configured) {
  return {
    ok: false,
    signature,
    configured,
    error: error || {
      code: 'unknown_error',
      message: 'No fue posible obtener una estimación de Gemini.'
    }
  };
}

function inferComposition(payload, responseCallback) {
  const product = sanitizeProductForPrompt(payload && payload.product);
  const force = Boolean(payload && payload.force === true);
  const signature =
    (payload && payload.signature) ||
    (self.VoliuzGemini && self.VoliuzGemini.signatureFor(product)) ||
    '';

  if (!signature) {
    responseCallback(
      buildFailure(
        { code: 'invalid_payload', message: 'La solicitud no contiene un producto válido.' },
        signature,
        false
      )
    );
    return;
  }

  const cached = getMemoryEntry(signature);
  const cachedConfigError =
    cached &&
    cached.ok === false &&
    cached.error &&
    (cached.error.code === 'missing_api_key' ||
      cached.error.code === 'ai_disabled' ||
      cached.error.code === 'invalid_api_key');

  // Un fallo de configuración no debe bloquear el reintento después de que el
  // usuario guarde una clave. Los fallos de red ya no se cachean.
  if (cachedConfigError) memoryCache.delete(signature);

  if (cached && !force && !cachedConfigError) {
    responseCallback({
      ok: cached.ok !== false,
      cached: true,
      signature,
      configured: true,
      data: cached.data,
      error: cached.error
    });
    return;
  }

  if (inFlightRequests.has(signature)) {
    inFlightRequests.get(signature).then(responseCallback);
    return;
  }

  loadPersistentEntry(signature, (persisted) => {
    if (persisted && !force) {
      responseCallback({
        ok: true,
        cached: true,
        signature,
        configured: true,
        data: persisted.data
      });
      return;
    }

    readAiSettings(async (settings) => {
      if (!settings.enabled) {
        responseCallback(
          buildFailure(
            {
              code: 'ai_disabled',
              message: 'La inferencia con IA está desactivada en la configuración.'
            },
            signature,
            false
          )
        );
        return;
      }

      if (!settings.available) {
        responseCallback(
          buildFailure(
            {
              code: 'missing_api_key',
              message:
                'No hay clave de Gemini ni backend configurado. Se muestran solo los datos declarados.'
            },
            signature,
            false
          )
        );
        return;
      }

      if (settings.backendUrl && !self.VoliuzBackendClient) {
        responseCallback(
          buildFailure(
            {
              code: 'backend_unavailable',
              message: 'El cliente del backend no está disponible en la extensión.'
            },
            signature,
            true
          )
        );
        return;
      }

      if (!settings.backendUrl && !self.VoliuzGemini) {
        responseCallback(
          buildFailure(
            {
              code: 'gemini_client_unavailable',
              message: 'El cliente de Gemini no está disponible en la extensión.'
            },
            signature,
            true
          )
        );
        return;
      }

      const request = (async () => {
        let result = null;

        if (settings.backendUrl) {
          result = await self.VoliuzBackendClient.analyze({
            backendUrl: settings.backendUrl,
            product,
            timeoutMs: 22000
          });
        } else {
          let imageInline = null;
          if (settings.useImage && isImageFetchable(product.imageUrl)) {
            imageInline = await loadImageInline(product.imageUrl);
          }

          result = await self.VoliuzGemini.fetchInference({
            apiKey: settings.apiKey,
            model: settings.model,
            product,
            imageInline,
            maxAttempts: 2
          });
        }

        if (result.ok) {
          const entry = { data: result.data, timestamp: Date.now(), ttl: CACHE_TTL_MS };
          rememberEntry(signature, entry);
          savePersistentEntry(signature, entry);
          return {
            ok: true,
            cached: false,
            signature,
            configured: true,
            data: result.data
          };
        }

        // No se cachean fallos de red ni de configuración para permitir
        // reintentos después de guardar una clave o recuperar la conexión.
        const code = result.error && result.error.code;
        const nonCacheable = [
          'network_error',
          'timeout',
          'service_unavailable',
          'missing_api_key',
          'ai_disabled',
          'invalid_api_key'
        ];
        if (!nonCacheable.includes(code)) {
          rememberEntry(signature, {
            ok: false,
            error: result.error,
            timestamp: Date.now(),
            ttl: NEGATIVE_TTL_MS
          });
        }

        return buildFailure(result.error, signature, true);
      })().finally(() => {
        inFlightRequests.delete(signature);
      });

      inFlightRequests.set(signature, request);
      request.then(responseCallback);
    });
  });
}

/* --------------------------------------------------------------------------
   Chat ambiental: validación, rate limit y contexto
   -------------------------------------------------------------------------- */

const chatRateLimit = new Map();

function inferAlternativeSuggestion(payload, responseCallback) {
  const product = sanitizeProductForPrompt(payload && payload.product);
  const force = Boolean(payload && payload.force === true);
  const signature =
    (payload && payload.signature) ||
    (self.VoliuzGemini && self.VoliuzGemini.signatureFor(product)) ||
    '';

  if (!signature) {
    responseCallback(
      buildFailure(
        { code: 'invalid_payload', message: 'La solicitud no contiene un producto válido.' },
        signature,
        false
      )
    );
    return;
  }

  const cached = getMemoryEntry(signature);
  if (cached && !force) {
    responseCallback({
      ok: cached.ok !== false,
      cached: true,
      signature,
      configured: true,
      data: cached.data,
      error: cached.error
    });
    return;
  }

  if (inFlightRequests.has(signature)) {
    inFlightRequests.get(signature).then(responseCallback);
    return;
  }

  readAiSettings(async (settings) => {
    if (!settings.enabled) {
      responseCallback(
        buildFailure(
          {
            code: 'ai_disabled',
            message: 'La inferencia con IA está desactivada en la configuración.'
          },
          signature,
          false
        )
      );
      return;
    }

    if (!settings.available && !settings.backendUrl) {
      responseCallback(
        buildFailure(
          {
            code: 'missing_api_key',
            message:
              'No hay clave de Gemini ni backend configurado. No se puede generar una sugerencia de alternativa.'
          },
          signature,
          false
        )
      );
      return;
    }

    const request = (async () => {
      let result = null;

      if (settings.backendUrl) {
        // El backend no expone sugerencias de alternativa todavía; se usa Gemini directo.
        result = await self.VoliuzGemini.fetchAlternativeSuggestion({
          apiKey: settings.apiKey,
          model: settings.model,
          product: product || {},
          impact: payload.impact || {},
          maxAttempts: 2,
        });
      } else {
        result = await self.VoliuzGemini.fetchAlternativeSuggestion({
          apiKey: settings.apiKey,
          model: settings.model,
          product: product || {},
          impact: payload.impact || {},
          maxAttempts: 2,
        });
      }

      if (result.ok) {
        const entry = { data: result.data, timestamp: Date.now(), ttl: CACHE_TTL_MS };
        rememberEntry(signature, entry);
        savePersistentEntry(signature, entry);
        responseCallback({
          ok: true,
          cached: false,
          signature,
          configured: true,
          data: result.data,
        });
      } else {
        const code = result.error && result.error.code;
        const nonCacheable = [
          'network_error',
          'timeout',
          'service_unavailable',
          'missing_api_key',
          'ai_disabled',
          'invalid_api_key'
        ];
        if (!nonCacheable.includes(code)) {
          rememberEntry(signature, {
            ok: false,
            error: result.error,
            timestamp: Date.now(),
            ttl: NEGATIVE_TTL_MS
          });
        }
        responseCallback(buildFailure(result.error, signature, true));
      }
    })();

    const requestPromise = request.then(responseCallback);
    inFlightRequests.set(signature, requestPromise);
    requestPromise.then(() => inFlightRequests.delete(signature));
  });
}

function cleanChatText(value, max) {
  return String(value == null ? '' : value)
    .replace(/<[^>]*>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, max);
}

function sanitizeChatHistory(history) {
  if (!Array.isArray(history)) return [];

  return history
    .slice(-MAX_CHAT_HISTORY_MESSAGES)
    .filter((message) => message && typeof message === 'object')
    .map((message) => ({
      role: message.role === 'assistant' ? 'assistant' : 'user',
      text: cleanChatText(message.text, 1200)
    }))
    .filter((message) => message.text);
}

function sanitizeChatImpact(impact = {}) {
  const source = impact && typeof impact === 'object' ? impact : {};
  const recyclability =
    source.recyclability && typeof source.recyclability === 'object'
      ? source.recyclability
      : {};

  return {
    available: source.available === true,
    co2e: Number.isFinite(Number(source.co2e)) ? Number(source.co2e) : null,
    formattedCO2e: cleanChatText(source.formattedCO2e, 40),
    impactLevel: cleanChatText(source.impactLevel, 60),
    dataBasis: cleanChatText(source.dataBasis, 40),
    isPartialEstimate: source.isPartialEstimate === true,
    weightKg: Number.isFinite(Number(source.weightKg)) ? Number(source.weightKg) : null,
    isWeightEstimated: source.isWeightEstimated === true,
    materials: Array.isArray(source.materials)
      ? source.materials
          .filter((material) => material && material.name)
          .map((material) => ({
            name: cleanChatText(material.name, 60),
            percentage: Number.isFinite(Number(material.percentage))
              ? Number(material.percentage)
              : null,
            inferred: material.inferred === true
          }))
          .slice(0, 12)
      : [],
    recyclability: {
      level: cleanChatText(recyclability.level, 80),
      description: cleanChatText(recyclability.description, 400)
    },
    warnings: Array.isArray(source.warnings)
      ? source.warnings
          .map((warning) => cleanChatText(warning, 240))
          .filter(Boolean)
          .slice(0, 6)
      : []
  };
}

function checkChatRateLimit(tabId) {
  const key = Number.isInteger(tabId) ? tabId : 'global';
  const now = Date.now();
  const stamps = (chatRateLimit.get(key) || []).filter(
    (stamp) => now - stamp < CHAT_RATE_WINDOW_MS
  );

  if (stamps.length >= CHAT_RATE_LIMIT_MAX) {
    chatRateLimit.set(key, stamps);
    const retryAfterMs = Math.max(0, CHAT_RATE_WINDOW_MS - (now - stamps[0]));
    return { allowed: false, retryAfterSeconds: Math.ceil(retryAfterMs / 1000) };
  }

  stamps.push(now);
  chatRateLimit.set(key, stamps);

  // Limpieza acotada para que el mapa no crezca sin control.
  if (chatRateLimit.size > 40) {
    Array.from(chatRateLimit.entries()).forEach(([entryKey, entryStamps]) => {
      const alive = entryStamps.filter((stamp) => now - stamp < CHAT_RATE_WINDOW_MS);
      if (alive.length === 0) chatRateLimit.delete(entryKey);
      else chatRateLimit.set(entryKey, alive);
    });
  }

  return { allowed: true };
}

function resolveChatDomains(product, question) {
  const knowledge = self.VoliuzEnvironmentalKnowledge;
  if (!knowledge || typeof knowledge.detectDomain !== 'function') return [];

  const text = [
    product.title,
    product.category,
    product.descriptionText,
    product.rawMaterials,
    Array.isArray(product.materialMentions) ? product.materialMentions.join(' ') : '',
    question
  ].join(' ');

  const detected = knowledge.detectDomain(text);
  if (detected) return [detected];

  // Sin señales claras: se incluyen los dos dominios disponibles (máximo dos).
  return Array.isArray(knowledge.DOMAIN_KEYS) ? knowledge.DOMAIN_KEYS.slice(0, 2) : [];
}

function chatFailure(error, configured) {
  return {
    ok: false,
    configured: Boolean(configured),
    error: error || {
      code: 'unknown_error',
      message: 'No fue posible obtener una respuesta del chat de IA.'
    }
  };
}

function chatWithGemini(payload, sender, responseCallback) {
  const tabId = sender && sender.tab ? sender.tab.id : null;
  const rate = checkChatRateLimit(tabId);
  if (!rate.allowed) {
    responseCallback(
      chatFailure(
        {
          code: 'rate_limited',
          message: `Demasiadas preguntas seguidas. Espera ${rate.retryAfterSeconds} s antes de volver a intentarlo.`
        },
        true
      )
    );
    return;
  }

  const rawQuestion = String((payload && payload.question) || '');
  if (rawQuestion.length > MAX_CHAT_QUESTION) {
    responseCallback(
      chatFailure(
        {
          code: 'invalid_payload',
          message: `La pregunta supera el límite de ${MAX_CHAT_QUESTION} caracteres.`
        },
        false
      )
    );
    return;
  }

  const question = cleanChatText(rawQuestion, MAX_CHAT_QUESTION);
  if (!question) {
    responseCallback(
      chatFailure(
        { code: 'invalid_payload', message: 'La pregunta del chat está vacía.' },
        false
      )
    );
    return;
  }

  const product = sanitizeProductForPrompt(payload && payload.product);
  if (!product.title && !product.url) {
    responseCallback(
      chatFailure(
        {
          code: 'invalid_payload',
          message: 'La solicitud no contiene un producto válido para el chat.'
        },
        false
      )
    );
    return;
  }

  const history = sanitizeChatHistory(payload && payload.history);
  const impact = sanitizeChatImpact(payload && payload.impact);

  const serialized = JSON.stringify({ product, impact, history, question });
  if (serialized.length > MAX_CHAT_TEXT) {
    responseCallback(
      chatFailure(
        {
          code: 'payload_too_large',
          message: 'El contexto del chat excede el límite permitido.'
        },
        true
      )
    );
    return;
  }

  readAiSettings((settings) => {
    if (!settings.enabled) {
      responseCallback(
        chatFailure(
          {
            code: 'ai_disabled',
            message: 'La IA está desactivada en la configuración de VOLIUZ.'
          },
          false
        )
      );
      return;
    }

    if (!settings.available) {
      responseCallback(
        chatFailure(
          {
            code: 'missing_api_key',
            message:
              'No hay clave de Gemini ni backend configurado. El chat no está disponible.'
          },
          false
        )
      );
      return;
    }

    if (settings.backendUrl && !self.VoliuzBackendClient) {
      responseCallback(
        chatFailure(
          {
            code: 'backend_unavailable',
            message: 'El cliente del backend no está disponible en la extensión.'
          },
          true
        )
      );
      return;
    }

    if (!settings.backendUrl && !self.VoliuzGemini) {
      responseCallback(
        chatFailure(
          {
            code: 'gemini_client_unavailable',
            message: 'El cliente de Gemini no está disponible en la extensión.'
          },
          true
        )
      );
      return;
    }

    const knowledge = self.VoliuzEnvironmentalKnowledge;
    const domains = resolveChatDomains(product, question);
    const knowledgeContext =
      knowledge && typeof knowledge.buildChatContext === 'function'
        ? knowledge.buildChatContext(domains)
        : '';

    if (!knowledgeContext) {
      responseCallback(
        chatFailure(
          {
            code: 'knowledge_unavailable',
            message: 'La base de conocimiento ambiental no está disponible.'
          },
          true
        )
      );
      return;
    }

    const request = settings.backendUrl
      ? self.VoliuzBackendClient.chat({
          backendUrl: settings.backendUrl,
          product,
          impact,
          knowledgeContext,
          history,
          question,
          timeoutMs: 24000
        })
      : self.VoliuzGemini.fetchChatAnswer({
          apiKey: settings.apiKey,
          model: settings.model,
          product,
          impact,
          knowledgeContext,
          history,
          question,
          maxAttempts: 2
        });

    request
      .then((result) => {
        if (!result || !result.ok) {
          responseCallback(
            chatFailure(
              (result && result.error) || {
                code: 'unknown_error',
                message: 'No fue posible obtener una respuesta del chat de IA.'
              },
              true
            )
          );
          return;
        }

        responseCallback({
          ok: true,
          configured: true,
          data: {
            answer: result.data.answer,
            model: result.data.model,
            generatedAt: result.data.generatedAt,
            domains
          }
        });
      })
      .catch(() => {
        responseCallback(
          chatFailure(
            {
              code: 'unknown_error',
              message: 'No fue posible obtener una respuesta del chat de IA.'
            },
            true
          )
        );
      });
  });
}

/* --------------------------------------------------------------------------
   Mensajería
   -------------------------------------------------------------------------- */

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message.action !== 'string') return false;

  if (message.action === 'checkActiveStatus') {
    chrome.storage.local.get(['extensionEnabled'], (result) => {
      if (chrome.runtime.lastError) {
        sendResponse({ success: false, error: 'No se pudo leer el estado.' });
        return;
      }

      sendResponse({
        success: true,
        enabled: result.extensionEnabled !== false
      });
    });

    return true;
  }

  if (message.action === 'voliuz:getAiStatus') {
    readAiSettings((settings) => {
      sendResponse({
        success: true,
        enabled: settings.enabled,
        configured: settings.available,
        localKeyConfigured: settings.configured,
        backend: Boolean(settings.backendUrl),
        mode: settings.mode,
        model: settings.model,
        useImage: settings.useImage
      });
    });
    return true;
  }

  if (message.action === 'voliuz:chat') {
    const senderUrl = (sender && sender.tab && sender.tab.url) || '';
    if (!isMercadoLibreUrl(senderUrl)) {
      sendResponse(
        chatFailure(
          {
            code: 'forbidden',
            message: 'El chat solo está disponible en fichas de Mercado Libre Colombia.'
          },
          false
        )
      );
      return false;
    }

    chatWithGemini(message.payload || {}, sender, sendResponse);
    return true;
  }

  if (message.action === 'voliuz:inferComposition') {
    const senderUrl = (sender && sender.tab && sender.tab.url) || '';
    if (!isMercadoLibreUrl(senderUrl)) {
      sendResponse(
        buildFailure(
          {
            code: 'forbidden',
            message: 'La inferencia solo está disponible en fichas de Mercado Libre Colombia.'
          },
          '',
          false
        )
      );
      return false;
    }

    const payload = message.payload || {};
    const serialized = JSON.stringify(payload.product || {});
    if (serialized.length > MAX_PRODUCT_TEXT) {
      sendResponse(
        buildFailure(
          {
            code: 'payload_too_large',
            message: 'Los datos del producto exceden el límite permitido.'
          },
          payload.signature || '',
          true
        )
      );
      return false;
    }

    inferComposition(payload, sendResponse);
    return true;
  }

  if (message.action === 'voliuz:alternativeSuggestion') {
    const senderUrl = (sender && sender.tab && sender.tab.url) || '';
    if (!isMercadoLibreUrl(senderUrl)) {
      sendResponse(
        buildFailure(
          {
            code: 'forbidden',
            message: 'La sugerencia de alternativa solo está disponible en fichas de Mercado Libre Colombia.'
          },
          '',
          false
        )
      );
      return false;
    }

    const payload = message.payload || {};
    const serialized = JSON.stringify(payload.product || {});
    if (serialized.length > MAX_PRODUCT_TEXT) {
      sendResponse(
        buildFailure(
          {
            code: 'payload_too_large',
            message: 'Los datos del producto exceden el límite permitido.'
          },
          payload.signature || '',
          true
        )
      );
      return false;
    }

    inferAlternativeSuggestion(payload, sendResponse);
    return true;
  }
  return false;
});
