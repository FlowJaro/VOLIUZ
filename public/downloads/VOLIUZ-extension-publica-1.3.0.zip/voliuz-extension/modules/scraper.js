/**
 * VOLIUZ - Motor de extracción de información
 * Plataforma piloto: Mercado Libre Colombia.
 *
 * Principio: no inventar datos.
 * El módulo separa tres cosas que antes se mezclaban:
 *   1. Datos generales de la publicación (título, precio, categoría, imagen...).
 *   2. Composición declarada explícitamente (solo porcentajes explícitos).
 *   3. Estado de suficiencia de los datos y fuente de cada campo.
 */

(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.VoliuzScraper = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const ML_SELECTORS = {
    title: [
      'h1.ui-pdp-title',
      '.ui-pdp-title',
      'h1.poly-component__title',
      '[data-testid="item-title"]',
      '[data-testid="pdp-product-title"]',
      '[data-testid="product-title"]',
      '.ui-pdp-header__title',
      'h1[class*="title"]'
    ],

    price: [
      '.ui-pdp-price__second-line .andes-money-amount__fraction',
      '.ui-pdp-price .andes-money-amount__fraction',
      '.ui-pdp-price__main-container .andes-money-amount__fraction',
      '[data-testid="price-part"] .andes-money-amount__fraction',
      '[data-testid="price-part"]',
      '.andes-money-amount__fraction',
      '.price-tag-fraction',
      '[itemprop="price"]',
      'meta[itemprop="price"]',
      'meta[property="product:price:amount"]',
      'meta[property="og:price:amount"]'
    ],

    currency: [
      '.ui-pdp-price__second-line .andes-money-amount__currency-symbol',
      '.andes-money-amount__currency-symbol',
      'meta[itemprop="priceCurrency"]',
      'meta[property="product:price:currency"]',
      'meta[property="og:price:currency"]'
    ],

    category: [
      '.andes-breadcrumb__item',
      '.ui-pdp-breadcrumb__link',
      '.ui-pdp-breadcrumb a',
      '[data-testid="breadcrumb"] a',
      '.breadcrumb a',
      'nav[aria-label*="miga"] a',
      'meta[name="twitter:data1"]',
      'meta[property="article:section"]'
    ],

    image: [
      '.ui-pdp-gallery__figure img',
      '.ui-pdp-image',
      'img.ui-pdp-image',
      '.gallery-image img',
      '[data-testid="gallery-image"] img',
      'img[data-zoom]',
      'figure img',
      'meta[property="og:image"]',
      'meta[name="twitter:image"]'
    ],

    seller: [
      '.ui-pdp-seller__link-trigger',
      '.ui-pdp-seller__link',
      '.ui-pdp-seller__header__title',
      '.ui-pdp-seller__title',
      '[data-testid="seller-name"]',
      '[data-testid="seller-name-link"]',
      '.ui-seller-data-header__title',
      '.seller-name',
      'a[href*="/perfil/"]',
      '.ui-box-component__title'
    ],

    specsTable: [
      '.ui-pdp-table',
      '.ui-vpp-striped-specs',
      '.ui-pdp-specs__table',
      '.ui-vpp-highlighted-specs',
      '.ui-pdp-features',
      '.andes-table',
      '[data-testid="highlighted-specs"]',
      '[data-testid="product-attributes"]',
      '[data-testid="specs"]',
      '.ui-pdp-specs'
    ],

    description: [
      '.ui-pdp-description__content',
      'p.ui-pdp-description__content',
      '#description',
      '.item-description__text',
      '[data-testid="description"]',
      '.ui-pdp-description'
    ],

    jsonLd: [
      'script[type="application/ld+json"]',
      'script[type*="ld+json"]'
    ],

    metaDescription: [
      'meta[name="description"]',
      'meta[property="og:description"]',
      'meta[name="twitter:description"]'
    ]
  };

  const MATERIAL_LABEL_PATTERN =
    /(composici[oó]n|material(es)?|tejido|fabric|fibra|textil|tela|cuero|acabado|confecci[oó]n)/i;

  const MATERIAL_TERMS = [
    'poliester', 'poliéster', 'polyester', 'algodon', 'algodón', 'cotton',
    'lana', 'wool', 'lino', 'linen', 'viscosa', 'rayon', 'rayón', 'nailon',
    'nylon', 'poliamida', 'polyamide', 'elastano', 'elastane', 'spandex',
    'licra', 'lycra', 'acrilico', 'acrílico', 'acrylic', 'cuero', 'piel',
    'leather', 'poliuretano', 'polyurethane', 'aluminio', 'aluminum',
    'vidrio', 'glass', 'carton', 'cartón', 'cardboard', 'celulosa', 'caucho',
    'goma', 'rubber', 'plastico', 'plástico', 'plastic', 'abs',
    'policarbonato', 'polycarbonate', 'seda', 'silk', 'canamo', 'cáñamo',
    'hemp', 'bambu', 'bambú', 'bamboo', 'modal', 'tencel', 'lyocell', 'yute',
    'jute', 'polipropileno', 'polypropylene', 'polietileno', 'polyethylene',
    'poliestireno', 'polystyrene', 'metal', 'acero', 'steel', 'hierro',
    'iron', 'cobre', 'copper', 'bronce', 'bronze', 'zinc', 'titanio',
    'titanium', 'madera', 'wood', 'corcho', 'cork', 'papel', 'paper',
    'tetra', 'tetrapak'
  ];

  const DESCRIPTOR_PATTERN =
    /\b(color|talla|marca|modelo|estilo|dise[nñ]o|ideal|perfecto|excelente|nuevo|nueva|original|calidad|garant[ií]a|env[ií]o|compra|oferta|descuento|cuotas)\b[\s\S]*$/i;

  function normalizeText(value) {
    return String(value == null ? '' : value)
      .replace(/\u00a0/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function normalizeKey(value) {
    return normalizeText(value)
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, ' ')
      .trim();
  }

  const MATERIAL_TERMS_NORMALIZED = [...new Set(
    MATERIAL_TERMS.map(normalizeKey).filter(Boolean)
  )].sort((a, b) => b.length - a.length);

  function containsMaterialTerm(value) {
    const tokens = new Set(normalizeKey(value).split(/\s+/).filter(Boolean));
    if (tokens.size === 0) return false;
    return MATERIAL_TERMS_NORMALIZED.some((term) => tokens.has(term));
  }

  function countMaterialTerms(value) {
    const tokens = new Set(normalizeKey(value).split(/\s+/).filter(Boolean));
    return MATERIAL_TERMS_NORMALIZED.filter((term) => tokens.has(term)).length;
  }

  function getDoc(doc) {
    if (doc && typeof doc.querySelector === 'function') return doc;
    if (typeof document !== 'undefined') return document;
    return null;
  }

  function getCurrentUrl() {
    if (typeof window !== 'undefined' && window.location) {
      return window.location.href;
    }
    return '';
  }

  function isMercadoLibreColombia(url) {
    return /^https?:\/\/([a-z0-9-]+\.)?mercadolibre\.com\.co(\/|$)/i.test(
      String(url || '')
    );
  }

  function readElementValue(element) {
    if (!element) return '';

    const tag = String(element.tagName || '').toUpperCase();

    if (tag === 'META') {
      return normalizeText(
        element.getAttribute && element.getAttribute('content')
      );
    }

    if (tag === 'IMG') {
      const attributes = ['src', 'data-zoom', 'data-src', 'data-lazy', 'data-original'];
      for (const name of attributes) {
        const value = element.getAttribute && element.getAttribute(name);
        if (value && String(value).trim()) return String(value).trim();
      }
      const srcset = element.getAttribute && element.getAttribute('srcset');
      if (srcset) {
        const first = String(srcset).split(',')[0].trim().split(/\s+/)[0];
        if (first) return first;
      }
      return '';
    }

    if (tag === 'SCRIPT') {
      return String(element.textContent || '').trim();
    }

    const text = normalizeText(element.textContent);
    if (text) return text;

    const attributes = ['content', 'value', 'data-value', 'title'];
    for (const name of attributes) {
      const value = element.getAttribute && element.getAttribute(name);
      if (value && String(value).trim()) return String(value).trim();
    }

    return '';
  }

  function queryFirstWithSource(selectors, doc, source = 'dom') {
    const target = getDoc(doc);
    if (!target || typeof target.querySelector !== 'function') return null;

    const list = Array.isArray(selectors) ? selectors : [selectors];

    for (const selector of list) {
      try {
        const element = target.querySelector(selector);
        if (!element) continue;
        const value = readElementValue(element);
        if (value) return { value, source, detail: selector };
      } catch (error) {
        // Un selector inválido no debe detener el resto de respaldos.
      }
    }

    return null;
  }

  function queryFirst(selectors, doc) {
    const result = queryFirstWithSource(selectors, doc);
    return result ? result.value : null;
  }

  function queryAllAcross(selectors, doc) {
    const target = getDoc(doc);
    if (!target || typeof target.querySelectorAll !== 'function') return [];

    const list = Array.isArray(selectors) ? selectors : [selectors];
    const seen = new Set();
    const elements = [];

    for (const selector of list) {
      try {
        const nodes = target.querySelectorAll(selector);
        if (!nodes || !nodes.length) continue;
        Array.from(nodes).forEach((node) => {
          if (node && !seen.has(node)) {
            seen.add(node);
            elements.push(node);
          }
        });
      } catch (error) {
        // Continuar con el siguiente respaldo.
      }
    }

    return elements;
  }

  function safeQueryAll(root, selector) {
    if (!root || typeof root.querySelectorAll !== 'function') return [];
    try {
      return Array.from(root.querySelectorAll(selector) || []);
    } catch (error) {
      return [];
    }
  }

  function isMockDocument(url, doc) {
    return (
      String(url || '').includes('mock_mercadolibre') ||
      Boolean(doc && doc.getElementById && doc.getElementById('mock-mercadolibre-container'))
    );
  }

  function isProductPage(url = getCurrentUrl(), doc) {
    const target = getDoc(doc);
    const currentUrl = String(url || '');

    if (isMockDocument(currentUrl, target)) return true;
    if (!isMercadoLibreColombia(currentUrl)) return false;

    const hasProductUrlPattern =
      /\/(p\/MCO|MCO-[A-Z0-9]+|articulo\.mercadolibre)/i.test(currentUrl);

    if (!target) return hasProductUrlPattern;

    const title = queryFirst(ML_SELECTORS.title, target);
    const price = queryFirst(ML_SELECTORS.price, target);
    const jsonLd = extractJsonLdData(target);

    return (
      hasProductUrlPattern ||
      Boolean((title || jsonLd.name) && (price != null || jsonLd.price != null))
    );
  }

  /**
   * Convierte un texto monetario de Mercado Libre en número.
   * Admite "129.900", "1.299,50", "$ 129900" y "R$ 1.299,00".
   */
  function parsePriceText(value) {
    if (value === null || value === undefined || value === '') return null;
    if (typeof value === 'number') {
      return Number.isFinite(value) && value > 0 ? value : null;
    }

    let text = String(value).trim();
    if (!text) return null;

    text = text.replace(/[^\d.,-]/g, '');
    if (!text) return null;

    const negative = text.startsWith('-');
    text = text.replace(/-/g, '');
    if (!text) return null;

    const hasDot = text.includes('.');
    const hasComma = text.includes(',');

    if (hasDot && hasComma) {
      const lastDot = text.lastIndexOf('.');
      const lastComma = text.lastIndexOf(',');
      if (lastComma > lastDot) {
        text = text.replace(/\./g, '').replace(/,/g, '.');
      } else {
        text = text.replace(/,/g, '');
      }
    } else if (hasComma) {
      const parts = text.split(',');
      const isThousands = /^\d{1,3}(,\d{3})+$/.test(text);
      if (parts.length > 2 || isThousands) text = text.replace(/,/g, '');
      else text = text.replace(',', '.');
    } else if (hasDot) {
      const parts = text.split('.');
      const isThousands = /^\d{1,3}(\.\d{3})+$/.test(text);
      if (parts.length > 2 || isThousands) text = text.replace(/\./g, '');
    }

    const number = Number(text);
    if (!Number.isFinite(number) || number <= 0) return null;
    return negative ? -number : number;
  }

  function normalizeCurrency(value, url = getCurrentUrl()) {
    const raw = normalizeText(value).toUpperCase();
    const currentUrl = String(url || '');

    if (/\bUSD\b|US\$/.test(raw)) return 'USD';
    if (/\bBRL\b|R\$/.test(raw)) return 'BRL';
    if (/\bCOP\b|COL\$/.test(raw)) return 'COP';
    if (/\bEUR\b|€/.test(raw)) return 'EUR';
    if (/\bARS\b/.test(raw)) return 'ARS';
    if (/\bMXN\b/.test(raw)) return 'MXN';
    if (/\bCLP\b/.test(raw)) return 'CLP';
    if (/\bPEN\b/.test(raw)) return 'PEN';

    if (/mercadolibre\.com\.br/i.test(currentUrl)) return 'BRL';
    if (/mercadolibre\.com\.mx/i.test(currentUrl)) return 'MXN';
    if (/mercadolibre\.com\.ar/i.test(currentUrl)) return 'ARS';
    if (/mercadolibre\.cl/i.test(currentUrl)) return 'CLP';
    if (/mercadolibre\.com\.pe/i.test(currentUrl)) return 'PEN';

    // El piloto es Colombia; "$" sin código explícito se interpreta como COP.
    return 'COP';
  }

  function formatMoney(amount, currency = 'COP') {
    if (!Number.isFinite(amount)) return 'No disponible';

    const symbols = {
      COP: '$',
      USD: 'US$',
      BRL: 'R$',
      EUR: '€',
      MXN: '$',
      ARS: '$',
      CLP: '$',
      PEN: 'S/'
    };
    const symbol = symbols[currency] || '';
    const hasDecimals = Math.abs(amount % 1) > 0.0001;
    const formatted = new Intl.NumberFormat('es-CO', {
      minimumFractionDigits: hasDecimals ? 2 : 0,
      maximumFractionDigits: hasDecimals ? 2 : 0
    }).format(amount);

    return `${symbol} ${formatted} ${currency}`.trim();
  }

  /**
   * Extrae productos de uno o varios bloques JSON-LD.
   * No atribuye propiedades que no estén presentes.
   */
  function parseJsonLdProducts(rawText) {
    const products = [];
    let data;

    try {
      data = JSON.parse(String(rawText || ''));
    } catch (error) {
      return products;
    }

    const visit = (node) => {
      if (!node) return;

      if (Array.isArray(node)) {
        node.forEach(visit);
        return;
      }

      if (typeof node !== 'object') return;

      const rawType = node['@type'];
      const types = Array.isArray(rawType) ? rawType : [rawType];
      const normalizedTypes = types
        .filter(Boolean)
        .map((type) => String(type).toLowerCase());

      if (
        normalizedTypes.includes('product') ||
        normalizedTypes.includes('productgroup')
      ) {
        products.push(node);
      }

      if (node['@graph']) visit(node['@graph']);
      if (node.itemListElement) visit(node.itemListElement);
      if (node.item) visit(node.item);
      if (node.hasVariant) visit(node.hasVariant);
    };

    visit(data);
    return products;
  }

  function textFromValue(value, keys = ['name']) {
    if (value === null || value === undefined) return '';

    if (typeof value === 'string' || typeof value === 'number') {
      return normalizeText(value);
    }

    if (Array.isArray(value)) {
      for (const item of value) {
        const text = textFromValue(item, keys);
        if (text) return text;
      }
      return '';
    }

    if (typeof value === 'object') {
      for (const key of keys) {
        if (value[key] !== null && value[key] !== undefined) {
          const text = textFromValue(value[key], keys);
          if (text) return text;
        }
      }
    }

    return '';
  }

  function getJsonLdScripts(doc) {
    return queryAllAcross(ML_SELECTORS.jsonLd, doc);
  }

  function extractJsonLdData(doc) {
    const result = {
      name: '',
      description: '',
      category: '',
      image: '',
      brand: '',
      seller: '',
      price: null,
      priceText: '',
      currency: '',
      materialTexts: [],
      additionalProperties: []
    };

    for (const script of getJsonLdScripts(doc)) {
      const products = parseJsonLdProducts(script.textContent || '');

      for (const product of products) {
        if (!result.name) result.name = normalizeText(product.name);
        if (!result.description) result.description = normalizeText(product.description);
        if (!result.category) result.category = textFromValue(product.category);
        if (!result.image) {
          result.image = textFromValue(product.image, ['url', 'contentUrl']);
        }
        if (!result.brand) result.brand = textFromValue(product.brand);

        const offers = Array.isArray(product.offers)
          ? product.offers
          : [product.offers];

        for (const offer of offers) {
          if (!offer || typeof offer !== 'object') continue;
          if (!result.seller) result.seller = textFromValue(offer.seller);
          if (result.priceText === '' && offer.price != null) {
            result.priceText = String(offer.price);
          }
          if (!result.currency && offer.priceCurrency) {
            result.currency = String(offer.priceCurrency);
          }
        }

        if (product.material) {
          const materials = Array.isArray(product.material)
            ? product.material
            : [product.material];
          materials.forEach((material) => {
            const text = textFromValue(material);
            if (text) result.materialTexts.push(text);
          });
        }

        if (Array.isArray(product.additionalProperty)) {
          product.additionalProperty.forEach((property) => {
            if (!property || typeof property !== 'object') return;
            const name = textFromValue(property.name);
            const value = textFromValue(property.value);
            if (name && value) {
              result.additionalProperties.push({ name, value });
            }
          });
        }

        if (result.name && result.priceText) break;
      }

      if (result.name && result.priceText) break;
    }

    result.price = parsePriceText(result.priceText);
    return result;
  }

  function cleanTitle(value) {
    return normalizeText(value)
      .replace(/\s*[|·-]\s*Mercado\s*Libre.*$/i, '')
      .replace(/\s*[|·-]\s*MercadoLibre.*$/i, '')
      .trim();
  }

  function isMeaningfulTitle(value) {
    const normalized = normalizeKey(value);
    if (!normalized || normalized.length < 3) return false;
    return !/^(mercado libre|mercadolibre|producto|inicio|pagina)$/.test(normalized);
  }

  function extractTitleDetails(doc, jsonLd = {}) {
    const dom = queryFirstWithSource(ML_SELECTORS.title, doc);
    let value = dom ? cleanTitle(dom.value) : '';
    let source = dom ? 'dom' : '';
    let detail = dom ? dom.detail : '';

    if (!isMeaningfulTitle(value) && jsonLd.name) {
      value = cleanTitle(jsonLd.name);
      source = 'json_ld';
      detail = 'Product.name';
    }

    if (!isMeaningfulTitle(value)) {
      const meta = queryFirstWithSource(
        [
          'meta[property="og:title"]',
          'meta[name="twitter:title"]',
          'title'
        ],
        doc
      );
      if (meta) {
        value = cleanTitle(meta.value);
        source = 'meta';
        detail = meta.detail;
      }
    }

    if (!isMeaningfulTitle(value)) {
      return { value: '', source: '', detail: '' };
    }

    return { value, source, detail };
  }

  function extractCategoryDetails(doc, jsonLd = {}) {
    const target = getDoc(doc);

    if (target) {
      for (const selector of ML_SELECTORS.category) {
        try {
          const nodes = target.querySelectorAll(selector);
          if (!nodes || !nodes.length) continue;

          if (selector.startsWith('meta')) {
            const value = normalizeText(nodes[0].getAttribute('content'));
            if (value) {
              return { value, source: 'meta', path: [value], detail: selector };
            }
            continue;
          }

          const parts = Array.from(nodes)
            .map((node) => normalizeText(node.textContent))
            .filter(Boolean)
            .filter((part) => !/^mercado\s*libre/i.test(part));

          if (parts.length) {
            const path = parts.slice(-3);
            return {
              value: path.slice(-2).join(' · '),
              source: 'breadcrumb',
              path,
              detail: selector
            };
          }
        } catch (error) {
          // Probar el siguiente selector.
        }
      }
    }

    if (jsonLd.category) {
      return {
        value: jsonLd.category,
        source: 'json_ld',
        path: [jsonLd.category],
        detail: 'Product.category'
      };
    }

    return { value: '', source: '', path: [], detail: '' };
  }

  function extractCategory(doc, jsonLd = {}) {
    return extractCategoryDetails(doc, jsonLd).value;
  }

  function normalizeImageUrl(value) {
    const raw = normalizeText(value);
    if (!raw) return '';

    try {
      const base = getCurrentUrl() || 'https://www.mercadolibre.com.co/';
      const url = new URL(raw, base);
      if (url.protocol === 'https:' || url.protocol === 'http:') {
        return url.href;
      }
    } catch (error) {
      return '';
    }

    return '';
  }

  function extractImageDetails(doc, jsonLd = {}) {
    const dom = queryFirstWithSource(ML_SELECTORS.image, doc);
    if (dom) {
      const value = normalizeImageUrl(dom.value);
      if (value) return { value, source: 'dom', detail: dom.detail };
    }

    if (jsonLd.image) {
      const value = normalizeImageUrl(jsonLd.image);
      if (value) return { value, source: 'json_ld', detail: 'Product.image' };
    }

    return { value: '', source: '', detail: '' };
  }

  function extractImage(doc, jsonLd = {}) {
    return extractImageDetails(doc, jsonLd).value;
  }

  function cleanSellerName(value) {
    const name = normalizeText(value)
      .replace(/^(vendido|vendedor|tienda)\s*(por|oficial)?\s*:?\s*/i, '')
      .replace(/\s*(ver perfil|ir a la tienda|visitar tienda).*$/i, '')
      .trim();

    if (!name) return '';
    if (name.length > 80) return '';

    const normalized = normalizeKey(name);
    if (
      /^(caracteristicas|descripcion|opiniones|preguntas|informacion|detalles|especificaciones|mercado libre|mercado libre colombia)$/.test(
        normalized
      )
    ) {
      return '';
    }

    return name;
  }

  function extractSellerDetails(doc, jsonLd = {}) {
    const dom = queryFirstWithSource(ML_SELECTORS.seller, doc);
    if (dom) {
      const value = cleanSellerName(dom.value);
      if (value) return { value, source: 'dom', detail: dom.detail };
    }

    if (jsonLd.seller) {
      const value = cleanSellerName(jsonLd.seller);
      if (value) {
        return { value, source: 'json_ld', detail: 'offers.seller.name' };
      }
    }

    return { value: '', source: '', detail: '' };
  }

  function extractPriceDetails(doc, jsonLd = {}) {
    const dom = queryFirstWithSource(ML_SELECTORS.price, doc);
    let value = null;
    let source = '';
    let detail = '';
    let raw = '';

    if (dom) {
      raw = dom.value;
      value = parsePriceText(dom.value);
      if (value !== null) {
        source = 'dom';
        detail = dom.detail;
      }
    }

    if (value === null && jsonLd.price !== null && jsonLd.price !== undefined) {
      raw = jsonLd.priceText || String(jsonLd.price);
      value = parsePriceText(jsonLd.price);
      if (value !== null) {
        source = 'json_ld';
        detail = 'Product.offers.price';
      }
    }

    return { value, source, detail, raw };
  }

  function extractCurrencyDetails(doc, jsonLd = {}, url = getCurrentUrl()) {
    if (jsonLd.currency) {
      return {
        value: normalizeCurrency(jsonLd.currency, url),
        source: 'json_ld',
        detail: 'Product.offers.priceCurrency'
      };
    }

    const dom = queryFirstWithSource(ML_SELECTORS.currency, doc);
    if (dom) {
      return {
        value: normalizeCurrency(dom.value, url),
        source: 'dom',
        detail: dom.detail
      };
    }

    return {
      value: normalizeCurrency('', url),
      source: 'default_domain',
      detail: ''
    };
  }

  const MATERIAL_DISPLAY_NAMES = new Map();

  MATERIAL_TERMS.forEach((term) => {
    const key = normalizeKey(term);
    if (!key) return;
    if (!MATERIAL_DISPLAY_NAMES.has(key) || /[áéíóúñ]/.test(term)) {
      MATERIAL_DISPLAY_NAMES.set(key, term);
    }
  });

  function cleanMaterialName(value) {
    let name = normalizeText(value)
      .replace(/^[\s,.;:|/+-]+/, '')
      .replace(/[\s,.;:|/+-]+$/, '')
      .replace(/^(?:de|del|con|en|mezcla\s+de)\s+/i, '')
      .replace(/\s+(?:y|e|and|con)\s*$/i, '')
      .trim();

    name = name.replace(/^\d{1,3}(?:[.,]\d+)?\s*%\s*/, '').trim();
    name = name.replace(DESCRIPTOR_PATTERN, '').trim();

    return name;
  }

  function looksLikeMaterial(value) {
    const name = cleanMaterialName(value);
    if (!name) return false;
    if (countMaterialTerms(name) === 0) return false;
    return true;
  }

  function firstClause(value) {
    return normalizeText(value)
      .split(/[,;|/]/)[0]
      .replace(/^\s*(?:de|del|con|en)\s+/i, '')
      .replace(/^\s*(?:y|e|and)\s+/i, '')
      .trim();
  }

  function firstClauseInfo(value) {
    const text = String(value || '');
    const leadingMatch = text.match(/^\s*/);
    const leading = leadingMatch ? leadingMatch[0].length : 0;
    const rest = text.slice(leading);
    const delimiterIndex = rest.search(/[,;|/]/);
    const clause = delimiterIndex >= 0 ? rest.slice(0, delimiterIndex) : rest;
    const end = leading + clause.length + (delimiterIndex >= 0 ? 1 : 0);
    return { raw: clause, end };
  }

  function immediateAfter(value) {
    const text = String(value || '').replace(/^\s*/, '');
    if (!text) return '';
    if (/^[,;|/]/.test(text)) return '';
    const delimiterIndex = text.search(/[,;|/]/);
    return delimiterIndex >= 0 ? text.slice(0, delimiterIndex) : text;
  }

  function immediateBefore(value) {
    const text = String(value || '').replace(/\s*$/, '');
    if (!text) return '';
    if (/[,;|/]$/.test(text)) return '';
    const parts = text.split(/[,;|/]/);
    return parts[parts.length - 1] || '';
  }

  function lastClause(value) {
    const parts = normalizeText(value).split(/[,;|/]/);
    return (parts[parts.length - 1] || '')
      .replace(/^\s*(?:y|e|and)\s+/i, '')
      .trim();
  }

  /**
   * Extrae únicamente porcentajes explícitos asociados a materiales.
   *
   * No convierte una descripción comercial en composición: si no hay
   * porcentaje, no se asigna uno. Si el nombre es ambiguo (por ejemplo,
   * "poliéster y algodón" con un solo porcentaje), se descarta.
   */
  function parseCompositionText(rawText) {
    const text = normalizeText(rawText);
    const result = {
      materials: [],
      totalPercentage: 0,
      status: 'none',
      warnings: []
    };

    if (!text) return result;

    const percentageMatches = Array.from(
      text.matchAll(/(\d{1,3}(?:[.,]\d+)?)\s*%/g)
    );

    if (percentageMatches.length === 0) return result;

    const parsed = [];
    let previousEnd = 0;

    percentageMatches.forEach((match, index) => {
      const nextStart =
        index + 1 < percentageMatches.length
          ? percentageMatches[index + 1].index
          : text.length;

      const before = text.slice(previousEnd, match.index);
      const after = text.slice(match.index + match[0].length, nextStart);
      const beforeHasMaterial = looksLikeMaterial(immediateBefore(before));
      const afterHasMaterial = looksLikeMaterial(immediateAfter(after));

      let rawName = '';
      let direction = '';
      let consumedEnd = match.index + match[0].length;

      if (afterHasMaterial && !beforeHasMaterial) {
        const clause = firstClauseInfo(after);
        rawName = firstClause(clause.raw);
        direction = 'percentage_first';
        consumedEnd = match.index + match[0].length + clause.end;
      } else if (beforeHasMaterial && !afterHasMaterial) {
        rawName = lastClause(before);
        direction = 'name_first';
      } else if (afterHasMaterial && beforeHasMaterial) {
        result.warnings.push(
          `Asociación ambigua cerca de "${match[0]}": se descarta ese fragmento.`
        );
      }

      previousEnd = consumedEnd;

      if (!rawName) return;

      const name = cleanMaterialName(rawName);
      if (!name || name.length > 60) return;

      const termCount = countMaterialTerms(name);
      if (termCount === 0) return;

      if (termCount > 1) {
        result.warnings.push(
          `Material ambiguo "${name}": se requiere una composición separada por porcentajes.`
        );
        return;
      }

      const percentage = Number.parseFloat(match[1].replace(',', '.'));
      const validPercentage =
        Number.isFinite(percentage) && percentage > 0 && percentage <= 100;

      if (!validPercentage) {
        result.warnings.push(`Porcentaje inválido: ${match[0]}.`);
      }

      parsed.push({
        name,
        normalizedName: normalizeKey(name),
        percentage: Number.isFinite(percentage) ? percentage : null,
        validPercentage,
        direction,
        raw: match[0]
      });
    });

    if (parsed.length === 0) return result;

    // Deduplicar el mismo material dentro del mismo bloque, sumando sus
    // porcentajes. No se combinan bloques de fuentes distintas.
    const merged = new Map();

    parsed.forEach((material) => {
      const key = material.normalizedName;
      if (!key) return;

      if (merged.has(key)) {
        const previous = merged.get(key);
        previous.percentage =
          (Number(previous.percentage) || 0) +
          (Number(material.percentage) || 0);
        previous.validPercentage =
          previous.validPercentage && material.validPercentage;
        previous.duplicated = true;
        result.warnings.push(
          `El material "${material.name}" aparece más de una vez; se sumaron sus porcentajes.`
        );
        return;
      }

      merged.set(key, { ...material });
    });

    const materials = Array.from(merged.values());
    const totalPercentage = materials.reduce(
      (total, material) =>
        total + (Number.isFinite(material.percentage) ? material.percentage : 0),
      0
    );

    const hasInvalid = materials.some(
      (material) =>
        !material.validPercentage ||
        !Number.isFinite(material.percentage) ||
        material.percentage <= 0 ||
        material.percentage > 100
    );

    let status = 'partial';
    if (hasInvalid || totalPercentage > 101) status = 'invalid';
    else if (totalPercentage >= 99 && totalPercentage <= 101) status = 'complete';

    result.materials = materials;
    result.totalPercentage = Math.round(totalPercentage * 100) / 100;
    result.status = status;

    if (status === 'partial') {
      result.warnings.push(
        `La composición suma ${result.totalPercentage}% y no alcanza el 100%.`
      );
    }

    if (status === 'invalid') {
      result.warnings.push(
        'La composición contiene porcentajes inválidos o supera el 100%.'
      );
    }

    return result;
  }

  function extractMaterialMentions(value) {
    const tokens = normalizeKey(value).split(/\s+/).filter(Boolean);
    const mentions = [];

    tokens.forEach((token) => {
      if (!MATERIAL_DISPLAY_NAMES.has(token)) return;
      const display = MATERIAL_DISPLAY_NAMES.get(token) || token;
      const label = display.charAt(0).toUpperCase() + display.slice(1);
      if (!mentions.includes(label)) mentions.push(label);
    });

    return mentions;
  }

  function collectMaterialBlocks(doc, jsonLd = {}) {
    const blocks = new Map();

    const addBlock = (value, source, priority) => {
      const text = normalizeText(value);
      const key = normalizeKey(text);
      if (!text || !key || text.length < 3 || text.length > 800) return;

      const existing = blocks.get(key);
      if (!existing || priority > existing.priority) {
        blocks.set(key, { text, source, priority });
      }
    };

    const relevant = (text) =>
      MATERIAL_LABEL_PATTERN.test(text) ||
      /%/.test(text) ||
      containsMaterialTerm(text);

    const tables = queryAllAcross(ML_SELECTORS.specsTable, doc);
    tables.forEach((table) => {
      const rows = safeQueryAll(
        table,
        'tr, .andes-table__row, .ui-pdp-specs__table-row, li, [data-testid*="spec"], [data-testid*="attribute"]'
      );
      const candidates = rows.length > 0 ? rows : [table];

      candidates.forEach((row) => {
        const text = normalizeText(row.textContent);
        if (text && relevant(text)) addBlock(text, 'ficha_tecnica', 4);
      });
    });

    const descriptions = queryAllAcross(ML_SELECTORS.description, doc);
    descriptions.forEach((element) => {
      const description = normalizeText(element.textContent);
      if (!description) return;

      description.split(/[.\n;]+/).forEach((sentence) => {
        const text = normalizeText(sentence);
        if (text && relevant(text)) addBlock(text, 'descripcion', 2);
      });
    });

    if (jsonLd.description) {
      String(jsonLd.description).split(/[.\n;]+/).forEach((sentence) => {
        const text = normalizeText(sentence);
        if (text && relevant(text)) addBlock(text, 'json_ld', 3);
      });
    }

    (jsonLd.materialTexts || []).forEach((material) => {
      addBlock(material, 'json_ld', 4);
    });

    (jsonLd.additionalProperties || []).forEach((property) => {
      const text = `${property.name}: ${property.value}`;
      if (MATERIAL_LABEL_PATTERN.test(property.name) || relevant(text)) {
        addBlock(text, 'json_ld', 4);
      }
    });

    ML_SELECTORS.metaDescription.forEach((selector) => {
      const meta = queryFirstWithSource([selector], doc);
      if (meta && relevant(meta.value)) {
        addBlock(meta.value, 'meta', 1);
      }
    });

    return Array.from(blocks.values());
  }

  function extractDescriptionAndFeatures(doc, jsonLd = {}) {
    const descriptionParts = [];

    queryAllAcross(ML_SELECTORS.description, doc).forEach((element) => {
      const text = normalizeText(element.textContent);
      if (text && text.length >= 20) descriptionParts.push(text);
    });

    if (jsonLd.description) {
      const text = normalizeText(jsonLd.description);
      if (text && text.length >= 20) descriptionParts.push(text);
    }

    if (descriptionParts.length === 0) {
      ML_SELECTORS.metaDescription.forEach((selector) => {
        const meta = queryFirstWithSource([selector], doc);
        const text = normalizeText(meta && meta.value);
        if (text && text.length >= 20) descriptionParts.push(text);
      });
    }

    const descriptionText = Array.from(new Set(descriptionParts))
      .join(' ')
      .slice(0, 3000);

    const features = [];
    const addFeature = (value) => {
      const text = normalizeText(value);
      if (!text || text.length < 3 || text.length > 200) return;
      features.push(text);
    };

    queryAllAcross(ML_SELECTORS.specsTable, doc).forEach((table) => {
      const rows = safeQueryAll(
        table,
        'tr, li, .andes-table__row, .ui-pdp-specs__table-row, [data-testid*="attribute"]'
      );
      const candidates = rows.length > 0 ? rows : [table];
      candidates.forEach((row) => addFeature(row.textContent));
    });

    (jsonLd.additionalProperties || []).forEach((property) => {
      addFeature(`${property.name}: ${property.value}`);
    });

    return {
      descriptionText,
      features: Array.from(new Set(features)).slice(0, 25)
    };
  }

  function extractMaterialsData(doc, jsonLd = {}) {
    const blocks = collectMaterialBlocks(doc, jsonLd);
    const evaluated = blocks.map((block) => {
      const composition = parseCompositionText(block.text);
      return {
        ...block,
        composition,
        mentions: extractMaterialMentions(block.text)
      };
    });

    const score = (block) => {
      const statusScore =
        block.composition.status === 'complete'
          ? 1000
          : block.composition.status === 'partial'
            ? 500
            : block.composition.status === 'invalid'
              ? 300
              : 0;
      return (
        statusScore +
        block.priority * 10 +
        block.composition.materials.length * 5
      );
    };

    const withMaterials = evaluated
      .filter((block) => block.composition.materials.length > 0)
      .sort((a, b) => score(b) - score(a));

    const best = withMaterials[0] || null;
    const mentions = [];
    evaluated.forEach((block) => {
      block.mentions.forEach((mention) => {
        if (!mentions.includes(mention)) mentions.push(mention);
      });
    });

    let compositionStatus = 'not_available';
    if (best) compositionStatus = best.composition.status;
    else if (mentions.length > 0) compositionStatus = 'mentions_only';

    const environmentalDataStatus =
      compositionStatus === 'complete'
        ? 'complete'
        : compositionStatus === 'partial'
          ? 'partial'
          : compositionStatus === 'invalid'
            ? 'invalid'
            : compositionStatus === 'mentions_only'
              ? 'mentions_only'
              : 'not_available';

    return {
      rawMaterials: best ? best.text : mentions.join(', '),
      materials: best ? best.composition.materials : [],
      compositionStatus,
      totalPercentage: best ? best.composition.totalPercentage : 0,
      materialSource: best ? best.source : 'no_disponible',
      materialSourceDetail: best ? best.text : '',
      materialMentions: mentions,
      environmentalDataStatus,
      warnings: best ? best.composition.warnings.slice() : []
    };
  }

  function extractMaterials(doc, jsonLd = {}) {
    return extractMaterialsData(doc, jsonLd).rawMaterials;
  }

  function environmentalStatusReason(status) {
    switch (status) {
      case 'not_available':
        return 'La publicación no declara composición porcentual de materiales.';
      case 'mentions_only':
        return 'La publicación menciona materiales, pero no declara porcentajes verificables.';
      case 'partial':
        return 'La composición declarada no suma el 100%; no se usa para calcular.';
      case 'invalid':
        return 'La composición declarada contiene porcentajes inválidos o incompatibles.';
      case 'complete':
        return '';
      default:
        return 'No hay información ambiental suficiente en la publicación.';
    }
  }

  function scrapeProduct(doc, options = {}) {
    const target = getDoc(doc);
    const currentUrl = options.url || getCurrentUrl();

    if (!target || !isProductPage(currentUrl, target)) {
      return createEmptyProductResult(
        'no_product_page',
        currentUrl,
        'La página actual no corresponde a una ficha de producto.'
      );
    }

    try {
      const jsonLd = extractJsonLdData(target);

      const titleDetails = extractTitleDetails(target, jsonLd);
      const priceDetails = extractPriceDetails(target, jsonLd);
      const currencyDetails = extractCurrencyDetails(
        target,
        jsonLd,
        currentUrl
      );
      const categoryDetails = extractCategoryDetails(target, jsonLd);
      const imageDetails = extractImageDetails(target, jsonLd);
      const sellerDetails = extractSellerDetails(target, jsonLd);
      const materialsData = extractMaterialsData(target, jsonLd);
      const descriptive = extractDescriptionAndFeatures(target, jsonLd);

      const title = titleDetails.value;
      const priceAvailable = Number.isFinite(priceDetails.value);
      const priceRaw = priceAvailable ? priceDetails.value : null;
      const currency = currencyDetails.value;
      const category = categoryDetails.value;
      const image = imageDetails.value;
      const sellerName = sellerDetails.value;
      const storeName = sellerName || 'Mercado Libre Colombia';
      const storeSource = sellerName
        ? sellerDetails.source
        : 'platform_default';

      const missingGeneralFields = [];
      if (!title) missingGeneralFields.push('title');
      if (!priceAvailable) missingGeneralFields.push('price');
      if (!category) missingGeneralFields.push('category');
      if (!image) missingGeneralFields.push('image');

      const missingEnvironmentalFields = [];
      if (materialsData.compositionStatus !== 'complete') {
        missingEnvironmentalFields.push('materials');
      }

      const missingFields = [
        ...missingGeneralFields,
        ...missingEnvironmentalFields
      ];

      let extractionStatus = 'insufficient';
      if (title && priceAvailable && category && image) {
        extractionStatus = 'complete';
      } else if (title && priceAvailable) {
        extractionStatus = 'partial';
      }

      const isDetected = Boolean(title || priceAvailable);

      return {
        isDetected,

        storeName,
        storeSource,
        sellerName,
        storeDomain: 'mercadolibre.com.co',

        title,
        titleAvailable: Boolean(title),

        priceRaw,
        formattedPrice: formatMoney(priceRaw, currency),
        priceAvailable,
        currency,

        category,
        categoryPath: categoryDetails.path,
        categoryAvailable: Boolean(category),
        categoryGroup:
          (typeof VoliuzCategoryImpact !== 'undefined' &&
            VoliuzCategoryImpact &&
            VoliuzCategoryImpact.resolveCategoryGroup)
            ? (VoliuzCategoryImpact.resolveCategoryGroup(category, title) || {}).group || null
            : null,

        image,
        imageAvailable: Boolean(image),

        brand: jsonLd.brand || '',

        descriptionText: descriptive.descriptionText,
        features: descriptive.features,

        rawMaterials: materialsData.rawMaterials,
        materials: materialsData.materials,
        materialsAvailable: materialsData.materials.length > 0,
        materialMentions: materialsData.materialMentions,
        materialMentionsAvailable: materialsData.materialMentions.length > 0,
        compositionStatus: materialsData.compositionStatus,
        totalCompositionPercentage: materialsData.totalPercentage,
        materialSource: materialsData.materialSource,
        materialSourceDetail: materialsData.materialSourceDetail,
        environmentalDataStatus: materialsData.environmentalDataStatus,
        environmentalDataReason: environmentalStatusReason(
          materialsData.environmentalDataStatus
        ),

        extractionStatus,
        extractionStatusReason:
          extractionStatus === 'complete'
            ? ''
            : extractionStatus === 'partial'
              ? 'La publicación no expone todos los datos generales.'
              : 'Faltan el título o el precio para identificar la publicación.',

        missingFields,
        missingGeneralFields,
        missingEnvironmentalFields,

        fieldSources: {
          title: titleDetails.source || 'not_available',
          price: priceDetails.source || 'not_available',
          currency: currencyDetails.source || 'not_available',
          category: categoryDetails.source || 'not_available',
          image: imageDetails.source || 'not_available',
          storeName: storeSource,
          materials: materialsData.materialSource
        },
        fieldDetails: {
          title: titleDetails.detail || '',
          price: priceDetails.detail || '',
          currency: currencyDetails.detail || '',
          category: categoryDetails.detail || '',
          image: imageDetails.detail || '',
          storeName: sellerDetails.detail || '',
          materials: materialsData.materialSourceDetail || ''
        },

        warnings: materialsData.warnings,

        url: currentUrl,
        extractedAt: new Date().toISOString()
      };
    } catch (error) {
      console.error('[VOLIUZ Scraper] Error durante la extracción:', error);

      return createEmptyProductResult(
        'error',
        currentUrl,
        'No fue posible leer la publicación. Los datos no se sustituyen por valores ficticios.'
      );
    }
  }

  function createEmptyProductResult(extractionStatus, url, reason = '') {
    return {
      isDetected: false,
      storeName: 'Mercado Libre Colombia',
      storeSource: 'platform_default',
      sellerName: '',
      storeDomain: 'mercadolibre.com.co',

      title: '',
      titleAvailable: false,

      priceRaw: null,
      formattedPrice: 'No disponible',
      priceAvailable: false,
      currency: 'COP',

      category: '',
      categoryPath: [],
      categoryAvailable: false,

      image: '',
      imageAvailable: false,

      brand: '',

      descriptionText: '',
      features: [],

      rawMaterials: '',
      materials: [],
      materialsAvailable: false,
      materialMentions: [],
      materialMentionsAvailable: false,
      compositionStatus: 'not_available',
      totalCompositionPercentage: 0,
      materialSource: 'no_disponible',
      materialSourceDetail: '',
      environmentalDataStatus: 'not_available',
      environmentalDataReason:
        'No se encontró información de composición en la publicación.',

      extractionStatus,
      extractionStatusReason:
        reason || 'No se pudo completar la extracción de la publicación.',

      missingFields: ['title', 'price', 'category', 'image', 'materials'],
      missingGeneralFields: ['title', 'price', 'category', 'image'],
      missingEnvironmentalFields: ['materials'],

      fieldSources: {
        title: 'not_available',
        price: 'not_available',
        currency: 'not_available',
        category: 'not_available',
        image: 'not_available',
        storeName: 'platform_default',
        materials: 'no_disponible'
      },
      fieldDetails: {
        title: '',
        price: '',
        currency: '',
        category: '',
        image: '',
        storeName: '',
        materials: ''
      },

      warnings: reason ? [reason] : [],

      url: url || '',
      extractedAt: new Date().toISOString()
    };
  }

  return {
    isProductPage,
    scrapeProduct,
    extractTitleDetails,
    extractPriceDetails,
    extractCurrencyDetails,
    extractCategoryDetails,
    extractImageDetails,
    extractSellerDetails,
    extractMaterials,
    extractMaterialsData,
    extractDescriptionAndFeatures,
    extractMaterialMentions,
    extractJsonLdData,
    parseJsonLdProducts,
    parsePriceText,
    parseCompositionText,
    normalizeCurrency,
    normalizeImageUrl,
    formatMoney,
    createEmptyProductResult,
    ML_SELECTORS
  };
});
