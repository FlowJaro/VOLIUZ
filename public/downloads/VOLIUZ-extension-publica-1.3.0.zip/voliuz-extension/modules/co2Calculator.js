/**
 * VOLIUZ - Motor de Estimación Ambiental (co2Calculator.js)
 *
 * Metodología:
 *   Impacto (kg CO2e) = Σ (peso_material_kg × factor_material_kgCO2e_por_kg)
 *
 * Los factores son parámetros provisionales del prototipo. No están
 * trazados a un dataset, versión, unidad funcional ni geografía verificables.
 * El resultado NO es una LCA certificada ni una medición directa.
 */

(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.VoliuzCO2Calculator = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  // Carga opcional del módulo de estimación por categoría (Fase 2 de datos).
  let CategoryImpact = null;
  try {
    if (typeof require === 'function') CategoryImpact = require('./categoryImpact.js');
  } catch (e) {
    CategoryImpact = null;
  }
  if (!CategoryImpact && typeof VoliuzCategoryImpact !== 'undefined') {
    CategoryImpact = VoliuzCategoryImpact;
  }
  const FACTOR_SOURCE = 'provisional_unverified';
  const FACTOR_SCOPE = 'cradle_to_gate_material_screening';
  const FACTOR_VERSION = 'prototype-1.2.0';
  const AI_MAX_TOTAL_PERCENTAGE = 102;

  const FACTOR_SOURCE_NOTE =
    'Factores heredados del prototipo VOLIUZ. No están trazados a un dataset, ' +
    'versión, unidad funcional ni geografía verificables; se usan solo como ' +
    'parámetros provisionales de exploración.';

  const METHODOLOGY = {
    formula:
      'Impacto (kg CO2e) = Σ (peso_material_kg × factor_material_kgCO2e_por_kg)',
    scope:
      'Cuna a puerta, únicamente etapa de materiales. No incluye transporte, ' +
      'fabricación, uso, empaque ni fin de vida.',
    weightMethod:
      'Peso estimado con promedios provisionales por categoría. No es un peso ' +
      'declarado por el fabricante.',
    factorStatus: FACTOR_SOURCE,
    factorSourceNote: FACTOR_SOURCE_NOTE,
    verificationStatus: 'preliminary_unverified',
    classificationNote:
      'Los umbrales Bajo/Medio/Alto son etiquetas pedagógicas provisionales, ' +
      'no límites normativos.'
  };

  const CLASSIFICATION_THRESHOLDS = {
    lowMax: 2,
    mediumMax: 4
  };

  const EMISSION_FACTORS = {
    // Fibras sintéticas
    polyester: {
      factor: 13.5,
      name: 'Poliéster virgen',
      recyclingPotential: 'medium',
      color: '#353a40'
    },
    polyester_recycled: {
      factor: 4.2,
      name: 'Poliéster reciclado (rPET)',
      recyclingPotential: 'medium',
      color: '#10b981'
    },
    polyamide: {
      factor: 15.8,
      name: 'Poliamida / Nailon',
      recyclingPotential: 'medium',
      color: '#353a40'
    },
    acrylic: {
      factor: 14.2,
      name: 'Acrílico',
      recyclingPotential: 'low',
      color: '#353a40'
    },
    elastane: {
      factor: 16.5,
      name: 'Elastano / Spandex',
      recyclingPotential: 'low',
      color: '#434933'
    },
    polyurethane: {
      factor: 8.5,
      name: 'Cuero sintético (PU)',
      recyclingPotential: 'low',
      color: '#353a40'
    },

    // Fibras naturales
    cotton_conventional: {
      factor: 9.8,
      name: 'Algodón convencional',
      recyclingPotential: 'medium',
      color: '#8ccdff'
    },
    cotton_organic: {
      factor: 3.6,
      name: 'Algodón orgánico',
      recyclingPotential: 'medium',
      color: '#b8f000'
    },
    cotton_recycled: {
      factor: 2.6,
      name: 'Algodón reciclado',
      recyclingPotential: 'medium',
      color: '#10b981'
    },
    wool: {
      factor: 19.5,
      name: 'Lana convencional',
      recyclingPotential: 'medium',
      color: '#c3caad'
    },
    wool_recycled: {
      factor: 6.5,
      name: 'Lana reciclada',
      recyclingPotential: 'medium',
      color: '#10b981'
    },
    viscose: {
      factor: 11.2,
      name: 'Viscosa / Rayón',
      recyclingPotential: 'low',
      color: '#8ccdff'
    },
    linen: {
      factor: 4.5,
      name: 'Lino natural',
      recyclingPotential: 'medium',
      color: '#b8f000'
    },

    // Materiales duros / tecnología / empaques
    aluminum_virgin: {
      factor: 12.8,
      name: 'Aluminio primario',
      recyclingPotential: 'high',
      color: '#dee3eb'
    },
    aluminum_recycled: {
      factor: 2.1,
      name: 'Aluminio reciclado',
      recyclingPotential: 'high',
      color: '#b8f000'
    },
    plastic_abs: {
      factor: 6.5,
      name: 'Plásticos técnicos (ABS/PC)',
      recyclingPotential: 'low',
      color: '#353a40'
    },
    glass: {
      factor: 1.2,
      name: 'Vidrio',
      recyclingPotential: 'high',
      color: '#8ccdff'
    },
    cardboard: {
      factor: 0.9,
      name: 'Cartón / Celulosa',
      recyclingPotential: 'high',
      color: '#b8f000'
    },
    leather_animal: {
      factor: 32.0,
      name: 'Cuero animal',
      recyclingPotential: 'low',
      color: '#353a40'
    },
    rubber: {
      factor: 4.8,
      name: 'Caucho / Goma',
      recyclingPotential: 'low',
      color: '#353a40'
    }
  };

  Object.values(EMISSION_FACTORS).forEach((material) => {
    material.factorSource = FACTOR_SOURCE;
    material.factorScope = FACTOR_SCOPE;
    material.factorVersion = FACTOR_VERSION;
    material.verifiedForColombia = false;
    material.recyclable =
      material.recyclingPotential === 'high' ||
      material.recyclingPotential === 'medium';
  });

  const METHODOLOGY_LIMITATIONS =
    'Estimación preliminar de cuna a puerta no validada por una LCA certificada. ' +
    'Usa composición declarada, peso estimado y parámetros provisionales; no modela ' +
    'transporte, fabricación, uso, empaque ni fin de vida, ni condiciones específicas ' +
    'de Colombia.';

  const METHODOLOGY_LIMITATIONS_LIST = [
    'No es una evaluación de ciclo de vida completa ni una certificación ambiental.',
    'No se modelan transporte, distribución, uso, empaque ni fin de vida.',
    'Los factores de emisión son provisionales y carecen de trazabilidad documental verificada.',
    'El peso del producto se estima por categoría; no proviene del fabricante.',
    'Solo se consideran los materiales declarados explícitamente en la publicación.',
    'No se consideran aditivos, accesorios, forros, botones, cierres ni tintes.'
  ];

  const CATEGORY_WEIGHTS = {
    hoodie: 0.35,
    buzo: 0.35,
    sudadera: 0.35,
    chaqueta: 0.7,
    abrigo: 0.95,
    pantalon: 0.5,
    jean: 0.55,
    camiseta: 0.18,
    camisa: 0.2,
    vestido: 0.35,
    calzado: 0.75,
    zapatos: 0.75,
    tenis: 0.7,
    morral: 0.5,
    gorra: 0.1,
    celular: 0.2,
    audifonos: 0.15,
    teclado: 0.6,
    hogar: 0.4,
    default: 0.35
  };

  const CATEGORY_WEIGHT_SOURCE = 'promedio_provisional_por_categoria';

  const NON_MATERIAL_TERMS =
    /(garant[ií]a|calidad|original|nuevo|nueva|seguro|env[ií]o|compra|oferta|descuento|cuotas|satisfacci[oó]n|modalidad|pago|talla|color|marca|modelo|uso|estilo|dise[nñ]o|ideal|perfecto|excelente)/i;

  function normalizeText(value) {
    return String(value == null ? '' : value)
      .replace(/\u00a0/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function normalizeKey(value) {
    return normalizeText(value)
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, ' ')
      .trim();
  }

  function round(value, decimals = 2) {
    const factor = Math.pow(10, decimals);
    return Math.round((Number(value) + Number.EPSILON) * factor) / factor;
  }

  function formatNumber(value, decimals = 1) {
    if (!Number.isFinite(value)) return 'No disponible';
    return new Intl.NumberFormat('es-CO', {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals
    }).format(value);
  }

  function estimateWeight(title = '', category = '') {
    const text = normalizeKey(`${title} ${category}`);
    const entries = Object.entries(CATEGORY_WEIGHTS)
      .filter(([key]) => key !== 'default')
      .sort((a, b) => b[0].length - a[0].length);

    for (const [key, weight] of entries) {
      if (text.includes(normalizeKey(key))) return weight;
    }

    return CATEGORY_WEIGHTS.default;
  }

  function estimateWeightDetails(title = '', category = '', explicitWeightKg = null) {
    const explicit = Number(explicitWeightKg);
    if (Number.isFinite(explicit) && explicit > 0) {
      return {
        weightKg: explicit,
        isWeightEstimated: false,
        weightSource: 'declarado',
        weightMethod: 'Peso declarado en la publicación.'
      };
    }

    return {
      weightKg: estimateWeight(title, category),
      isWeightEstimated: true,
      weightSource: CATEGORY_WEIGHT_SOURCE,
      weightMethod:
        'Peso estimado con un promedio provisional por categoría. No fue declarado por el fabricante.'
    };
  }

  function resolveMaterialData(inputName = '') {
    const name = normalizeKey(inputName);
    const isRecycled = /recicl|recycled/.test(name);

    // 1. Materiales reciclados específicos antes de las reglas genéricas.
    if (/algod|cotton/.test(name) && isRecycled) {
      return { ...EMISSION_FACTORS.cotton_recycled, rawKey: 'cotton_recycled' };
    }
    if (/lana|wool/.test(name) && isRecycled) {
      return { ...EMISSION_FACTORS.wool_recycled, rawKey: 'wool_recycled' };
    }
    if (
      /rpet/.test(name) ||
      ((/poliester|polyester|pet\b/.test(name)) && isRecycled)
    ) {
      return {
        ...EMISSION_FACTORS.polyester_recycled,
        rawKey: 'polyester_recycled'
      };
    }

    // 2. Fibras específicas antes de la regla genérica "poli".
    if (/poliam|nail|nylon/.test(name)) {
      return { ...EMISSION_FACTORS.polyamide, rawKey: 'polyamide' };
    }
    if (/poliuretano|cuero\s*sint|\bpu\b/.test(name)) {
      return { ...EMISSION_FACTORS.polyurethane, rawKey: 'polyurethane' };
    }
    if (/elast|spandex|lycra|licra/.test(name)) {
      return { ...EMISSION_FACTORS.elastane, rawKey: 'elastane' };
    }
    if (/acrilic|acrylic/.test(name)) {
      return { ...EMISSION_FACTORS.acrylic, rawKey: 'acrylic' };
    }
    if (/algod|cotton/.test(name)) {
      return /organic|organico/.test(name)
        ? { ...EMISSION_FACTORS.cotton_organic, rawKey: 'cotton_organic' }
        : {
            ...EMISSION_FACTORS.cotton_conventional,
            rawKey: 'cotton_conventional'
          };
    }
    if (/poliester|polyester/.test(name)) {
      return { ...EMISSION_FACTORS.polyester, rawKey: 'polyester' };
    }
    if (/polietilen|poliestiren|polipropilen|plastic|plastico|abs|policarbonato|\bpc\b|\bpp\b|\bpe\b/.test(name)) {
      return { ...EMISSION_FACTORS.plastic_abs, rawKey: 'plastic_abs' };
    }

    // 3. Otros materiales.
    if (/alum/.test(name)) {
      return isRecycled
        ? {
            ...EMISSION_FACTORS.aluminum_recycled,
            rawKey: 'aluminum_recycled'
          }
        : { ...EMISSION_FACTORS.aluminum_virgin, rawKey: 'aluminum_virgin' };
    }
    if (/lana|wool/.test(name)) {
      return { ...EMISSION_FACTORS.wool, rawKey: 'wool' };
    }
    if (/lino|linen/.test(name)) {
      return { ...EMISSION_FACTORS.linen, rawKey: 'linen' };
    }
    if (/viscosa|rayon|viscose/.test(name)) {
      return { ...EMISSION_FACTORS.viscose, rawKey: 'viscose' };
    }
    if (/vidrio|glass/.test(name)) {
      return { ...EMISSION_FACTORS.glass, rawKey: 'glass' };
    }
    if (/carton|cardboard|celulosa|papel|paper/.test(name)) {
      return { ...EMISSION_FACTORS.cardboard, rawKey: 'cardboard' };
    }
    if (/caucho|goma|rubber/.test(name)) {
      return { ...EMISSION_FACTORS.rubber, rawKey: 'rubber' };
    }
    if (/cuero|piel|leather/.test(name)) {
      return { ...EMISSION_FACTORS.leather_animal, rawKey: 'leather_animal' };
    }

    // Sin factor: no se inventa un valor para materiales no identificados.
    return {
      factor: null,
      name: normalizeText(inputName) || 'Material no identificado',
      recyclingPotential: 'unknown',
      recyclable: false,
      color: '#353a40',
      rawKey: 'generic'
    };
  }

  const MATERIAL_WORDS = [
    'algodon', 'cotton', 'poliester', 'polyester', 'rpet', 'poliamida',
    'poliam', 'nailon', 'nylon', 'elastano', 'elastane', 'spandex', 'lycra',
    'licra', 'acrilico', 'acrylic', 'poliuretano', 'polyurethane', 'cuero',
    'piel', 'leather', 'lana', 'wool', 'seda', 'silk', 'viscosa', 'rayon',
    'viscose', 'modal', 'lyocell', 'tencel', 'lino', 'linen', 'canamo',
    'hemp', 'bambu', 'bamboo', 'yute', 'jute', 'aluminio', 'aluminum',
    'alum', 'vidrio', 'glass', 'carton', 'cardboard', 'celulosa', 'papel',
    'paper', 'caucho', 'goma', 'rubber', 'plastico', 'plastic', 'abs',
    'policarbonato', 'polycarbonate', 'polietileno', 'polyethylene',
    'poliestireno', 'polystyrene', 'polipropileno', 'polypropylene', 'metal',
    'acero', 'steel', 'hierro', 'iron', 'cobre', 'copper', 'bronce',
    'bronze', 'zinc', 'titanio', 'titanium', 'madera', 'wood', 'corcho',
    'cork', 'tetra', 'tetrapak'
  ];

  const MATERIAL_WORD_SET = new Set(MATERIAL_WORDS);

  const KNOWN_MATERIAL_PATTERN = new RegExp(
    `\\b(${MATERIAL_WORDS.join('|')})\\b`,
    'i'
  );

  const COMPOSITION_DESCRIPTOR_PATTERN =
    /\b(color|talla|marca|modelo|estilo|diseno|ideal|perfecto|excelente|nuevo|nueva|original|calidad|garantia|envio|compra|oferta|descuento|cuotas|modalidad|pago)\b[\s\S]*$/i;

  function cleanMaterialName(value) {
    let name = normalizeText(value)
      .replace(/^[\s,.;:|/+-]+/, '')
      .replace(/[\s,.;:|/+-]+$/, '')
      .replace(/^(?:de|del|con|en|mezcla\s+de)\s+/i, '')
      .replace(/\s+(?:y|e|and|con)\s*$/i, '')
      .trim();

    name = name.replace(/^\d{1,3}(?:[.,]\d+)?\s*%\s*/, '').trim();
    name = name.replace(COMPOSITION_DESCRIPTOR_PATTERN, '').trim();

    return name;
  }

  function countMaterialWords(value) {
    const tokens = new Set(normalizeKey(value).split(/\s+/).filter(Boolean));
    let count = 0;
    tokens.forEach((token) => {
      if (MATERIAL_WORD_SET.has(token)) count += 1;
    });
    return count;
  }

  function looksLikeMaterial(value) {
    const name = cleanMaterialName(value);
    if (!name) return false;
    return KNOWN_MATERIAL_PATTERN.test(normalizeKey(name));
  }

  function immediateAfter(value) {
    const text = String(value || '').replace(/^\s*/, '');
    if (!text || /^[,;|/]/.test(text)) return '';
    const delimiterIndex = text.search(/[,;|/]/);
    return delimiterIndex >= 0 ? text.slice(0, delimiterIndex) : text;
  }

  function immediateBefore(value) {
    const text = String(value || '').replace(/\s*$/, '');
    if (!text || /[,;|/]$/.test(text)) return '';
    const parts = text.split(/[,;|/]/);
    return parts[parts.length - 1] || '';
  }

  function firstClauseInfo(value) {
    const text = String(value || '');
    const leading = (text.match(/^\s*/) || [''])[0].length;
    const rest = text.slice(leading);
    const delimiterIndex = rest.search(/[,;|/]/);
    const clause = delimiterIndex >= 0 ? rest.slice(0, delimiterIndex) : rest;
    const end = leading + clause.length + (delimiterIndex >= 0 ? 1 : 0);
    return { raw: clause, end };
  }

  function lastClause(value) {
    const parts = normalizeText(value).split(/[,;|/]/);
    return (parts[parts.length - 1] || '')
      .replace(/^\s*(?:y|e|and)\s+/i, '')
      .trim();
  }

  /**
   * Extrae únicamente porcentajes explícitos vinculados a un material.
   * No transforma descripciones comerciales en composición ni asigna
   * porcentajes que la publicación no declara.
   */
  function parseCompositionText(rawText) {
    const text = normalizeText(rawText);
    const result = {
      materials: [],
      totalPercentage: 0,
      status: 'none',
      warnings: [],
      unresolved: false
    };

    if (!text) return result;

    const matches = Array.from(
      text.matchAll(/(\d{1,3}(?:[.,]\d+)?)\s*%/g)
    );

    if (matches.length === 0) return result;

    const parsed = [];
    let previousEnd = 0;

    matches.forEach((match, index) => {
      const nextStart =
        index + 1 < matches.length ? matches[index + 1].index : text.length;

      const before = text.slice(previousEnd, match.index);
      const after = text.slice(match.index + match[0].length, nextStart);
      const beforeMaterial = looksLikeMaterial(immediateBefore(before));
      const afterMaterial = looksLikeMaterial(immediateAfter(after));

      let rawName = '';
      let direction = '';
      let consumedEnd = match.index + match[0].length;

      if (afterMaterial && !beforeMaterial) {
        const clause = firstClauseInfo(after);
        rawName = cleanMaterialName(clause.raw);
        direction = 'percentage_first';
        consumedEnd = match.index + match[0].length + clause.end;
      } else if (beforeMaterial && !afterMaterial) {
        rawName = cleanMaterialName(lastClause(before));
        direction = 'name_first';
      } else if (afterMaterial && beforeMaterial) {
        result.warnings.push(
          `Asociación ambigua cerca de "${match[0]}": se descarta ese fragmento.`
        );
      }

      previousEnd = consumedEnd;

      if (!rawName) return;
      if (rawName.length > 60) return;

      const wordCount = countMaterialWords(rawName);
      if (wordCount === 0) return;
      if (wordCount > 1) {
        result.warnings.push(
          `Material ambiguo "${rawName}": se requiere una composición separada por porcentajes.`
        );
        return;
      }

      const percentage = Number.parseFloat(match[1].replace(',', '.'));
      const validPercentage =
        Number.isFinite(percentage) && percentage > 0 && percentage <= 100;

      if (!validPercentage) {
        result.warnings.push(`Porcentaje inválido: ${match[0]}.`);
      }

      parsed.push({
        name: rawName,
        normalizedName: normalizeKey(rawName),
        percentage: Number.isFinite(percentage) ? percentage : null,
        validPercentage,
        direction,
        raw: match[0]
      });
    });

    if (parsed.length === 0) {
      result.unresolved = true;
      result.status = 'unresolved';
      return result;
    }

    const merged = new Map();
    parsed.forEach((material) => {
      const key = material.normalizedName;
      if (!key) return;

      if (merged.has(key)) {
        const previous = merged.get(key);
        previous.percentage =
          (Number(previous.percentage) || 0) +
          (Number(material.percentage) || 0);
        previous.validPercentage =
          previous.validPercentage && material.validPercentage;
        result.warnings.push(
          `El material "${material.name}" aparece más de una vez; se sumaron sus porcentajes.`
        );
        return;
      }

      merged.set(key, { ...material });
    });

    const materials = Array.from(merged.values());
    const totalPercentage = materials.reduce(
      (total, material) =>
        total + (Number.isFinite(material.percentage) ? material.percentage : 0),
      0
    );

    const hasInvalid = materials.some(
      (material) =>
        !material.validPercentage ||
        !Number.isFinite(material.percentage) ||
        material.percentage <= 0 ||
        material.percentage > 100
    );

    let status = 'partial';
    if (hasInvalid || totalPercentage > 101) status = 'invalid';
    else if (totalPercentage >= 99 && totalPercentage <= 101) status = 'complete';

    result.materials = materials;
    result.totalPercentage = Math.round(totalPercentage * 100) / 100;
    result.status = status;

    if (status === 'partial') {
      result.warnings.push(
        `La composición suma ${result.totalPercentage}% y no alcanza el 100%.`
      );
    }

    if (status === 'invalid') {
      result.warnings.push(
        'La composición contiene porcentajes inválidos o supera el 100%.'
      );
    }

    return result;
  }

  /**
   * Normaliza la composición recibida del scraper o, como respaldo,
   * interpreta el texto de `rawMaterials`.
   */
  function normalizeMaterials(product = {}) {
    const warnings = [];
    let source = 'none';
    let rawMaterials = [];

    if (Array.isArray(product.materials) && product.materials.length > 0) {
      source = 'structured';
      rawMaterials = product.materials.map((material) => ({
        name: normalizeText(material && material.name),
        percentage:
          material && material.percentage !== null && material.percentage !== undefined
            ? Number(material.percentage)
            : null,
        validPercentage:
          material && typeof material.validPercentage === 'boolean'
            ? material.validPercentage
            : null
      }));
    } else if (normalizeText(product.rawMaterials)) {
      source = 'raw_text';
      const parsed = parseCompositionText(product.rawMaterials);
      warnings.push(...parsed.warnings);
      if (parsed.status === 'unresolved') {
        return {
          materials: [],
          totalPercentage: 0,
          status: 'unresolved',
          warnings,
          source
        };
      }
      rawMaterials = parsed.materials;
    }

    const materials = rawMaterials
      .map((material) => {
        const name = normalizeText(material.name);
        const percentage = Number(material.percentage);
        const valid =
          material.validPercentage !== false &&
          Number.isFinite(percentage) &&
          percentage > 0 &&
          percentage <= 100;

        return {
          name,
          percentage: Number.isFinite(percentage) ? percentage : null,
          valid
        };
      })
      .filter((material) => material.name);

    if (materials.length === 0) {
      return {
        materials: [],
        totalPercentage: 0,
        status: source === 'none' ? 'missing' : 'unresolved',
        warnings,
        source
      };
    }

    if (materials.some((material) => !material.valid)) {
      return {
        materials,
        totalPercentage: 0,
        status: 'invalid',
        warnings: [
          ...warnings,
          'La composición contiene porcentajes ausentes o fuera de rango.'
        ],
        source
      };
    }

    const rawTotal = materials.reduce(
      (total, material) => total + material.percentage,
      0
    );

    if (rawTotal > 101) {
      return {
        materials,
        totalPercentage: round(rawTotal, 2),
        status: 'invalid',
        warnings: [...warnings, 'La composición supera el 100%.'],
        source
      };
    }

    if (rawTotal < 99) {
      return {
        materials,
        totalPercentage: round(rawTotal, 2),
        status: 'incomplete',
        warnings: [
          ...warnings,
          `La composición suma ${round(rawTotal, 2)}% y no alcanza el 100%.`
        ],
        source
      };
    }

    // Los porcentajes se normalizan a 100 para que el peso declarado o
    // estimado se reparta exactamente entre los materiales reconocidos.
    const scale = 100 / rawTotal;
    const normalized = materials.map((material) => ({
      ...material,
      percentage: round(material.percentage * scale, 2)
    }));

    let normalizedTotal = round(
      normalized.reduce((total, material) => total + material.percentage, 0),
      2
    );

    // Ajusta el residuo de redondeo para que la suma mostrada sea 100.
    const residual = round(100 - normalizedTotal, 2);
    if (normalized.length > 0 && residual !== 0) {
      const last = normalized[normalized.length - 1];
      last.percentage = round(last.percentage + residual, 2);
      normalizedTotal = round(
        normalized.reduce((total, material) => total + material.percentage, 0),
        2
      );
    }

    return {
      materials: normalized,
      totalPercentage: normalizedTotal,
      status: 'complete',
      warnings,
      source
    };
  }

  /**
   * Normaliza una composición inferida por IA.
   *
   * Reglas estrictas:
   *   - Solo se aceptan nombres y porcentajes; jamás factores ni pesos.
   *   - No se renormaliza a 100: se conserva la fracción identificada.
   *   - Los materiales sin porcentaje no se usan para calcular.
   */
  function normalizeInferredComposition(aiComposition) {
    if (
      !aiComposition ||
      aiComposition.ok === false ||
      !Array.isArray(aiComposition.materials) ||
      aiComposition.materials.length === 0
    ) {
      return null;
    }

    const quantified = [];
    const unquantified = [];

    aiComposition.materials.forEach((item) => {
      const name = normalizeText(item && item.name);
      if (!name) return;

      const minimumRaw = Number(item && item.percentageMin);
      const maximumRaw = Number(item && item.percentageMax);
      const minimum = Number.isFinite(minimumRaw)
        ? Math.max(0, Math.min(100, minimumRaw))
        : null;
      const maximum = Number.isFinite(maximumRaw)
        ? Math.max(0, Math.min(100, maximumRaw))
        : null;

      let percentage = Number(item && item.percentage);
      let valid =
        Number.isFinite(percentage) && percentage > 0 && percentage <= 100;

      // Defensa adicional: si el cliente de IA solo devolvió un rango
      // (percentage ausente o 0), se usa su punto medio. No se renormaliza
      // la composición ni se completa la fracción desconocida.
      if (
        !valid &&
        minimum !== null &&
        maximum !== null &&
        Math.max(minimum, maximum) > 0
      ) {
        percentage = (minimum + maximum) / 2;
        valid = percentage > 0 && percentage <= 100;
      }

      if (!valid) {
        unquantified.push(name);
        return;
      }

      quantified.push({
        name,
        percentage,
        percentageMin: minimum,
        percentageMax: maximum,
        confidence: normalizeText((item && item.confidence) || 'baja', 10),
        evidence: normalizeText(item && item.evidence, 240),
        declared: false,
        inferred: true,
        validPercentage: true
      });
    });

    if (quantified.length === 0) return null;

    const totalPercentage = round(
      quantified.reduce((total, material) => total + material.percentage, 0),
      2
    );

    if (totalPercentage > AI_MAX_TOTAL_PERCENTAGE) return null;

    const warnings = [];
    if (totalPercentage < 99.5) {
      warnings.push(
        `La composición inferida identifica ${totalPercentage}% del producto; el resto es desconocido.`
      );
    }

    const unknownFraction = Math.round(Math.max(0, 100 - totalPercentage) * 10) / 10;

    return {
      composition: {
        materials: quantified,
        totalPercentage,
        status: 'inferred',
        warnings,
        source: 'ai'
      },
      warnings,
      meta: {
        source: 'gemini',
        model: normalizeText(aiComposition.model, 60),
        productType: normalizeText(aiComposition.productType, 120),
        confidence: normalizeText(aiComposition.confidence || 'baja', 10),
        uncertainty: normalizeText(aiComposition.uncertainty, 300),
        reasoningSummary: normalizeText(aiComposition.reasoningSummary, 400),
        limitations: Array.isArray(aiComposition.limitations)
          ? aiComposition.limitations
              .map((item) => normalizeText(item, 200))
              .filter(Boolean)
              .slice(0, 5)
          : [],
        identifiedFraction: totalPercentage,
        unknownFraction,
        imageUsed: aiComposition.imageUsed === true,
        unquantifiedMaterials: unquantified
      }
    };
  }

  /**
   * Evalúa el potencial de reciclaje de los materiales declarados.
   * No afirma reciclabilidad efectiva: esta depende de la infraestructura
   * disponible y no se verificó para Colombia.
   */
  function evaluateRecyclability(materials = [], compositionStatus = 'missing') {
    const empty = {
      level: 'Información insuficiente',
      potential: 'unknown',
      score: 0,
      description:
        'Información insuficiente para evaluar la reciclabilidad. La publicación no declara una composición porcentual utilizable.',
      effectiveRecyclability: 'not_verified',
      localContextNote:
        'No se verificó la disponibilidad de infraestructura de reciclaje en Colombia.',
      mixed: false,
      materials: []
    };

    if (
      (compositionStatus !== 'complete' && compositionStatus !== 'inferred') ||
      !Array.isArray(materials) ||
      materials.length === 0
    ) {
      return empty;
    }

    const basedOnInferred = compositionStatus === 'inferred';

    const potentialWeights = { high: 0, medium: 0, low: 0, unknown: 0 };
    const breakdown = materials.map((material) => {
      const potential = material.recyclingPotential || 'unknown';
      potentialWeights[potential] =
        (potentialWeights[potential] || 0) + (material.percentage || 0);
      return {
        name: material.name,
        percentage: material.percentage,
        potential
      };
    });

    const total = Object.values(potentialWeights).reduce(
      (sum, value) => sum + value,
      0
    );

    if (total <= 0) return empty;

    const highShare = potentialWeights.high / total;
    const mediumShare = potentialWeights.medium / total;
    const lowShare = potentialWeights.low / total;

    let level = 'Potencialmente bajo';
    let potential = 'low';
    let score = Math.round((highShare + mediumShare * 0.5) * 100);

    if (highShare >= 0.5) {
      level = 'Potencialmente alto';
      potential = 'high';
    } else if (highShare + mediumShare >= 0.6) {
      level = 'Potencialmente medio';
      potential = 'medium';
    }

    const mixed = materials.length > 1;
    const mixedNote = mixed
      ? `Mezcla de ${materials.length} materiales: ${breakdown
          .map((item) => `${item.name} (${item.percentage}%)`)
          .join(', ')}. Las mezclas pueden reducir la reciclabilidad efectiva.`
      : '';

    const descriptions = {
      high:
        'Potencial de reciclaje alto a nivel de material. La reciclabilidad efectiva depende de la infraestructura local disponible y no está verificada.',
      medium:
        'Potencial de reciclaje medio a nivel de material. La reciclabilidad efectiva depende de la infraestructura local disponible y no está verificada.',
      low:
        'Potencial de reciclaje bajo o limitado a nivel de material. La reciclabilidad efectiva depende de la infraestructura local disponible y no está verificada.'
    };

    return {
      level,
      potential,
      basedOnInferred,
      score: Math.max(0, Math.min(100, score)),
      description: [
        descriptions[potential],
        basedOnInferred
          ? 'Clasificación basada en una composición inferida por IA, no declarada por el vendedor.'
          : '',
        mixedNote
      ]
        .filter(Boolean)
        .join(' '),
      effectiveRecyclability: 'not_verified',
      localContextNote:
        'No se afirma reciclabilidad efectiva en Colombia: no se verificó la infraestructura de recolección ni el procesamiento local.',
      mixed,
      shares: {
        high: round(highShare * 100, 1),
        medium: round(mediumShare * 100, 1),
        low: round(lowShare * 100, 1)
      },
      materials: breakdown
    };
  }

  const CAR_EQUIVALENCE_FACTOR = {
    kgCO2ePerKm: 0.192,
    source: 'provisional_unverified',
    note:
      'Factor pedagógico provisional para un automóvil de pasajeros; no es una medición del vehículo del usuario.'
  };

  function getEquivalence(co2e) {
    if (co2e === null || co2e === undefined || co2e === '') {
      return {
        icon: 'info',
        text: 'No disponible: se requiere una estimación válida.',
        km: null,
        factor: CAR_EQUIVALENCE_FACTOR.kgCO2ePerKm,
        source: CAR_EQUIVALENCE_FACTOR.source
      };
    }

    const value = Number(co2e);
    if (!Number.isFinite(value) || value < 0) {
      return {
        icon: 'info',
        text: 'No disponible: se requiere una estimación válida.',
        km: null,
        factor: CAR_EQUIVALENCE_FACTOR.kgCO2ePerKm,
        source: CAR_EQUIVALENCE_FACTOR.source
      };
    }

    const km = value / CAR_EQUIVALENCE_FACTOR.kgCO2ePerKm;

    return {
      icon: 'directions_car',
      text:
        `Equivalencia aproximada: ${formatNumber(km, 1)} km recorridos en un ` +
        'automóvil de pasajeros. Parámetro provisional, no una medición directa.',
      km: round(km, 1),
      factor: CAR_EQUIVALENCE_FACTOR.kgCO2ePerKm,
      source: CAR_EQUIVALENCE_FACTOR.source
    };
  }

  function classifyImpact(co2e) {
    if (!Number.isFinite(co2e)) {
      return { impactClass: 'unknown', impactLevel: 'Datos insuficientes' };
    }
    if (co2e < CLASSIFICATION_THRESHOLDS.lowMax) {
      return { impactClass: 'low', impactLevel: 'Bajo' };
    }
    if (co2e <= CLASSIFICATION_THRESHOLDS.mediumMax) {
      return { impactClass: 'medium', impactLevel: 'Medio' };
    }
    return { impactClass: 'high', impactLevel: 'Alto' };
  }

  function createUnavailableResult(status, reason, extra = {}) {
    return {
      available: false,
      status,
      reason,
      co2e: null,
      formattedCO2e: 'No disponible',
      impactClass: 'unknown',
      impactLevel: 'Datos insuficientes',
      equivalence: getEquivalence(null),
      materials: [],
      compositionStatus: 'unavailable',
      totalCompositionPercentage: 0,
      dataBasis: 'none',
      isPartialEstimate: false,
      knownPercentage: 0,
      unknownPercentage: 100,
      ai: null,
      co2eRange: null,
      declaredCompositionStatus: 'unavailable',
      weightKg: null,
      isWeightEstimated: true,
      weightEstimated: true,
      weightSource: 'not_available',
      weightMethod: METHODOLOGY.weightMethod,
      recyclability: evaluateRecyclability([], 'missing'),
      confidence: { level: 'ninguna', reasons: [reason] },
      verificationStatus: METHODOLOGY.verificationStatus,
      methodology: METHODOLOGY,
      methodologyLimitations: METHODOLOGY_LIMITATIONS,
      methodologyLimitationsList: METHODOLOGY_LIMITATIONS_LIST,
      assumptions: [],
      limitations: METHODOLOGY_LIMITATIONS_LIST,
      factorSource: FACTOR_SOURCE,
      factorVersion: FACTOR_VERSION,
      warnings: reason ? [reason] : [],
      ...extra
    };
  }

  /**
   * Calcula la estimación ambiental a partir de la composición declarada.
   *
   * No depende del precio y no aplica recargos fijos: cualquier proceso
   * adicional debe modelarse explícitamente como un término separado.
   */
  function calculateImpact(productData = {}) {
    try {
      const product =
        productData && typeof productData === 'object' ? productData : {};

      // Estimación por categoría (Fase 2 de datos): tiene prioridad para
      // categorías no basadas en composición material (vehículos, inmuebles,
      // servicios, alimentos) y para tecnología sin composición declarada.
      if (CategoryImpact) {
        const categoryEntry = CategoryImpact.resolveCategoryGroup(
          product.category,
          product.title
        );
        const categoryResult = CategoryImpact.calculateCategoryImpact(product);
        const specialGroups = [
          'mobility.automotive',
          'real_estate.buildings',
          'services.intangible',
          'food.grocery'
        ];
        if (categoryResult && categoryResult.available) {
          return categoryResult;
        }
        if (
          categoryEntry &&
          (specialGroups.includes(categoryEntry.group) ||
            ((categoryEntry.group === 'technology.mobile' ||
              categoryEntry.group === 'technology.computing') &&
              !(Array.isArray(product.materials) && product.materials.length > 0)))
        ) {
          if (categoryResult) return categoryResult;
        }
      }

      const declaredComposition = normalizeMaterials(product);
      const declaredStatus = declaredComposition.status;
      const inferred = normalizeInferredComposition(product.aiComposition);

      // Prioridad: composición declarada por el vendedor. Solo si no alcanza
      // el 100% (o es inválida/insuficiente) se usa la inferencia de IA.
      const useInference =
        declaredComposition.status !== 'complete' && inferred !== null;

      const composition = useInference
        ? inferred.composition
        : declaredComposition;
      const dataBasis = useInference ? 'ai_inferred' : 'declared';
      const aiMeta = useInference ? inferred.meta : null;
      const warnings = composition.warnings.slice();
      const additionalWarnings = useInference ? inferred.warnings : [];
      additionalWarnings.forEach((warning) => {
        if (warnings.indexOf(warning) === -1) warnings.push(warning);
      });

      if (composition.status === 'missing') {
        return createUnavailableResult(
          'composition_missing',
          'La publicación no declara composición porcentual de materiales; no se estima la huella.',
          { compositionStatus: 'missing', warnings }
        );
      }

      if (composition.status === 'unresolved') {
        return createUnavailableResult(
          'material_unsupported',
          'La publicación menciona porcentajes, pero no se reconoce un material con factor disponible.',
          { compositionStatus: 'unresolved', warnings }
        );
      }

      if (composition.status === 'incomplete') {
        return createUnavailableResult(
          'composition_incomplete',
          `La composición declarada suma ${composition.totalPercentage}% y no alcanza el 100%; no se estima la huella.`,
          {
            compositionStatus: 'incomplete',
            totalCompositionPercentage: composition.totalPercentage,
            warnings
          }
        );
      }

      if (composition.status === 'invalid') {
        return createUnavailableResult(
          'composition_invalid',
          'La composición declarada contiene porcentajes inválidos o supera el 100%; no se estima la huella.',
          {
            compositionStatus: 'invalid',
            totalCompositionPercentage: composition.totalPercentage,
            warnings
          }
        );
      }

      const resolvedAll = composition.materials.map((material) => {
        const factorData = resolveMaterialData(material.name);
        return {
          name: factorData.name || material.name,
          originalName: material.name,
          percentage: material.percentage,
          percentageMin:
            material.percentageMin !== undefined ? material.percentageMin : null,
          percentageMax:
            material.percentageMax !== undefined ? material.percentageMax : null,
          confidence: material.confidence || null,
          evidence: material.evidence || '',
          declared: material.declared !== false,
          inferred: material.inferred === true,
          rawKey: factorData.rawKey,
          factor: factorData.factor,
          color: factorData.color,
          recyclingPotential: factorData.recyclingPotential,
          factorSource: factorData.factorSource || FACTOR_SOURCE,
          factorScope: factorData.factorScope || FACTOR_SCOPE,
          factorVersion: factorData.factorVersion || FACTOR_VERSION,
          verifiedForColombia: factorData.verifiedForColombia === true
        };
      });

      const unsupported = resolvedAll.filter(
        (material) => !Number.isFinite(material.factor)
      );

      // En modo inferido, los materiales sin factor se excluyen y se advierte;
      // la estimación sigue siendo parcial y nunca se completa con valores
      // inventados. En modo declarado se mantiene el comportamiento estricto.
      const resolved =
        dataBasis === 'ai_inferred'
          ? resolvedAll.filter((material) => Number.isFinite(material.factor))
          : resolvedAll;

      if (resolved.length === 0) {
        return createUnavailableResult(
          'material_unsupported',
          `No hay factor de emisión documentado para: ${unsupported
            .map((material) => material.originalName)
            .join(', ')}. No se inventa un valor para completar la estimación.`,
          {
            compositionStatus: composition.status,
            totalCompositionPercentage: composition.totalPercentage,
            unsupportedMaterials: unsupported.map(
              (material) => material.originalName
            ),
            dataBasis,
            ai: aiMeta,
            warnings
          }
        );
      }

      if (dataBasis !== 'ai_inferred' && unsupported.length > 0) {
        return createUnavailableResult(
          'material_unsupported',
          `No hay factor de emisión para: ${unsupported
            .map((material) => material.originalName)
            .join(', ')}. No se inventa un valor para completar la estimación.`,
          {
            compositionStatus: composition.status,
            totalCompositionPercentage: composition.totalPercentage,
            unsupportedMaterials: unsupported.map(
              (material) => material.originalName
            ),
            dataBasis,
            warnings
          }
        );
      }

      if (unsupported.length > 0) {
        const unsupportedNames = unsupported.map(
          (material) => material.originalName
        );
        warnings.push(
          `Materiales inferidos sin factor documentado (excluidos del cálculo): ${unsupportedNames.join(
            ', '
          )}.`
        );
      }

      const knownPercentage = round(
        resolved.reduce((total, material) => total + material.percentage, 0),
        2
      );
      const isPartialEstimate =
        dataBasis === 'ai_inferred' && knownPercentage < 99.5;

      const weightDetails = estimateWeightDetails(
        product.title || '',
        product.category || '',
        product.weightKg != null ? product.weightKg : product.weight
      );

      const materials = resolved.map((material) => {
        const materialWeightKg =
          weightDetails.weightKg * (material.percentage / 100);
        const materialCO2e = materialWeightKg * material.factor;
        return {
          ...material,
          weightKg: round(materialWeightKg, 4),
          co2e: round(materialCO2e, 4)
        };
      });

      const co2e = round(
        materials.reduce((total, material) => total + material.co2e, 0),
        2
      );

      let co2eRange = null;
      if (dataBasis === 'ai_inferred') {
        const withRanges = resolved.filter(
          (material) =>
            Number.isFinite(material.percentageMin) &&
            Number.isFinite(material.percentageMax)
        );
        if (withRanges.length === resolved.length) {
          const minimum = round(
            resolved.reduce(
              (total, material) =>
                total +
                weightDetails.weightKg *
                  (material.percentageMin / 100) *
                  material.factor,
              0
            ),
            2
          );
          const maximum = round(
            resolved.reduce(
              (total, material) =>
                total +
                weightDetails.weightKg *
                  (material.percentageMax / 100) *
                  material.factor,
              0
            ),
            2
          );
          co2eRange = {
            min: minimum,
            max: maximum,
            label: `${formatNumber(minimum, 2)} – ${formatNumber(maximum, 2)}`
          };
        }
      }

      const classification = classifyImpact(co2e);
      const recyclability = evaluateRecyclability(
        materials,
        composition.status
      );

      const confidenceReasons = [
        'La composición proviene de la publicación y no fue auditada.',
        'El peso se estima por categoría y no lo declara el fabricante.',
        'Los factores de emisión son parámetros provisionales sin trazabilidad documental verificada.'
      ];

      if (dataBasis === 'ai_inferred') {
        confidenceReasons.unshift(
          'La composición fue inferida por IA a partir de datos parciales de la publicación.'
        );
        confidenceReasons.push(
          'Los porcentajes inferidos son aproximados y no fueron verificados por el vendedor.'
        );
        if (aiMeta && aiMeta.uncertainty) {
          confidenceReasons.push(`Incertidumbre declarada por la IA: ${aiMeta.uncertainty}`);
        }
      }

      if (weightDetails.isWeightEstimated === false) {
        confidenceReasons[1] = 'El peso fue declarado en la publicación.';
      }

      return {
        available: true,
        status: 'estimated',
        reason: '',
        co2e,
        formattedCO2e: formatNumber(co2e, 2),
        co2eRange,
        impactClass: classification.impactClass,
        impactLevel: classification.impactLevel,

        dataBasis,
        isPartialEstimate,
        knownPercentage,
        unknownPercentage: round(Math.max(0, 100 - knownPercentage), 2),
        ai: aiMeta,
        declaredCompositionStatus: declaredStatus,

        materials,
        compositionStatus: composition.status,
        compositionSource: composition.source,
        totalCompositionPercentage: composition.totalPercentage,

        weightKg: round(weightDetails.weightKg, 3),
        isWeightEstimated: weightDetails.isWeightEstimated,
        weightEstimated: weightDetails.isWeightEstimated,
        weightSource: weightDetails.weightSource,
        weightMethod: weightDetails.weightMethod,

        recyclability,
        equivalence: getEquivalence(co2e),

        confidence: {
          level: 'baja',
          reasons: confidenceReasons
        },
        verificationStatus: METHODOLOGY.verificationStatus,

        methodology: METHODOLOGY,
        methodologyLimitations: METHODOLOGY_LIMITATIONS,
        methodologyLimitationsList: METHODOLOGY_LIMITATIONS_LIST,
        assumptions:
          dataBasis === 'ai_inferred'
            ? [
                'La composición fue inferida por IA y no fue declarada ni verificada por el vendedor.',
                'La fracción no identificada no se contabiliza; la huella es parcial.',
                'Los porcentajes se aplican sobre el peso total estimado.',
                'Solo se modela la etapa de materiales de cuna a puerta.',
                'No se modelan transporte, fabricación, uso, empaque ni fin de vida.'
              ]
            : [
                'La composición declarada es correcta y representa todo el producto.',
                'Los porcentajes se aplican sobre el peso total estimado.',
                'Solo se modela la etapa de materiales de cuna a puerta.',
                'No se modelan transporte, fabricación, uso, empaque ni fin de vida.'
              ],
        limitations: METHODOLOGY_LIMITATIONS_LIST,

        factorSource: FACTOR_SOURCE,
        factorScope: FACTOR_SCOPE,
        factorVersion: FACTOR_VERSION,
        factorSourceNote: FACTOR_SOURCE_NOTE,

        warnings
      };
    } catch (error) {
      console.error('[VOLIUZ CO2] Error durante el cálculo:', error);
      return createUnavailableResult(
        'error',
        'No fue posible calcular la estimación con los datos disponibles.'
      );
    }
  }

  return {
    calculateImpact,
    normalizeMaterials,
    normalizeInferredComposition,
    parseCompositionText,
    evaluateRecyclability,
    getEquivalence,
    classifyImpact,
    estimateWeight,
    estimateWeightDetails,
    resolveMaterialData,
    formatNumber,
    round,
    EMISSION_FACTORS,
    METHODOLOGY,
    METHODOLOGY_LIMITATIONS,
    METHODOLOGY_LIMITATIONS_LIST,
    CLASSIFICATION_THRESHOLDS,
    FACTOR_SOURCE,
    FACTOR_SCOPE,
    FACTOR_VERSION,
    CATEGORY_WEIGHTS
  };
});
