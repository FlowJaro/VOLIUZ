
/**
 * VOLIUZ - Estimación ambiental por categoría (Fase 2 de datos).
 *
 * Contiene los factores de emisión, reglas físicas, parámetros de fase de
 * uso, tasas de fin de vida y el mapeo taxonómico Mercado Libre → grupo
 * ambiental, tal como se definieron en el informe técnico de factores.
 *
 * Principio metodológico (Regla de Oro):
 * - Solo se estima cuando existen los insumos mínimos de la categoría.
 * - Cada resultado cita fuente, alcance y margen de incertidumbre.
 * - Si falta un insumo, se devuelve "no disponible", nunca una cifra.
 * - Los valores son estimaciones preliminares, no LCA certificadas.
 */

(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.VoliuzCategoryImpact = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const VERSION = '1.0.0';
  const UPDATED_AT = '2026-11-16';

  // Factor de la red eléctrica colombiana (UPME / XM), kg CO2e/kWh.
  const GRID_FACTOR_CO = 0.126;

  /* -----------------------------------------------------------------------
     Tabla 1 - Factores de emisión por material/subcategoría (kg CO2e).
     ----------------------------------------------------------------------- */
  const EMISSION_FACTORS = [
    { group: 'technology', material: 'Plásticos Técnicos (ABS / Policarbonato)', factor: 3.82, unit: 'kg', scope: 'Cuna a Puerta', source: 'Ecoinvent v3.10 / ISO 14044', uncertainty: '± 8%' },
    { group: 'technology', material: 'Aluminio Primario (Chasis)', factor: 11.45, unit: 'kg', scope: 'Cuna a Puerta', source: 'ICE v3.0 / Ecoinvent v3.10', uncertainty: '± 12%' },
    { group: 'technology', material: 'Aluminio Reciclado (Secundario)', factor: 1.85, unit: 'kg', scope: 'Cuna a Puerta', source: 'ICE v3.0 / European Aluminium', uncertainty: '± 6%' },
    { group: 'technology', material: 'Cobre / Cableado interno', factor: 4.25, unit: 'kg', scope: 'Cuna a Puerta', source: 'Ecoinvent v3.10 / ICA', uncertainty: '± 10%' },
    { group: 'technology', material: 'Placa de Circuito Impreso (PCB multinivel)', factor: 28.50, unit: 'kg', scope: 'Cuna a Puerta', source: 'PEFCR IT Equipment / Ecoinvent', uncertainty: '± 15%' },
    { group: 'technology', material: 'Batería de Ión-Litio (NMC)', factor: 12.30, unit: 'kg', scope: 'Cuna a Puerta', source: 'Argonne GREET 2023 / ISO 14067', uncertainty: '± 14%' },

    { group: 'apparel', material: 'Algodón Convencional', factor: 4.55, unit: 'kg', scope: 'Cuna a Puerta', source: 'PEFCR Apparel & Footwear (2023)', uncertainty: '± 10%' },
    { group: 'apparel', material: 'Algodón Orgánico Certificado (GOTS)', factor: 1.80, unit: 'kg', scope: 'Cuna a Puerta', source: 'Textile Exchange / GOTS LCA', uncertainty: '± 9%' },
    { group: 'apparel', material: 'Poliéster Virgen (PET textil)', factor: 6.40, unit: 'kg', scope: 'Cuna a Puerta', source: 'PEFCR Apparel & Footwear / HIGG', uncertainty: '± 7%' },
    { group: 'apparel', material: 'Poliéster Reciclado (rPET)', factor: 2.15, unit: 'kg', scope: 'Cuna a Puerta', source: 'HIGG Materials Sustainability Index', uncertainty: '± 8%' },
    { group: 'apparel', material: 'Cuero Sintético (PU/PVC)', factor: 7.80, unit: 'kg', scope: 'Cuna a Puerta', source: 'Ecoinvent v3.10 / ISO 14040', uncertainty: '± 11%' },

    { group: 'personal_care', material: 'Formulación Cosmética Base Agua/Tensoactivo', factor: 0.85, unit: '100 ml', scope: 'Cuna a Puerta', source: 'PEFCR for Shampoos (Cosmetics Eur)', uncertainty: '± 6%' },
    { group: 'personal_care', material: 'Envase Plástico PET Virgen', factor: 3.12, unit: 'kg', scope: 'Cuna a Puerta', source: 'DEFRA/DESNZ 2024 / ISO 18602', uncertainty: '± 5%' },
    { group: 'personal_care', material: 'Envase Plástico PET Reciclado (100% PCR)', factor: 0.95, unit: 'kg', scope: 'Cuna a Puerta', source: 'APR / Plastics Recyclers Europe', uncertainty: '± 7%' },

    { group: 'home_cleaning', material: 'Detergente Líquido Concentrado', factor: 1.25, unit: 'dosis (50 ml)', scope: 'Cuna a Puerta', source: 'PEFCR Liquid Detergents / A.I.S.E.', uncertainty: '± 8%' },
    { group: 'home_cleaning', material: 'Empaque Flexible LDPE (Bolsa recarga)', factor: 2.45, unit: 'kg', scope: 'Cuna a Puerta', source: 'Flexible Packaging Europe / ISO 18604', uncertainty: '± 6%' },

    { group: 'baby', material: 'Pañal Desechable (Núcleo Mixto Pulpa/SAP)', factor: 0.12, unit: 'unidad', scope: 'Cuna a Tumba', source: 'EU Ecolabel Absorbent Hygiene (2023)', uncertainty: '± 9%' },
    { group: 'baby', material: 'Ropa de Bebé 100% Algodón OEKO-TEX', factor: 1.15, unit: 'prenda (~120 g)', scope: 'Cuna a Puerta', source: 'OEKO-TEX Standard 100 / PEFCR', uncertainty: '± 8%' },

    // Categorías especiales (valores por unidad funcional definidos en sección 6).
    { group: 'food', material: 'Granos / Cereales', factor: 1.2, unit: 'kg', scope: 'Cuna a Puerta', source: 'FAO GLEAM / IPCC AR6', uncertainty: '± 15%' },
    { group: 'food', material: 'Lácteos', factor: 3.2, unit: 'kg', scope: 'Cuna a Puerta', source: 'FAO GLEAM / IPCC AR6', uncertainty: '± 15%' },
    { group: 'food', material: 'Proteína animal', factor: 27.5, unit: 'kg', scope: 'Cuna a Puerta', source: 'FAO GLEAM / IPCC AR6', uncertainty: '± 20%' },
    { group: 'food', material: 'Empaque alimentario + cadena de frío', factor: 0.15, unit: 'factor adicional (+15% a +25%)', scope: 'Cuna a Puerta', source: 'FAO GLEAM / IPCC AR6', uncertainty: '± 5%' },

    { group: 'mobility', material: 'Fabricación vehículo térmico (medio)', factor: 7500, unit: 'kg CO2e/vehículo', scope: 'Cuna a Puerta', source: 'ISO 14067 / WLTP', uncertainty: '± 20%' },
    { group: 'mobility', material: 'Fabricación vehículo eléctrico', factor: 11800, unit: 'kg CO2e/vehículo', source: 'ISO 14067 / WLTP', uncertainty: '± 20%' },
    { group: 'mobility', material: 'Uso vehículo gasolina (160 g CO2/km)', factor: 0.16, unit: 'kg CO2e/km', scope: 'Uso', source: 'WLTP / UPME', uncertainty: '± 10%' },

    { group: 'real_estate', material: 'Carbono embebido estructural (concreto/acero)', factor: 435, unit: 'kg CO2e/m²', scope: 'Cuna a Puerta', source: 'ISO 21930 / Edge Building', uncertainty: '± 20%' },

    { group: 'services', material: 'Desplazamiento técnico', factor: 0.18, unit: 'kg CO2e/km', scope: 'Uso', source: 'GHG Protocol Scope 3', uncertainty: '± 15%' },
    { group: 'services', material: 'Consumo digital por hora', factor: 0.05, unit: 'kg CO2e/h', scope: 'Uso', source: 'GHG Protocol Scope 3', uncertainty: '± 20%' }
  ];

  /* -----------------------------------------------------------------------
     Tabla 2 - Reglas físicas promedio (masa/volumen) por subcategoría.
     ----------------------------------------------------------------------- */
  const PHYSICAL_RULES = [
    { group: 'technology', subtype: 'smartphone', massKg: 0.190, composition: { 'Aluminio Primario (Chasis)': 0.30, 'Vidrio': 0.25, 'Batería de Ión-Litio (NMC)': 0.20, 'Placa de Circuito Impreso (PCB multinivel)': 0.15, 'Plásticos Técnicos (ABS / Policarbonato)': 0.10 } },
    { group: 'technology', subtype: 'laptop', massKg: 1.450, composition: { 'Aluminio Primario (Chasis)': 0.45, 'Vidrio': 0.25, 'Batería de Ión-Litio (NMC)': 0.15, 'Placa de Circuito Impreso (PCB multinivel)': 0.15 } },
    { group: 'technology', subtype: 'desktop_pc', massKg: 7.500, composition: { 'Acero/Gabinete': 0.55, 'Cobre / Cableado interno': 0.20, 'Placa de Circuito Impreso (PCB multinivel)': 0.25 } },
    { group: 'apparel', subtype: 'tshirt', massKg: 0.180, composition: {} },
    { group: 'apparel', subtype: 'jeans', massKg: 0.620, composition: { 'Algodón Convencional': 0.98 } },
    { group: 'personal_care', subtype: 'shampoo', massKg: 0.420, volumeMl: 400, composition: {} },
    { group: 'home_cleaning', subtype: 'detergent', massKg: 1.050, volumeMl: 1000, composition: {} },
    { group: 'baby', subtype: 'diaper_pack', massKg: 1.600, units: 40, composition: {} }
  ];

  /* -----------------------------------------------------------------------
     Tabla 3 - Fase de uso (energía) para tecnología/electrodomésticos.
     ----------------------------------------------------------------------- */
  const USE_PHASE = [
    { type: 'smartphone', kwhPerYear: 6.5, lifetimeYears: 3.0 },
    { type: 'laptop', kwhPerYear: 32.0, lifetimeYears: 4.0 },
    { type: 'tv_55', kwhPerYear: 110.0, lifetimeYears: 6.0 },
    { type: 'refrigerator_300l', kwhPerYear: 280.0, lifetimeYears: 10.0 },
    { type: 'washer_top_15kg', kwhPerYear: 145.0, lifetimeYears: 8.0 }
  ];

  /* -----------------------------------------------------------------------
     Tabla 4 - Fin de vida / reciclabilidad efectiva.
     ----------------------------------------------------------------------- */
  const EOL_RATES = [
    { material: 'Aluminio y Metales Ferrosos', rate: 0.88, flow: 'Chatarra Metálica Reciclable', norm: 'Decreto 284 de 2018', level: 'high' },
    { material: 'Cobre y Cables Eléctricos', rate: 0.82, flow: 'Recuperación RAEE', norm: 'Ley 1672 de 2013 (RAEE)', level: 'high' },
    { material: 'Plástico PET / HDPE Botellas', rate: 0.65, flow: 'Cadena Recicladores de Oficio', norm: 'Res. 1407 de 2018 (Envases)', level: 'high' },
    { material: 'Vidrio Transparente', rate: 0.72, flow: 'Reciclaje de Vidrio Industrial', norm: 'Res. 1407 de 2018 (Envases)', level: 'high' },
    { material: 'Cartón y Papel Empaque', rate: 0.78, flow: 'Reciclaje de Pulpa y Papel', norm: 'Res. 1407 de 2018 (Envases)', level: 'high' },
    { material: 'Plásticos Técnicos (ABS/PC)', rate: 0.35, flow: 'Desmantelamiento RAEE Especializado', norm: 'Ley 1672 de 2013 (RAEE)', level: 'medium' },
    { material: 'Fibras Textiles Monomaterial', rate: 0.15, flow: 'Reciclaje Textil Mecánico', norm: 'Política Economía Circular', level: 'medium' },
    { material: 'Fibras Textiles Mezcladas', rate: 0.02, flow: 'Relleno Sanitario / Desecho', norm: 'Res. 2184 de 2019', level: 'low' },
    { material: 'Baterías de Litio', rate: 0.45, flow: 'Gestión Peligrosa Posconsumo', norm: 'Res. 1297 de 2010 (Pilas)', level: 'special' },
    { material: 'Plástico Flexible / Multicapa', rate: 0.08, flow: 'Rechazo / Relleno Sanitario', norm: 'Res. 1407 de 2018', level: 'low' }
  ];

  /* -----------------------------------------------------------------------
     Tabla 5 - Mapeo taxonómico Mercado Libre → grupo ambiental.
     ----------------------------------------------------------------------- */
  const CATEGORY_MAP = [
    { ml: 'Celulares y Telefonía', sub: 'Smartphones, Accesorios', group: 'technology.mobile', norm: 'EPEAT / Argonne GREET / RETIQ', fallback: 'Requiere masa y tipo de chasis; si no hay datos, aplica 0.19kg base.' },
    { ml: 'Computación', sub: 'Laptops, PC Escritorio', group: 'technology.computing', norm: 'PEFCR IT Equipment / ENERGY STAR', fallback: 'Requiere tipo de equipo; aplica consumo en uso estándar según clase.' },
    { ml: 'Electrodomésticos', sub: 'Refrigeración, Lavado, TV', group: 'appliances.home', norm: 'RETIQ Colombia / Ley 1715', fallback: 'Exige etiqueta RETIQ o potencia (W); de lo contrario, estado — / No disponible.' },
    { ml: 'Ropa y Accesorios', sub: 'Ropa Hombre/Mujer, Calzado', group: 'apparel.textiles', norm: 'PEFCR Apparel & Footwear / HIGG', fallback: 'Requiere composición % de fibras; si no suma ~100%, rechaza estimación.' },
    { ml: 'Belleza y Cuidado', sub: 'Champús, Cremas, Maquillaje', group: 'personal_care.beauty', norm: 'PEFCR for Shampoos / ISO 16128', fallback: 'Evalúa masa del envase y tipo de plástico (PET/HDPE/PCR).' },
    { ml: 'Hogar y Muebles', sub: 'Muebles interior/exterior', group: 'home.furniture', norm: 'ISO 14040 / PEFCR Furniture', fallback: 'Requiere material principal y masa.' },
    { ml: 'Hogar y Limpieza', sub: 'Detergentes, Limpiadores', group: 'home.cleaning', norm: 'PEFCR Liquid Detergents / ISO 18604', fallback: 'Evalúa volumen formulado y empaque flexible vs. rígido.' },
    { ml: 'Bebés', sub: 'Pañales, Ropa de Bebé', group: 'baby.childcare', norm: 'EU Ecolabel Hygiene / OEKO-TEX', fallback: 'Distingue entre textil de vestir y producto absorbente de celulosa.' },
    { ml: 'Alimentos y Bebidas', sub: 'Granos, Enlatados, Frescos', group: 'food.grocery', norm: 'FAO GLEAM / IPCC AR6', fallback: 'Requiere tipo de alimento y peso neto; aplica factor cuna a puerta por kg.' },
    { ml: 'Deportes y Fitness', sub: 'Ropa Deportiva, Equipos', group: 'sports.equipment', norm: 'HIGG MSI / ISO 14044', fallback: 'Clasifica en textil deportivo (sintético) o estructura metálica.' },
    { ml: 'Herramientas y Construcción', sub: 'Herramientas Eléctricas/Manuales', group: 'tools.hardware', norm: 'ISO 14040 / RoHS', fallback: 'Evalúa masa metálica y motor eléctrico en fase de uso.' },
    { ml: 'Juegos y Juguetes', sub: 'Juguetes Plásticos/Electrónicos', group: 'toys.plastics', norm: 'EN 71 / Ecoinvent ABS', fallback: 'Evalúa masa plástica (PVC/ABS) o presencia de componentes RAEE.' },
    { ml: 'Vehículos', sub: 'Carros, Motos, Repuestos', group: 'mobility.automotive', norm: 'ISO 14067 / WLTP', fallback: 'Evalúa enfoque híbrido (Fabricación + Emisión km recorridos).' },
    { ml: 'Inmuebles', sub: 'Venta/Arriendo Vivienda/Local', group: 'real_estate.buildings', norm: 'ISO 21930 / Edge Building', fallback: 'Evalúa m² construidos e intensidad energética operacional.' },
    { ml: 'Servicios', sub: 'Mantenimiento, Cursos, Servicios', group: 'services.intangible', norm: 'GHG Protocol Scope 3', fallback: 'Evalúa horas de servicio, insumos directos y transporte asociado.' },
    { ml: 'Supermercado', sub: 'Alimentos, bebidas, limpieza', group: 'food.grocery', norm: 'FAO GLEAM / IPCC AR6', fallback: 'Requiere tipo de alimento y peso neto.' }
  ];

  /* -----------------------------------------------------------------------
     Bibliografía (sección 7 del informe).
     ----------------------------------------------------------------------- */
  const BIBLIOGRAPHY = [
    'International Organization for Standardization. (2018). ISO 14067:2018. Carbon footprint of products. Ginebra.',
    'Comisión Europea. (2021). Recomendación (UE) 2021/2279. PEF. Diario Oficial UE.',
    'Ecoinvent Centre. (2023). Ecoinvent Database Version 3.10. Zurich.',
    'DEFRA / DESNZ. (2024). UK Government GHG Conversion Factors. Londres.',
    'IPCC. (2021). Sexto Informe de Evaluación (AR6).',
    'Universidad de Bath. (2019). Inventory of Carbon and Energy (ICE v3.0).',
    'Congreso de Colombia. (2013). Ley 1672 de 2013 (RAEE).',
    'Ministerio de Ambiente Colombia. (2018). Resolución 1407 de 2018 (Envases).',
    'Asociación OEKO-TEX. (2024). OEKO-TEX Standard 100.',
    'Cosmetics Europe. (2022). PEFCR for Liquid Soap, Shampoos and Hair Conditioners.'
  ];

  function normalizeText(value) {
    return String(value || '')
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .trim();
  }

  /**
   * Resuelve el grupo ambiental a partir de categoría y/o título.
   * Devuelve el objeto de mapeo o null.
   */
  function resolveCategoryGroup(category, title) {
    const haystack = normalizeText(`${category || ''} ${title || ''}`);
    if (!haystack) return null;

    // Coincidencia directa por nombre de categoría de Mercado Libre.
    for (const entry of CATEGORY_MAP) {
      const ml = normalizeText(entry.ml);
      if (haystack.includes(ml)) return entry;
    }

    // Coincidencia por palabras clave.
    const keywordMap = [
      { keys: ['celular', 'telefono', 'smartphone', 'iphone', 'android'], group: 'technology.mobile' },
      { keys: ['laptop', 'computador', 'pc', 'notebook', 'macbook'], group: 'technology.computing' },
      { keys: ['refrigerador', 'lavadora', 'televisor', 'aire acondicionado', 'electrodomestico', 'microondas', 'horno'], group: 'appliances.home' },
      { keys: ['camisa', 'pantalon', 'vestido', 'zapato', 'zapatilla', 'chaqueta', 'buzo', 'hoodie', 'ropa', 'textil', 'jean', 'blusa', 'falda', 'sudadera'], group: 'apparel.textiles' },
      { keys: ['champu', 'crema', 'maquillaje', 'perfume', 'cosmetico', 'jabon', 'acondicionador'], group: 'personal_care.beauty' },
      { keys: ['detergente', 'limpiador', 'desinfectante', 'cloro'], group: 'home.cleaning' },
      { keys: ['mueble', 'sofa', 'mesa', 'silla', 'cama', 'estanteria', 'decoracion', 'lampara', 'jardin'], group: 'home.furniture' },
      { keys: ['panal', 'bebe', 'infantil', 'coche', 'cuna', 'lactancia'], group: 'baby.childcare' },
      { keys: ['alimento', 'grano', 'arroz', 'frijol', 'lacteo', 'leche', 'carne', 'pollo', 'pescado', 'fruta', 'verdura', 'enlatado', 'bebida', 'supermercado', 'abarrotes'], group: 'food.grocery' },
      { keys: ['deporte', 'fitness', 'bicicleta', 'camping', 'pesca', 'futbol', 'gimnasio', 'musculacion', 'suplemento'], group: 'sports.equipment' },
      { keys: ['herramienta', 'taladro', 'martillo', 'sierra', 'plomeria', 'griferia', 'construccion', 'material de obra'], group: 'tools.hardware' },
      { keys: ['juguete', 'muneco', 'juego de mesa', 'coleccionable', 'hobby'], group: 'toys.plastics' },
      { keys: ['carro', 'moto', 'vehiculo', 'camioneta', 'embarcacion', 'aeronave', 'repuesto', 'accesorio auto'], group: 'mobility.automotive' },
      { keys: ['apartamento', 'casa', 'lote', 'oficina', 'local', 'inmueble', 'vivienda', 'arriendo', 'venta'], group: 'real_estate.buildings' },
      { keys: ['servicio', 'mantenimiento', 'clase', 'reparacion', 'oficio', 'curso'], group: 'services.intangible' }
    ];

    for (const { keys, group } of keywordMap) {
      if (keys.some((key) => haystack.includes(normalizeText(key)))) {
        return CATEGORY_MAP.find((entry) => entry.group === group) || { group };
      }
    }
    return null;
  }

  function formatNumber(value) {
    return Number.isFinite(value) ? value.toFixed(2).replace('.', ',') : '—';
  }

  function classifyImpact(co2e, weightKg) {
    // Clasificación por kg CO2e totales (consistente con el HUD existente).
    if (!Number.isFinite(co2e)) return { impactClass: 'unknown', impactLevel: 'Datos insuficientes' };
    if (co2e < 2) return { impactClass: 'low', impactLevel: 'Bajo' };
    if (co2e <= 4) return { impactClass: 'medium', impactLevel: 'Medio' };
    return { impactClass: 'high', impactLevel: 'Alto' };
  }

  function buildUnavailable(reason, group) {
    return {
      available: false,
      co2e: null,
      formattedCO2e: 'No disponible',
      impactClass: 'unknown',
      impactLevel: 'Datos insuficientes',
      materials: [],
      recyclability: { level: 'Información insuficiente', potential: 'unknown', description: reason, basedOnInferred: false, score: 0, localContextNote: 'Reciclabilidad efectiva local no verificada.' },
      weightKg: null,
      dataBasis: 'category_estimate',
      reason,
      equivalence: { icon: 'info', text: 'No se pudo estimar con los datos disponibles.' },
      isPartialEstimate: false,
      isWeightEstimated: false,
      compositionSource: 'category',
      categoryGroup: group || null,
      source: null,
      uncertainty: null,
      scope: null
    };
  }

  /**
   * Estimación para alimentos (food.grocery).
   * Requiere peso neto (kg) y, opcionalmente, tipo de alimento.
   */
  function estimateFood(product) {
    const weightKg = Number(product.netWeightKg || product.weightKg);
    if (!Number.isFinite(weightKg) || weightKg <= 0) {
      return buildUnavailable('Falta el peso neto del alimento para estimar la huella.', 'food.grocery');
    }
    const foodType = normalizeText(product.foodType || product.subcategory || product.title);
    let factorEntry = EMISSION_FACTORS.find((e) => e.group === 'food' && foodType.includes(normalizeText(e.material.split(' / ')[0])));
    if (!factorEntry) {
      if (foodType.includes('lact') || foodType.includes('leche') || foodType.includes('queso')) factorEntry = EMISSION_FACTORS.find((e) => e.material === 'Lácteos');
      else if (foodType.includes('carne') || foodType.includes('pollo') || foodType.includes('pescado') || foodType.includes('cerdo') || foodType.includes('res')) factorEntry = EMISSION_FACTORS.find((e) => e.material === 'Proteína animal');
      else factorEntry = EMISSION_FACTORS.find((e) => e.material === 'Granos / Cereales');
    }
    const coldChain = product.refrigerated === true || product.frozen === true;
    const packagingFactor = 0.15; // recargo por empaque + cadena de frío base
    const baseCo2e = weightKg * factorEntry.factor;
    const coldExtra = coldChain ? baseCo2e * 0.20 : 0;
    const packagingExtra = weightKg * packagingFactor;
    const co2e = baseCo2e + coldExtra + packagingExtra;
    const { impactClass, impactLevel } = classifyImpact(co2e, weightKg);
    return {
      available: true,
      co2e: Number(co2e.toFixed(4)),
      formattedCO2e: co2e.toFixed(2).replace('.', ','),
      impactClass,
      impactLevel,
      materials: [{ name: factorEntry.material, percentage: 100, color: '#8ccdff', factor: factorEntry.factor }],
      recyclability: { level: 'Potencial de reciclaje según empaque', potential: 'medium', description: 'La reciclabilidad efectiva depende del empaque y de la infraestructura local; no verificada.', basedOnInferred: false, score: 50, localContextNote: 'Reciclabilidad efectiva local no verificada.' },
      weightKg,
      dataBasis: 'category_estimate',
      reason: 'Estimación por categoría de alimento (FAO GLEAM / IPCC AR6).',
      equivalence: { icon: 'directions_car', text: `Equivale a ${(co2e / 0.12).toFixed(1).replace('.', ',')} km en automóvil.` },
      isPartialEstimate: true,
      isWeightEstimated: !Number.isFinite(Number(product.netWeightKg)),
      compositionSource: 'category',
      categoryGroup: 'food.grocery',
      source: factorEntry.source,
      uncertainty: factorEntry.uncertainty,
      scope: 'Cuna a Puerta (+ cadena de frío si aplica)',
      eol: null,
      inputs: { weightKg, foodType: factorEntry.material, coldChain }
    };
  }

  /**
   * Estimación para vehículos (mobility.automotive).
   * Requiere tipo (thermal/ev) y, opcionalmente, km recorridos.
   */
  function estimateMobility(product) {
    const vehicleType = normalizeText(product.vehicleType || product.fuelType || product.title);
    const isEV = vehicleType.includes('electric') || vehicleType.includes('electrico') || vehicleType.includes('ev');
    const manufacturing = isEV
      ? EMISSION_FACTORS.find((e) => e.material === 'Fabricación vehículo eléctrico').factor
      : EMISSION_FACTORS.find((e) => e.material === 'Fabricación vehículo térmico (medio)').factor;
    const km = Number(product.kmDriven || product.km || product.mileage);
    const usePhaseFactor = EMISSION_FACTORS.find((e) => e.material === 'Uso vehículo gasolina (160 g CO2/km)').factor;
    const usePhase = Number.isFinite(km) && km > 0 ? km * usePhaseFactor : 0;
    const co2e = manufacturing + usePhase;
    const { impactClass, impactLevel } = classifyImpact(co2e, null);
    return {
      available: true,
      co2e: Number(co2e.toFixed(2)),
      formattedCO2e: co2e.toFixed(2).replace('.', ','),
      impactClass: co2e > 10000 ? 'high' : impactClass,
      impactLevel: co2e > 10000 ? 'Alto' : impactLevel,
      materials: [
        { name: isEV ? 'Fabricación vehículo eléctrico' : 'Fabricación vehículo térmico (medio)', percentage: null, color: '#8ccdff', factor: manufacturing },
        ...(Number.isFinite(km) && km > 0 ? [{ name: 'Uso (combustible)', percentage: null, color: '#b8f000', factor: usePhaseFactor }] : [])
      ],
      recyclability: { level: 'Reciclabilidad según componentes', potential: 'medium', description: 'La reciclabilidad efectiva depende del desmontaje y de la gestión RAEE/metales; no verificada.', basedOnInferred: false, score: 50, localContextNote: 'Reciclabilidad efectiva local no verificada.' },
      weightKg: null,
      dataBasis: 'category_estimate',
      reason: Number.isFinite(km) && km > 0
        ? 'Estimación híbrida cuna a tumba (fabricación + uso).'
        : 'Solo fabricación embebida; falta kilometraje para la fase de uso.',
      equivalence: { icon: 'directions_car', text: Number.isFinite(km) && km > 0 ? `Incluye ${formatNumber(km)} km de uso.` : 'Falta kilometraje para la fase de uso.' },
      isPartialEstimate: !Number.isFinite(km) || km <= 0,
      isWeightEstimated: true,
      compositionSource: 'category',
      categoryGroup: 'mobility.automotive',
      source: 'ISO 14067 / WLTP',
      uncertainty: '± 20%',
      scope: 'Cuna a Tumba (fabricación + uso)',
      eol: null,
      inputs: { vehicleType: isEV ? 'eléctrico' : 'térmico', km: Number.isFinite(km) ? km : null }
    };
  }

  /**
   * Estimación para inmuebles (real_estate.buildings).
   * Requiere área (m²).
   */
  function estimateRealEstate(product) {
    const area = Number(product.areaM2 || product.area || product.squareMeters);
    if (!Number.isFinite(area) || area <= 0) {
      return buildUnavailable('Falta el área construida (m²) para estimar la huella.', 'real_estate.buildings');
    }
    const factorEntry = EMISSION_FACTORS.find((e) => e.material === 'Carbono embebido estructural (concreto/acero)');
    const embedded = area * factorEntry.factor;
    const annualKwhPerM2 = Number(product.energyIntensityKwhM2) || 100; // supuesto
    const operationalYears = Number(product.operationalYears) || 50;
    const operational = area * annualKwhPerM2 * operationalYears * GRID_FACTOR_CO;
    const co2e = embedded + operational;
    const { impactClass, impactLevel } = classifyImpact(co2e, null);
    return {
      available: true,
      co2e: Number(co2e.toFixed(2)),
      formattedCO2e: co2e.toFixed(2).replace('.', ','),
      impactClass: 'high',
      impactLevel: 'Alto',
      materials: [
        { name: 'Carbono embebido estructural', percentage: null, color: '#8ccdff', factor: factorEntry.factor },
        { name: 'Operación energética', percentage: null, color: '#b8f000', factor: annualKwhPerM2 * GRID_FACTOR_CO }
      ],
      recyclability: { level: 'Reciclabilidad según materiales', potential: 'medium', description: 'La reciclabilidad efectiva depende del diseño y de los flujos locales; no verificada.', basedOnInferred: false, score: 50, localContextNote: 'Reciclabilidad efectiva local no verificada.' },
      weightKg: null,
      dataBasis: 'category_estimate',
      reason: 'Estimación por m² construido + operación energética.',
      equivalence: { icon: 'info', text: `Área: ${area} m²; operación asumida ${operationalYears} años.` },
      isPartialEstimate: !Number.isFinite(Number(product.energyIntensityKwhM2)),
      isWeightEstimated: true,
      compositionSource: 'category',
      categoryGroup: 'real_estate.buildings',
      source: 'ISO 21930 / Edge Building',
      uncertainty: '± 20%',
      scope: 'Cuna a Puerta + Operación',
      eol: null,
      inputs: { areaM2: area, annualKwhPerM2, operationalYears }
    };
  }

  /**
   * Estimación para servicios (services.intangible).
   * Requiere horas de servicio o distancia de desplazamiento.
   */
  function estimateServices(product) {
    const hours = Number(product.serviceHours);
    const km = Number(product.travelKm);
    if ((!Number.isFinite(hours) || hours <= 0) && (!Number.isFinite(km) || km <= 0)) {
      return buildUnavailable('Falta duración del servicio (horas) o desplazamiento (km).', 'services.intangible');
    }
    const h = Number.isFinite(hours) && hours > 0 ? hours : 1;
    const travel = Number.isFinite(km) && km > 0 ? km * 0.18 : 0;
    const digital = h * 0.05;
    const consumables = Number(product.consumablesKg) > 0 ? Number(product.consumablesKg) * 1.0 : 0;
    const co2e = travel + digital + consumables;
    const { impactClass, impactLevel } = classifyImpact(co2e, null);
    return {
      available: true,
      co2e: Number(co2e.toFixed(4)),
      formattedCO2e: co2e.toFixed(2).replace('.', ','),
      impactClass,
      impactLevel,
      materials: [
        ...(Number.isFinite(km) && km > 0 ? [{ name: 'Desplazamiento técnico', percentage: null, color: '#8ccdff', factor: 0.18 }] : []),
        { name: 'Consumo digital', percentage: null, color: '#b8f000', factor: 0.05 },
        ...(consumables > 0 ? [{ name: 'Insumos consumibles', percentage: null, color: '#c3caad', factor: 1.0 }] : [])
      ],
      recyclability: { level: 'No aplicable', potential: 'unknown', description: 'Los servicios no generan residuo físico directo; el impacto proviene del desplazamiento y el consumo digital.', basedOnInferred: false, score: 0, localContextNote: 'Reciclabilidad efectiva local no verificada.' },
      weightKg: null,
      dataBasis: 'category_estimate',
      reason: 'Estimación por hora de servicio y desplazamiento.',
      equivalence: { icon: 'info', text: Number.isFinite(km) && km > 0 ? `Desplazamiento: ${km} km.` : 'Sin desplazamiento declarado.' },
      isPartialEstimate: !Number.isFinite(hours) || hours <= 0,
      isWeightEstimated: true,
      compositionSource: 'category',
      categoryGroup: 'services.intangible',
      source: 'GHG Protocol Scope 3',
      uncertainty: '± 20%',
      scope: 'Uso (servicio)',
      eol: null,
      inputs: { hours: Number.isFinite(hours) ? hours : null, travelKm: Number.isFinite(km) ? km : null }
    };
  }

  /**
   * Estimación para tecnología por composición de materiales (usa PHYSICAL_RULES).
   * Si el producto declara composición, se delega al calculador material;
   * aquí solo se aplica cuando hay un subtype reconocido y no hay composición.
   */
  function estimateTechnologyDefault(product) {
    const subtype = normalizeText(product.techSubtype || product.subcategory || '');
    let rule = PHYSICAL_RULES.find((r) => r.group === 'technology' && subtype.includes(r.subtype));
    if (!rule) {
      const title = normalizeText(product.title);
      if (title.includes('laptop') || title.includes('portatil') || title.includes('portátil')) rule = PHYSICAL_RULES.find((r) => r.subtype === 'laptop');
      else if (title.includes('pc') || title.includes('escritorio') || title.includes('torre')) rule = PHYSICAL_RULES.find((r) => r.subtype === 'desktop_pc');
      else rule = PHYSICAL_RULES.find((r) => r.subtype === 'smartphone');
    }
    if (!rule) return null;

    const massKg = Number(product.weightKg) > 0 ? Number(product.weightKg) : rule.massKg;
    let co2e = 0;
    const materials = [];
    Object.entries(rule.composition || {}).forEach(([mat, share]) => {
      const factorEntry = EMISSION_FACTORS.find((e) => e.material === mat || e.material.toLowerCase().includes(mat.toLowerCase()));
      const factor = factorEntry ? factorEntry.factor : 0;
      const mass = massKg * share;
      co2e += mass * factor;
      materials.push({ name: mat, percentage: Math.round(share * 100), color: '#8ccdff', factor, massKg: Number(mass.toFixed(4)) });
    });
    // Masa no cubierta por la composición -> plásticos técnicos.
    const coveredShare = Object.values(rule.composition || {}).reduce((a, b) => a + b, 0);
    if (coveredShare < 1) {
      const rest = massKg * (1 - coveredShare);
      const fe = EMISSION_FACTORS.find((e) => e.material === 'Plásticos Técnicos (ABS / Policarbonato)');
      co2e += rest * fe.factor;
      materials.push({ name: 'Plásticos Técnicos (ABS / Policarbonato)', percentage: Math.round((1 - coveredShare) * 100), color: '#353a40', factor: fe.factor, massKg: Number(rest.toFixed(4)) });
    }

    // Fase de uso.
    const useType = rule.subtype === 'smartphone' ? 'smartphone' : rule.subtype === 'laptop' ? 'laptop' : null;
    const useEntry = useType ? USE_PHASE.find((u) => u.type === useType) : null;
    const usePhaseCo2e = useEntry ? useEntry.kwhPerYear * useEntry.lifetimeYears * GRID_FACTOR_CO : 0;
    co2e += usePhaseCo2e;

    const { impactClass, impactLevel } = classifyImpact(co2e, massKg);
    return {
      available: true,
      co2e: Number(co2e.toFixed(2)),
      formattedCO2e: co2e.toFixed(2).replace('.', ','),
      impactClass,
      impactLevel,
      materials,
      recyclability: { level: 'Potencial de reciclaje según componentes', potential: 'medium', description: 'La reciclabilidad efectiva depende del desmontaje y de la gestión RAEE; no verificada.', basedOnInferred: false, score: 50, localContextNote: 'Reciclabilidad efectiva local no verificada.' },
      weightKg: massKg,
      dataBasis: 'category_estimate',
      reason: 'Estimación por composición típica del equipo + fase de uso (ENERGY STAR / EPEAT).',
      equivalence: { icon: 'directions_car', text: `Incluye ${usePhaseCo2e.toFixed(2).replace('.', ',')} kg CO₂e de uso.` },
      isPartialEstimate: true,
      isWeightEstimated: !Number.isFinite(Number(product.weightKg)),
      compositionSource: 'category',
      categoryGroup: 'technology.' + (rule.subtype === 'smartphone' ? 'mobile' : 'computing'),
      source: 'PEFCR IT Equipment / Ecoinvent / ENERGY STAR',
      uncertainty: '± 15%',
      scope: 'Cuna a Puerta + Uso',
      eol: null,
      inputs: { subtype: rule.subtype, massKg, usePhaseCo2e }
    };
  }

  /**
   * Punto de entrada. Devuelve un resultado compatible con co2Calculator
   * o null si la categoría no tiene una ruta de estimación por categoría.
   */
  function calculateCategoryImpact(productData) {
    const product = productData && typeof productData === 'object' ? productData : {};
    const entry = resolveCategoryGroup(product.category, product.title);
    const group = entry ? entry.group : null;
    if (!group) return null;

    // Categorías con ruta específica.
    if (group === 'food.grocery') return estimateFood(product);
    if (group === 'mobility.automotive') return estimateMobility(product);
    if (group === 'real_estate.buildings') return estimateRealEstate(product);
    if (group === 'services.intangible') return estimateServices(product);

    // Tecnología: solo si NO hay composición declarada (la material tiene prioridad).
    const hasComposition = Array.isArray(product.materials) && product.materials.length > 0;
    if ((group === 'technology.mobile' || group === 'technology.computing') && !hasComposition) {
      return estimateTechnologyDefault(product);
    }

    // Otras categorías: no hay ruta de estimación por categoría todavía;
    // se deja al calculador material (si hay composición) o a "no disponible".
    return null;
  }

  return {
    VERSION,
    UPDATED_AT,
    GRID_FACTOR_CO,
    EMISSION_FACTORS,
    PHYSICAL_RULES,
    USE_PHASE,
    EOL_RATES,
    CATEGORY_MAP,
    BIBLIOGRAPHY,
    resolveCategoryGroup,
    calculateCategoryImpact
  };
});
