/**
 * VOLIUZ - Cliente del servicio backend (backendClient.js)
 *
 * El backend es un componente OPCIONAL de Fase 2 que permite mantener la clave
 * de Gemini fuera del equipo del usuario final. Cuando no se configura una URL,
 * la extensión sigue usando el cliente directo de Gemini.
 *
 * Contrato esperado:
 *   POST {baseUrl}/api/ai/analyze -> { success, data }
 *   POST {baseUrl}/api/ai/chat    -> { success, data }
 *   GET  {baseUrl}/health         -> { status, configured, model }
 *
 * Este módulo se ejecuta en el service worker. No recibe ni manipula claves.
 */

(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.VoliuzBackendClient = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const DEFAULT_TIMEOUT_MS = 22000;
  const MAX_RESPONSE_LENGTH = 20000;

  function fail(code, message) {
    return { ok: false, error: { code, message } };
  }

  function normalizeBaseUrl(value) {
    const raw = String(value == null ? '' : value).trim();
    if (!raw) return '';

    try {
      const url = new URL(raw);
      if (url.protocol !== 'http:' && url.protocol !== 'https:') return '';
      if (url.username || url.password) return '';
      url.hash = '';
      url.search = '';
      return url.href.replace(/\/+$/, '');
    } catch (error) {
      return '';
    }
  }

  function errorFromPayload(status, payload) {
    const detail =
      payload && payload.error && typeof payload.error === 'object'
        ? payload.error
        : {};
    const code = String(detail.code || '').trim();
    const message = String(detail.message || '').trim();

    if (code) {
      return fail(code, message || 'El servicio backend rechazó la solicitud.');
    }

    if (status === 401 || status === 403) {
      return fail('invalid_api_key', 'El servicio backend rechazó la credencial de Gemini.');
    }
    if (status === 429) {
      return fail('quota_exceeded', 'Se alcanzó el límite de solicitudes del servicio backend.');
    }
    if (status === 400 || status === 422) {
      return fail('invalid_request', message || 'El servicio backend rechazó los datos enviados.');
    }
    if (status === 503) {
      return fail('service_unavailable', 'El servicio backend no está configurado o no está disponible.');
    }
    if (status >= 500) {
      return fail('service_unavailable', 'El servicio backend no está disponible en este momento.');
    }
    return fail('api_error', message || `Error HTTP ${status} del servicio backend.`);
  }

  async function requestJson(options = {}) {
    const baseUrl = normalizeBaseUrl(options.backendUrl);
    if (!baseUrl) {
      return fail(
        'missing_backend_url',
        'No hay una URL de backend válida configurada.'
      );
    }

    const path = String(options.path || '');
    if (!path.startsWith('/')) {
      return fail('invalid_request', 'La ruta del backend no es válida.');
    }

    const fetchImpl =
      options.fetchImpl || (typeof fetch === 'function' ? fetch : null);
    if (!fetchImpl) {
      return fail('network_unavailable', 'No hay acceso de red disponible.');
    }

    const timeoutMs =
      Number(options.timeoutMs) > 0 ? Number(options.timeoutMs) : DEFAULT_TIMEOUT_MS;
    const controller =
      typeof AbortController === 'function' ? new AbortController() : null;
    const timer =
      controller && typeof setTimeout === 'function'
        ? setTimeout(() => controller.abort(), timeoutMs)
        : null;

    const method = String(options.method || 'POST').toUpperCase();
    const hasBody = method !== 'GET' && method !== 'HEAD';

    try {
      const response = await fetchImpl(`${baseUrl}${path}`, {
        method,
        headers: hasBody ? { 'Content-Type': 'application/json' } : undefined,
        body: hasBody ? JSON.stringify(options.payload || {}) : undefined,
        signal: controller ? controller.signal : undefined,
      });

      if (!response || typeof response.status !== 'number') {
        return fail('invalid_response', 'El backend devolvió una respuesta no procesable.');
      }

      let payload = null;
      try {
        payload = await response.json();
      } catch (error) {
        payload = null;
      }

      if (!response.ok) {
        return errorFromPayload(response.status, payload);
      }

      if (!payload || typeof payload !== 'object' || payload.success !== true) {
        return errorFromPayload(response.status, payload);
      }

      return { ok: true, data: payload.data || payload };
    } catch (error) {
      const aborted = error && error.name === 'AbortError';
      return fail(
        aborted ? 'timeout' : 'network_error',
        aborted
          ? 'El servicio backend no respondió dentro del tiempo límite.'
          : 'No fue posible conectar con el servicio backend.'
      );
    } finally {
      if (timer) clearTimeout(timer);
    }
  }

  function validateInferenceData(data) {
    if (!data || typeof data !== 'object' || Array.isArray(data)) return null;
    if (!Array.isArray(data.materials) || data.materials.length === 0) return null;
    if (data.status !== 'inferred') return null;

    const materials = data.materials
      .filter((material) => material && typeof material.name === 'string')
      .slice(0, 12)
      .map((material) => ({
        name: String(material.name).slice(0, 60),
        percentage:
          Number.isFinite(Number(material.percentage))
            ? Number(material.percentage)
            : null,
        percentageMin: Number.isFinite(Number(material.percentageMin))
          ? Number(material.percentageMin)
          : null,
        percentageMax: Number.isFinite(Number(material.percentageMax))
          ? Number(material.percentageMax)
          : null,
        confidence: ['alta', 'media', 'baja'].includes(material.confidence)
          ? material.confidence
          : 'baja',
        evidence: String(material.evidence || '').slice(0, 240),
        declared: false,
        inferred: true,
      }));

    if (materials.length === 0) return null;

    return {
      status: 'inferred',
      source: 'backend_gemini',
      model: String(data.model || '').slice(0, 60),
      productType: String(data.productType || '').slice(0, 120),
      materials,
      identifiedFraction: Number.isFinite(Number(data.identifiedFraction))
        ? Number(data.identifiedFraction)
        : materials.reduce((total, material) => total + (material.percentage || 0), 0),
      unknownFraction: Number.isFinite(Number(data.unknownFraction))
        ? Number(data.unknownFraction)
        : null,
      confidence: ['alta', 'media', 'baja'].includes(data.confidence)
        ? data.confidence
        : 'baja',
      uncertainty: String(data.uncertainty || '').slice(0, 300),
      reasoningSummary: String(data.reasoningSummary || '').slice(0, 400),
      limitations: Array.isArray(data.limitations)
        ? data.limitations.map((item) => String(item).slice(0, 200)).slice(0, 5)
        : [],
      imageUsed: false,
      generatedAt: String(data.generatedAt || new Date().toISOString()).slice(0, 40),
    };
  }

  async function analyze(options = {}) {
    const result = await requestJson({
      backendUrl: options.backendUrl,
      path: '/api/ai/analyze',
      payload: { product: options.product || {} },
      timeoutMs: options.timeoutMs,
      fetchImpl: options.fetchImpl,
    });

    if (!result.ok) return result;

    const inference = validateInferenceData(result.data);
    if (!inference) {
      return fail('invalid_response', 'El backend devolvió una composición no utilizable.');
    }

    return { ok: true, data: inference };
  }

  async function chat(options = {}) {
    const result = await requestJson({
      backendUrl: options.backendUrl,
      path: '/api/ai/chat',
      payload: {
        product: options.product || {},
        impact: options.impact || {},
        knowledgeContext: String(options.knowledgeContext || '').slice(
          0,
          MAX_RESPONSE_LENGTH
        ),
        history: Array.isArray(options.history) ? options.history.slice(-8) : [],
        question: String(options.question || '').slice(0, 500),
      },
      timeoutMs: options.timeoutMs,
      fetchImpl: options.fetchImpl,
    });

    if (!result.ok) return result;

    const answer = String(
      result.data && (result.data.answer || result.data.text)
        ? result.data.answer || result.data.text
        : ''
    )
      .replace(/<[^>]*>/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, 4000);

    if (!answer) {
      return fail('empty_response', 'El backend no devolvió una respuesta utilizable.');
    }

    return {
      ok: true,
      data: {
        answer,
        model: String((result.data && result.data.model) || '').slice(0, 60),
        generatedAt: String(
          (result.data && result.data.generatedAt) || new Date().toISOString()
        ).slice(0, 40),
      },
    };
  }

  async function health(options = {}) {
    const result = await requestJson({
      backendUrl: options.backendUrl,
      path: '/health',
      method: 'GET',
      timeoutMs: options.timeoutMs || 5000,
      fetchImpl: options.fetchImpl,
    });

    if (!result.ok) return result;

    return {
      ok: true,
      data: {
        status: String(result.data.status || 'unknown').slice(0, 20),
        configured: result.data.configured === true,
        model: String(result.data.model || '').slice(0, 60),
      },
    };
  }

  return {
    DEFAULT_TIMEOUT_MS,
    normalizeBaseUrl,
    requestJson,
    validateInferenceData,
    analyze,
    chat,
    health,
  };
});
