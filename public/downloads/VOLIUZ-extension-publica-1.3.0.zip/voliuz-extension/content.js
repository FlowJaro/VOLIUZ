/**
 * VOLIUZ - Content Script Principal (content.js)
 * Orquestador en el cliente: Web Scraping, cálculo ambiental, recomendación
 * e inyección del panel lateral telemétrico (HUD) mediante Shadow DOM.
 */

(function () {
  "use strict";

  // Evitar inyecciones duplicadas
  if (window.__VOLIUZ_CONTENT_INJECTED__) return;
  window.__VOLIUZ_CONTENT_INJECTED__ = true;

  console.log("[VOLIUZ] Script inyectado con éxito en:", window.location.href);

  let hostElement = null;
  let shadowRoot = null;
  let currentProductData = null;
  let currentImpactData = null;
  let currentAlternativeData = null;
  let isPanelOpen = true;
  let extensionEnabled = true;
  let currentTheme = "light";
  let moduleRetryCount = 0;
  const MAX_MODULE_RETRIES = 10;

  // Web pública de VOLIUZ. Se enlaza desde el logo y desde la
  // sección de alternativas; no sustituye al catálogo verificado.
  const VOLIUZ_WEB_URL = "https://voliuz-puce.vercel.app/";

  // Ciclo de vida de la navegación SPA.
  const INITIAL_ANALYSIS_DELAY = 500;
  const SPA_SETTLE_DELAY = 700;
  let eventController = null;
  let analysisTimer = null;
  let retryTimer = null;
  let lastUrl = window.location.href;
  let extractionRetryCount = 0;
  const MAX_EXTRACTION_RETRIES = 5;

  // Estado de la inferencia con IA (Gemini). La clave nunca vive aquí:
  // el content script solo envía datos del producto al service worker.
  const aiCache = new Map();
  let aiRequestKey = null;
  let aiRequestInFlight = false;

  // Estado del chat. Vive fuera del Shadow DOM porque renderHUD reconstruye
  // el árbol en cada actualización de IA. No se persiste en storage.
  const MAX_CHAT_MESSAGES = 24;
  const chatState = {
    productSignature: "",
    messages: [],
    status: "idle",
    error: null,
  };

  const CHAT_SUGGESTIONS = [
    "¿Qué significa el valor de CO₂e de este producto?",
    "¿Qué materiales son más reciclables aquí?",
    "¿Por qué la estimación es preliminar?",
    "¿Cómo puedo reducir el impacto de este producto?",
  ];

  /**
 * Escapa caracteres especiales para evitar que datos externos
 * se interpreten como código HTML.
 */
function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, (character) => {
    const entities = {
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;",
    };

    return entities[character];
  });
}

/**
 * Acepta únicamente direcciones de imagen HTTP o HTTPS.
 */
function safeImageURL(value) {
  try {
    const rawValue = String(value ?? "").trim();
    const isRelativePath = /^(?:\.{1,2}\/|\/)/.test(rawValue);
    const url = new URL(rawValue, window.location.origin);

    if (
      url.protocol === "https:" ||
      (isRelativePath &&
        window.location.protocol === "https:" &&
        url.origin === window.location.origin)
    ) {
      return url.href;
    }
  } catch (error) {
    console.warn("[VOLIUZ] URL de imagen no válida.");
  }

  return "";
}

function safeColor(value, fallback = "#8ccdff") {
  return /^#[0-9a-f]{3,8}$/i.test(String(value || "")) ? value : fallback;
}

/**
 * Paleta equivalente para el tema oscuro.
 *
 * Los grises y verdes oscuros del tema claro se pierden sobre el fondo
 * oscuro del HUD. Cada material conserva su identidad cromática, pero
 * con luminosidad suficiente para leerse en la gráfica.
 */
const DARK_MATERIAL_COLORS = {
  "#353a40": "#a7b6c6",
  "#434933": "#b9c493",
  "#c3caad": "#d9dfc2",
  "#dee3eb": "#eef2f8",
  "#10b981": "#34d399",
  "#8ccdff": "#8ccdff",
  "#b8f000": "#d4ff4d",
};

function darkMaterialColor(value) {
  const color = safeColor(value).toLowerCase();
  return DARK_MATERIAL_COLORS[color] || safeColor(value);
}

function safePercentage(value) {
  const percentage = Number(value);
  return Number.isFinite(percentage) && percentage >= 0 && percentage <= 100
    ? Math.round(percentage)
    : 0;
}

function safeClass(value, allowed, fallback = "") {
  return allowed.includes(value) ? value : fallback;
}

function plainText(value) {
  return String(value ?? "").replace(/<[^>]*>/g, "");
}

  /**
   * Iconos SVG inline. Se evita depender de una fuente de iconos externa
   * para que ningún nombre de icono pueda mostrarse como texto.
   */
  const ICON_PATHS = {
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5"/><path d="M12 8h.01"/>',
    close: '<path d="M18 6 6 18M6 6l12 12"/>',
    chevron_right: '<path d="m9 18 6-6-6-6"/>',
    storefront:
      '<path d="M3 9l1.5-5h15L21 9"/><path d="M3 9h18v2a3 3 0 0 1-6 0 3 3 0 0 1-6 0 3 3 0 0 1-6 0V9z"/><path d="M5 13v7h14v-7"/>',
    check_circle:
      '<circle cx="12" cy="12" r="9"/><path d="m8.5 12.5 2.5 2.5 4.5-5"/>',
    warning:
      '<path d="M12 3 21 20H3L12 3z"/><path d="M12 9v5"/><path d="M12 17h.01"/>',
    error:
      '<circle cx="12" cy="12" r="9"/><path d="m9 9 6 6M15 9l-6 6"/>',
    eco:
      '<path d="M20 4c-8 0-14 5-14 12 0 2 1 4 1 4"/><path d="M7 16c4-1 7-4 9-8"/><path d="M20 4c0 8-5 12-12 12"/>',
    layers:
      '<path d="m12 3 9 5-9 5-9-5 9-5z"/><path d="m3 12 9 5 9-5"/><path d="m3 16 9 5 9-5"/>',
    autorenew:
      '<path d="m17 2 4 4-4 4"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><path d="m7 22-4-4 4-4"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/>',
    verified:
      '<path d="M12 2l2.4 2.4 3.4-.4.9 3.3 3 1.7-1.5 3.1 1.5 3.1-3 1.7-.9 3.3-3.4-.4L12 22l-2.4-2.4-3.4.4-.9-3.3-3-1.7 1.5-3.1L2.3 8.8l3-1.7.9-3.3 3.4.4L12 2z"/><path d="m8.5 12.5 2.5 2.5 4.5-5"/>',
    directions_car:
      '<path d="M4 17V11l2-6h12l2 6v6"/><path d="M5 17h14"/><circle cx="7.5" cy="17.5" r="1.5"/><circle cx="16.5" cy="17.5" r="1.5"/><path d="M6 11h12"/>',
    arrow_forward: '<path d="M5 12h14"/><path d="m13 6 6 6-6 6"/>',
    open_in_new: '<path d="M14 3h7v7"/><path d="M10 14 21 3"/><path d="M21 14v5a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5"/>',
    sparkles: '<path d="M12 2l1.5 4.5L18 9l-3 3.5L13.5 15 12 14l-1.5 1L6 15l-1.5-1L3 9l4.5-3.5L10.5 6.5 12 2z"/><path d="M12 14l-1.5-1L6 15l-1.5-1L3 9l4.5-3.5L10.5 6.5 12 2z"/><path d="M12 6l-1.5 4.5L18 9l-3 3.5L13.5 15z"/><path d="M12 12l1.5 4.5L18 9l-3 3.5L13.5 15z"/>',
    inventory:
      '<path d="M8 6h13M8 12h13M8 18h13"/><path d="M3 6h.01M3 12h.01M3 18h.01"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/>',
    moon: '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>'
  };

  function icon(name, className = "", size = 16) {
    const key = Object.prototype.hasOwnProperty.call(ICON_PATHS, name)
      ? name
      : "info";
    return `<svg class="voliuz-icon ${className}" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${ICON_PATHS[key]}</svg>`;
  }

  const EXTRACTION_STATUS = {
    complete: { label: "Datos completos", icon: "check_circle", className: "complete" },
    partial: { label: "Datos parciales", icon: "warning", className: "partial" },
    insufficient: { label: "Datos insuficientes", icon: "warning", className: "insufficient" },
    error: { label: "Error de extracción", icon: "error", className: "error" },
    no_product_page: { label: "Sin ficha de producto", icon: "info", className: "unknown" }
  };

  const FIELD_LABELS = {
    title: "título",
    price: "precio",
    category: "categoría",
    image: "imagen",
    materials: "composición"
  };

  const SOURCE_LABELS = {
    dom: "DOM",
    json_ld: "JSON-LD",
    meta: "metadatos",
    breadcrumb: "migaja de navegación",
    default_domain: "dominio del sitio",
    platform_default: "plataforma",
    ficha_tecnica: "ficha técnica",
    descripcion: "descripción",
    no_disponible: "no disponible",
    not_available: "no disponible"
  };

  function sourceLabel(value) {
    return SOURCE_LABELS[value] || "no disponible";
  }

  function extractionInfo(product) {
    const base =
      EXTRACTION_STATUS[product.extractionStatus] || EXTRACTION_STATUS.insufficient;
    const missingEnvironmental = Array.isArray(product.missingEnvironmentalFields)
      ? product.missingEnvironmentalFields
      : [];

    // Tener todos los campos generales no equivale a tener composición:
    // si falta la información ambiental, el estado global es parcial.
    if (
      product.extractionStatus === "complete" &&
      missingEnvironmental.length > 0
    ) {
      return {
        ...base,
        label: "Datos parciales",
        icon: "warning",
        className: "partial",
      };
    }

    return base;
  }

  function renderExtractionNotice(product) {
    const info = extractionInfo(product);
    const missingGeneral = Array.isArray(product.missingGeneralFields)
      ? product.missingGeneralFields
      : [];
    const missingEnvironmental = Array.isArray(product.missingEnvironmentalFields)
      ? product.missingEnvironmentalFields
      : [];

    if (product.extractionStatus === "complete" && missingEnvironmental.length === 0) {
      return `
        <div class="voliuz-data-note ok">
          ${icon("check_circle", "note-icon")}
          <span>Datos generales y composición declarada disponibles.</span>
        </div>
      `;
    }

    const details = [];

    if (missingGeneral.length > 0) {
      details.push(
        `Campos generales no encontrados: ${missingGeneral
          .map((field) => escapeHTML(FIELD_LABELS[field] || field))
          .join(", ")}.`
      );
    } else if (product.extractionStatus !== "complete") {
      details.push(escapeHTML(product.extractionStatusReason || info.label));
    }

    if (missingEnvironmental.length > 0) {
      details.push(
        escapeHTML(
          product.environmentalDataReason ||
            "No se encontró composición porcentual utilizable."
        )
      );
    }

    if (details.length === 0) return "";

    // Una extracción general completa puede convivir con composición
    // ausente; en ese caso la nota debe advertir, no mostrarse como éxito.
    const noteClass =
      product.extractionStatus === "error"
        ? "error"
        : product.extractionStatus === "insufficient"
          ? "insufficient"
          : missingGeneral.length > 0 || missingEnvironmental.length > 0
            ? "partial"
            : info.className;

    return `
      <div class="voliuz-data-note ${escapeHTML(noteClass)}">
        ${icon(info.icon, "note-icon")}
        <span>${details.join(" ")}</span>
      </div>
    `;
  }

  /**
   * Renderiza las rutas externas de búsqueda y sustitución.
   *
   * Son enlaces reales a plataformas y organizaciones ambientales.
   * No se presentan como alternativas verificadas ni como reducciones
   * cuantificadas; el catálogo verificado sigue vacío.
   */
  function renderAlternativeRoutes(alt) {
    const routes =
      alt && Array.isArray(alt.routes)
        ? alt.routes.filter(
          (route) =>
            route &&
            typeof route.url === "string" &&
            /^https?:\/\//i.test(route.url),
        )
        : [];

    const strategies =
      alt && Array.isArray(alt.strategies)
        ? alt.strategies.filter(
          (strategy) => typeof strategy === "string" && strategy.trim() !== "",
        )
        : [];

    if (routes.length === 0 && strategies.length === 0 && !alt) {
      return "";
    }

    const strategiesHtml =
      strategies.length > 0
        ? `
      <ul class="voliuz-alt-strategies">
        ${strategies
          .map((strategy) => `<li>${escapeHTML(strategy)}</li>`)
          .join("")}
      </ul>
    `
        : "";

    const routesHtml = routes
      .map(
        (route) => `
      <li class="voliuz-alt-route">
        <a class="voliuz-alt-route-link" href="${escapeHTML(route.url)}" target="_blank" rel="noopener noreferrer">
          <span class="voliuz-alt-route-label">
            <span>${escapeHTML(route.label || "Ruta externa")}</span>
            ${icon("open_in_new", "alt-route-external", 11)}
          </span>
          <span class="voliuz-alt-route-source">${escapeHTML(route.source || "Fuente externa")}</span>
          <span class="voliuz-alt-route-desc">${escapeHTML(route.description || "")}</span>
          ${route.note ? `<span class="voliuz-alt-route-note">${escapeHTML(route.note)}</span>` : ""}
        </a>
      </li>
    `,
      )
      .join("");

    return `
      <div class="voliuz-alt-routes">
        <div class="voliuz-alt-routes-head">
          ${icon("open_in_new", "alt-routes-icon", 13)}
          <span>Rutas externas de menor impacto</span>
          <span class="voliuz-cert-badge">Fuera de VOLIUZ</span>
        </div>
        <p class="voliuz-alt-routes-note">
          Enlaces a plataformas y organizaciones ambientales. No son productos
          verificados por VOLIUZ ni implican una reducción cuantificada.
        </p>
        ${strategiesHtml}
        <ul class="voliuz-alt-route-list">${routesHtml}</ul>
      </div>
    `;
  }

  function renderAlternativeSection(alt) {
    const hasVerified =
      alt && alt.hasAlternative === true && alt.comparisonAvailable === true;
    const routesHtml = renderAlternativeRoutes(alt);

    if (!hasVerified) {
      // Sugerencia generada por IA: mostrar categorías de alternativa,
      // materiales, certificaciones y plataformas donde buscar.
      const aiAltAction = `
        ${alt && alt.aiSuggestionError
          ? `<p class="voliuz-alt-ai-error">${icon("warning", "note-icon", 12)} ${escapeHTML(aiErrorMessage(alt.aiSuggestionError))}</p>`
          : ""}
        <div class="voliuz-alt-ai-action">
          <button class="voliuz-ai-retry" id="vz-ai-alt-retry" type="button">
            ${icon("sparkles", "ai-retry-icon", 13)}
            <span>${alt && alt.aiSuggestion === true ? "Volver a sugerir con IA" : "Sugerir alternativa con IA"}</span>
          </button>
        </div>
      `;
      if (alt && alt.aiSuggestion) {
        const materialsList = Array.isArray(alt.suggestedMaterials) && alt.suggestedMaterials.length > 0
          ? `<ul class="voliuz-alt-ai-list">${alt.suggestedMaterials.map((m) => `<li>${escapeHTML(m)}</li>`).join("")}</ul>`
          : "";
        const certsList = Array.isArray(alt.certifications) && alt.certifications.length > 0
          ? `<ul class="voliuz-alt-ai-list">${alt.certifications.map((c) => `<li>${escapeHTML(c)}</li>`).join("")}</ul>`
          : "";
        const platformsList = Array.isArray(alt.platforms) && alt.platforms.length > 0
          ? `<ul class="voliuz-alt-ai-list">${alt.platforms.map((p) => `<li>${escapeHTML(p)}</li>`).join("")}</ul>`
          : "";
        const webLinksList = Array.isArray(alt.webLinks) && alt.webLinks.length > 0
          ? `<ul class="voliuz-alt-ai-links">${alt.webLinks
              .filter((link) => link && /^https?:\/\//i.test(link.url))
              .map((link) => `<li><a href="${escapeHTML(link.url)}" target="_blank" rel="noopener noreferrer">${escapeHTML(link.title || link.url)}</a></li>`)
              .join("")}</ul>`
          : "";

        return `
          <div class="voliuz-section-header">
            <div class="voliuz-section-title">
              ${icon("eco", "icon-accent", 16)}
              <span>Alternativa sugerida por IA</span>
            </div>
            <span class="voliuz-cert-badge">Sugerencia de IA</span>
          </div>

          <div class="voliuz-alt-empty">
            ${icon("sparkles", "alt-empty-icon", 20)}
            <div>
              <h3 class="voliuz-alt-title">No hay una alternativa equivalente verificada para este producto</h3>
              <p class="voliuz-alt-empty-text">
                ${escapeHTML(alt.reasoning || "La IA no encontró una alternativa verificada en el catálogo de VOLIUZ.")}
              </p>
              ${alt.alternativeType ? `<p class="voliuz-alt-ai-type"><strong>Tipo de alternativa:</strong> ${escapeHTML(alt.alternativeType)}</p>` : ""}
              ${materialsList ? `<p class="voliuz-alt-ai-label"><strong>Materiales a buscar:</strong></p>${materialsList}` : ""}
              ${certsList ? `<p class="voliuz-alt-ai-label"><strong>Certificaciones:</strong></p>${certsList}` : ""}
              ${platformsList ? `<p class="voliuz-alt-ai-label"><strong>Plataformas donde buscar:</strong></p>${platformsList}` : ""}
              ${webLinksList ? `<p class="voliuz-alt-ai-label"><strong>Enlaces encontrados en la web:</strong></p>${webLinksList}` : ""}
              <p class="voliuz-alt-ai-disclaimer">${escapeHTML(alt.disclaimer || "VOLIUZ no verifica estos productos ni las plataformas externas.")}</p>
            </div>
          </div>

          ${aiAltAction}
          ${routesHtml}
        `;
      }

      return `
        <div class="voliuz-section-header">
          <div class="voliuz-section-title">
            ${icon("verified", "icon-accent", 16)}
            <span>Alternativa sugerida</span>
          </div>
          <span class="voliuz-cert-badge">Sin verificar</span>
        </div>

        <div class="voliuz-alt-empty">
          ${icon("info", "alt-empty-icon", 20)}
          <div>
            <h3 class="voliuz-alt-title">Actualmente no hay una alternativa equivalente verificada para este producto</h3>
            <p class="voliuz-alt-empty-text">
              No se muestran marcas, precios ni reducciones sin datos ambientales comparables.
              El directorio de emprendimientos es una propuesta independiente
              de esta extensión.
            </p>
          </div>
        </div>

        ${aiAltAction}
        ${routesHtml}
      `;
    }

    const title = escapeHTML(alt.title || "Alternativa verificada");
    const materials = escapeHTML(alt.materialsSummary || "No disponible");
    const co2e = escapeHTML(alt.formattedCO2e || "No disponible");
    const reduction = escapeHTML(alt.reductionLabel || "No calculable");
    const description = escapeHTML(alt.description || "");

    return `
      <div class="voliuz-section-header">
        <div class="voliuz-section-title">
          ${icon("verified", "icon-accent", 16)}
          <span>Alternativa sugerida</span>
        </div>
        <span class="voliuz-cert-badge verified">Comparable</span>
      </div>

      <div class="voliuz-alt-card">
        <div class="voliuz-alt-accent-bar"></div>
        <div class="voliuz-alt-product-body">
          <div class="voliuz-alt-thumb">${icon("eco", "alt-thumb-icon", 20)}</div>
          <div class="voliuz-alt-info">
            <h3 class="voliuz-alt-title">${title}</h3>
            <span class="voliuz-alt-materials">${materials}</span>
            <div class="voliuz-alt-metrics-row">
              <span class="voliuz-alt-co2">CO₂e: ${co2e}</span>
              <span>${reduction}</span>
            </div>
            ${description ? `<p class="voliuz-detail-note">${description}</p>` : ""}
          </div>
        </div>
      </div>

      ${routesHtml}
    `;
  }

  /**
   * Renderiza la tarjeta de composición asistida por IA (Gemini).
   * No sustituye los datos declarados: solo añade contexto y advertencias.
   */
  function renderAiSection(product, impact) {
    const status = product.aiStatus || "idle";
    if (status === "idle") return "";

    if (status === "loading") {
      return `
        <section class="voliuz-ai-card">
          <div class="voliuz-ai-header">
            <div class="voliuz-ai-title">
              ${icon("autorenew", "ai-icon spin", 15)}
              <span>Composición asistida por IA</span>
            </div>
            <span class="voliuz-ai-badge loading">Analizando</span>
          </div>
          <p class="voliuz-ai-note">
            Gemini está revisando título, categoría, descripción y características.
            El HUD sigue disponible con los datos declarados por el vendedor.
          </p>
        </section>
      `;
    }

    if (status === "unavailable") {
      const code = product.aiError && product.aiError.code;
      const retryable = [
        "missing_api_key",
        "invalid_api_key",
        "ai_disabled",
        "network_error",
        "timeout",
        "service_unavailable",
        "no_messaging",
        "quota_exceeded",
      ].includes(code);

      return `
        <section class="voliuz-ai-card unavailable">
          <div class="voliuz-ai-header">
            <div class="voliuz-ai-title">
              ${icon("info", "ai-icon", 15)}
              <span>Composición asistida por IA</span>
            </div>
            <span class="voliuz-ai-badge">No disponible</span>
          </div>
          <p class="voliuz-ai-note">${escapeHTML(aiErrorMessage(product.aiError))}</p>
          ${
            code === "missing_api_key"
              ? `<p class="voliuz-ai-note muted">
            La clave se guarda en el navegador y nunca se muestra en la página.
            Después de guardarla, este producto se puede volver a analizar sin recargar la ficha.
          </p>`
              : ""
          }
          ${
            retryable
              ? `<div class="voliuz-ai-actions">
            <button class="voliuz-ai-retry" id="vz-ai-retry" type="button">
              ${icon("autorenew", "ai-retry-icon", 13)}
              <span>Reintentar con IA</span>
            </button>
          </div>`
              : ""
          }
          <p class="voliuz-ai-note muted">
            El cálculo continúa solo con la información declarada. No se inventaron
            materiales ni porcentajes para completar la huella.
          </p>
        </section>
      `;
    }

    const ai = impact.ai || product.aiComposition;
    if (!ai || !Array.isArray(ai.materials) || ai.materials.length === 0) {
      return "";
    }

    const confidence = escapeHTML(ai.confidence || "baja");
    const uncertainty = escapeHTML(ai.uncertainty || "");
    const unknown = Number(ai.unknownFraction);
    const unknownLabel = Number.isFinite(unknown)
      ? Math.max(0, Math.min(100, Math.round(unknown)))
      : null;

    const rows = ai.materials
      .slice(0, 8)
      .map((material) => {
        const percentage = Number(material.percentage);
        const percentageLabel = Number.isFinite(percentage)
          ? `~${safePercentage(percentage)}%`
          : "s/d";
        const range =
          Number.isFinite(Number(material.percentageMin)) &&
          Number.isFinite(Number(material.percentageMax))
            ? `${safePercentage(material.percentageMin)}–${safePercentage(
                material.percentageMax,
              )}%`
            : "";
        return `
          <div class="voliuz-ai-row">
            <span class="voliuz-ai-name" title="${escapeHTML(material.name)}">
              <span class="voliuz-ai-dot"></span>
              <span>${escapeHTML(material.name)}</span>
            </span>
            <span class="voliuz-ai-values">
              <span class="voliuz-ai-pct">${percentageLabel}</span>
              ${range ? `<span class="voliuz-ai-range">${range}</span>` : ""}
            </span>
          </div>
        `;
      })
      .join("");

    const limitations = Array.isArray(ai.limitations)
      ? ai.limitations.filter(Boolean).slice(0, 5)
      : [];

    return `
      <section class="voliuz-ai-card">
        <div class="voliuz-ai-header">
          <div class="voliuz-ai-title">
            ${icon("autorenew", "ai-icon", 15)}
            <span>Composición inferida por IA</span>
          </div>
          <span class="voliuz-ai-badge inferred">Inferido · ${confidence}</span>
        </div>

        <div class="voliuz-ai-rows">${rows}</div>

        ${
          unknownLabel !== null && unknownLabel > 0
            ? `<p class="voliuz-ai-note warning">${icon(
                "warning",
                "note-icon",
                12,
              )} La IA identificó aproximadamente el ${
                100 - unknownLabel
              }% de la composición; el ${unknownLabel}% restante es desconocido y no se contabiliza.</p>`
            : ""
        }

        ${
          uncertainty
            ? `<p class="voliuz-ai-note">Incertidumbre: ${uncertainty}</p>`
            : ""
        }

        ${
          limitations.length > 0
            ? `<ul class="voliuz-ai-limits">${limitations
                .map((item) => `<li>${escapeHTML(item)}</li>`)
                .join("")}</ul>`
            : ""
        }

        <p class="voliuz-ai-disclaimer">
          La IA estima la composición; el motor de VOLIUZ realiza el cálculo
          ambiental con factores provisionales. Estos datos no fueron verificados
          por el vendedor.
        </p>
      </section>
    `;
  }

  /**
   * Indica si la publicación ya ofrece una composición declarada utilizable.
   * En ese caso no se consulta a Gemini: los datos del vendedor tienen prioridad.
   */
  function hasUsableDeclaredComposition(product) {
    return Boolean(
      product &&
        product.compositionStatus === "complete" &&
        Array.isArray(product.materials) &&
        product.materials.length > 0,
    );
  }

  function aiSignature(product) {
    if (!product) return "";
    const materials = Array.isArray(product.materials)
      ? product.materials
          .map((material) => `${material.name}:${material.percentage}`)
          .join("|")
      : "";
    return [
      product.url || "",
      product.title || "",
      product.rawMaterials || "",
      materials,
    ].join("::");
  }

  function aiErrorMessage(error) {
    const code = error && error.code;
    const retryAfter =
      error && error.retryAfter
        ? ` Espera aproximadamente ${Math.round(error.retryAfter)} s antes de volver a intentar.`
        : "";
    const messages = {
      missing_api_key:
        "Falta la clave de Gemini. Ábrela desde el icono de VOLIUZ → «Composición asistida por IA», guárdala y pulsa Reintentar. Si usas .env, ejecuta node scripts/build-env.js y recarga la extensión.",
      ai_disabled: "La inferencia con IA está desactivada en la configuración.",
      quota_exceeded:
        "Se alcanzó el límite de solicitudes de Gemini." + retryAfter,
      invalid_api_key: "La clave de Gemini no es válida o no tiene permisos.",
      timeout: "Gemini no respondió dentro del tiempo límite.",
      network_error: "No fue posible conectar con Gemini.",
      service_unavailable: "Gemini no está disponible en este momento.",
      insufficient_evidence:
        "La IA no encontró evidencia suficiente para inferir la composición.",
      invalid_percentages:
        "La IA devolvió porcentajes no utilizables; no se aplicaron al cálculo.",
      invalid_json:
        "La respuesta de la IA no tuvo el formato esperado y fue descartada.",
      blocked:
        "La IA bloqueó la respuesta por sus filtros de seguridad. Reformula la pregunta.",
      empty_response:
        "La IA no devolvió una respuesta utilizable. Intenta de nuevo.",
      invalid_request:
        "La pregunta no tiene un formato válido. Intenta reformularla.",
      invalid_response:
        "La IA devolvió una respuesta no procesable. Intenta de nuevo.",
      rate_limited:
        "Hiciste varias preguntas seguidas. Espera un momento antes de continuar.",
      knowledge_unavailable:
        "La base de conocimiento ambiental no está disponible en este momento.",
      forbidden: "La inferencia solo está disponible en Mercado Libre Colombia.",
      payload_too_large: "El contexto enviado excede el límite permitido.",
      no_messaging:
        "El canal de mensajería de la extensión no está disponible.",
    };
    return (
      messages[code] ||
      (error && error.message) ||
      "No fue posible obtener una estimación de la IA."
    );
  }

  function renderAIUpdate() {
    if (!currentProductData) return;
    const scope = shadowRoot
      ? shadowRoot.getElementById("voliuz-scope-root")
      : null;
    const body = scope ? scope.querySelector(".voliuz-body") : null;
    const scrollTop = body ? body.scrollTop : 0;

    currentImpactData = getCalculator().calculateImpact(currentProductData);
    currentAlternativeData = getRecommender().findAlternative(
      currentProductData,
      currentImpactData,
    );
    renderHUD(currentProductData, currentImpactData, currentAlternativeData);

    // Si no hay alternativa verificada, solicitar sugerencia de IA
    // (categorías de alternativa, materiales, certificaciones, plataformas).
    if (
      currentAlternativeData &&
      currentAlternativeData.hasAlternative !== true &&
      !currentAlternativeData.aiSuggestion
    ) {
      requestAlternativeSuggestion(currentProductData, currentImpactData);
    }

    const updatedScope = shadowRoot
      ? shadowRoot.getElementById("voliuz-scope-root")
      : null;
    const updatedBody = updatedScope
      ? updatedScope.querySelector(".voliuz-body")
      : null;
    if (updatedBody && scrollTop > 0) updatedBody.scrollTop = scrollTop;
  }

  /**
   * Solicita al service worker una composición inferida por Gemini.
   * Nunca envía la clave ni ejecuta la petición desde la página: el HUD
   * continúa funcionando con datos declarados si la IA falla.
   */
  function requestAiComposition(product, options = {}) {
    if (!product) return;

    const force = options && options.force === true;
    const signature = aiSignature(product);
    const cached = aiCache.get(signature);

    if (cached && !force) {
      product.aiComposition = cached;
      product.aiStatus = "available";
      product.aiError = null;
      renderAIUpdate();
      return;
    }

    if (aiRequestInFlight && aiRequestKey === signature) return;

    if (
      typeof chrome === "undefined" ||
      !chrome.runtime ||
      typeof chrome.runtime.sendMessage !== "function"
    ) {
      product.aiStatus = "unavailable";
      product.aiError = {
        code: "no_messaging",
        message: "El canal de mensajería de la extensión no está disponible.",
      };
      renderAIUpdate();
      return;
    }

    if (force) {
      aiCache.delete(signature);
      product.aiComposition = null;
      product.aiError = null;
    }
    product.aiStatus = "loading";
    renderAIUpdate();

    aiRequestKey = signature;
    aiRequestInFlight = true;

    const payload = {
      signature,
      force,
      product: buildAiProductPayload(product),
    };

    chrome.runtime.sendMessage(
      { action: "voliuz:inferComposition", payload },
      (response) => {
        aiRequestInFlight = false;

        if (
          !currentProductData ||
          aiSignature(currentProductData) !== signature
        ) {
          return;
        }

        if (chrome.runtime.lastError) {
          product.aiComposition = null;
          product.aiStatus = "unavailable";
          product.aiError = {
            code: "network_error",
            message: "No fue posible comunicarse con el service worker.",
          };
          renderAIUpdate();
          return;
        }

        if (response && response.ok && response.data) {
          aiCache.set(signature, response.data);
          product.aiComposition = response.data;
          product.aiStatus = "available";
          product.aiError = null;
        } else {
          product.aiComposition = null;
          product.aiStatus = "unavailable";
          product.aiError =
            (response && response.error) || {
              code: "unknown_error",
              message: "No fue posible obtener una estimación de la IA.",
            };
        }

        renderAIUpdate();
      },
    );
  }

  /**
   * Solicita al service worker una sugerencia de alternativa de menor impacto
   * generada por Gemini. NO inventa productos, precios ni reducciones.
   * Devuelve categorías de alternativa, materiales, certificaciones y plataformas
   * donde buscar, siempre con descargo de que VOLIUZ no las verifica.
   */
  function requestAlternativeSuggestion(product, impact, options = {}) {
    if (!product) return;

    const force = options && options.force === true;
    const signature = aiSignature(product) + "|alternative";
    const cached = aiCache.get(signature);

    // Preserva siempre las rutas externas y el CTA del catálogo, tanto si la
    // IA responde como si falla: nunca se pierden los enlaces reales.
    const baseAlternative = {
      ...(currentAlternativeData &&
      typeof currentAlternativeData === "object"
        ? currentAlternativeData
        : {}),
    };

    const finalize = (data, aiSuggestion, aiError) => {
      currentAlternativeData = {
        ...baseAlternative,
        ...(data && typeof data === "object" ? data : {}),
        hasAlternative: false,
        comparisonAvailable: false,
        verificationStatus: "pending",
        aiSuggestion: aiSuggestion === true,
        aiSuggestionError: aiError || null,
        webUrl: VOLIUZ_WEB_URL,
        webLabel: "Explorar la web de VOLIUZ",
      };
      renderHUD(currentProductData, currentImpactData, currentAlternativeData);
    };

    if (cached && !force) {
      finalize(cached, true, null);
      return;
    }

    if (
      typeof chrome === "undefined" ||
      !chrome.runtime ||
      typeof chrome.runtime.sendMessage !== "function"
    ) {
      finalize(null, false, {
        code: "no_messaging",
        message: "El canal de mensajería de la extensión no está disponible.",
      });
      return;
    }

    const payload = {
      signature,
      force,
      product: buildAiProductPayload(product),
      impact: {
        co2e: impact && impact.co2e,
        available: impact && impact.available,
        materials: impact && Array.isArray(impact.materials) ? impact.materials : [],
      },
      categoryGroup: product.categoryGroup || null,
    };

    chrome.runtime.sendMessage(
      { action: "voliuz:alternativeSuggestion", payload },
      (response) => {
        if (
          !currentProductData ||
          aiSignature(currentProductData) !== signature.replace(/\|alternative$/, "")
        ) {
          return;
        }

        if (chrome.runtime.lastError) {
          finalize(null, false, {
            code: "network_error",
            message: "No fue posible comunicarse con el service worker.",
          });
          return;
        }

        if (response && response.ok && response.data) {
          aiCache.set(signature, response.data);
          finalize(response.data, true, null);
        } else {
          finalize(null, false, {
            code:
              response && response.error && response.error.code
                ? response.error.code
                : "unknown_error",
            message:
              (response && response.error && response.error.message) ||
              "No se pudo obtener una sugerencia de alternativa.",
          });
        }
      },
    );
  }

  /**
   * Datos del producto que se envían al service worker. Nunca incluye la clave
   * de API ni datos de la cuenta del usuario.
   */
  function buildAiProductPayload(product) {
    return {
      url: product.url || window.location.href,
      title: product.title || "",
      category: product.category || "",
      descriptionText: product.descriptionText || "",
      features: Array.isArray(product.features) ? product.features : [],
      materialMentions: Array.isArray(product.materialMentions)
        ? product.materialMentions
        : [],
      materials: Array.isArray(product.materials) ? product.materials : [],
      rawMaterials: product.rawMaterials || "",
      currency: product.currency || "",
      image: product.image || "",
    };
  }

  /**
   * Resumen acotado del impacto para el chat. El service worker lo valida
   * de nuevo antes de construir el prompt.
   */
  function buildChatImpactPayload(impact) {
    const source = impact || {};
    const recyclability = source.recyclability || {};

    return {
      available: source.available === true,
      co2e: source.co2e,
      formattedCO2e: source.formattedCO2e || "",
      impactLevel: source.impactLevel || "",
      dataBasis: source.dataBasis || "",
      isPartialEstimate: source.isPartialEstimate === true,
      weightKg: source.weightKg,
      isWeightEstimated: source.isWeightEstimated === true,
      materials: Array.isArray(source.materials)
        ? source.materials.slice(0, 12).map((material) => ({
            name: material.name || "",
            percentage: material.percentage,
            inferred: material.inferred === true,
          }))
        : [],
      recyclability: {
        level: recyclability.level || "",
        description: recyclability.description || "",
      },
      warnings: Array.isArray(source.warnings)
        ? source.warnings.slice(0, 6)
        : [],
    };
  }

  /**
   * El historial del chat vive en memoria y se descarta al cambiar de ficha.
   */
  function resetChatState() {
    chatState.productSignature = "";
    chatState.messages = [];
    chatState.status = "idle";
    chatState.error = null;
  }

  function clearChatConversation() {
    chatState.messages = [];
    chatState.status = "idle";
    chatState.error = null;
    if (currentProductData) {
      chatState.productSignature = aiSignature(currentProductData);
    }
  }

  function syncChatProduct(product) {
    const signature = aiSignature(product);
    if (signature === chatState.productSignature) return;
    chatState.productSignature = signature;
    chatState.messages = [];
    chatState.status = "idle";
    chatState.error = null;
  }

  function trimChatMessages() {
    if (chatState.messages.length > MAX_CHAT_MESSAGES) {
      chatState.messages = chatState.messages.slice(-MAX_CHAT_MESSAGES);
    }
  }

  function formatChatText(value) {
    return escapeHTML(value).replace(/\n/g, "<br />");
  }

  function chatStatusMeta(status = chatState.status) {
    const meta = {
      idle: { label: "Listo", className: "idle" },
      loading: { label: "Pensando", className: "loading" },
      error: { label: "Atención", className: "error" },
    };
    return meta[status] || meta.idle;
  }

  function renderChatSuggestionsHtml() {
    return CHAT_SUGGESTIONS.map(
      (question) => `
        <button
          type="button"
          class="voliuz-chat-suggestion"
          data-chat-suggestion="${escapeHTML(question)}"
        >${escapeHTML(question)}</button>
      `,
    ).join("");
  }

  function renderChatLogHtml() {
    const pieces = chatState.messages.map((message) => {
      const role = message.role === "assistant" ? "assistant" : "user";
      const label = role === "assistant" ? "VOLIUZ IA" : "Tú";
      return `
        <div class="voliuz-chat-msg ${role}">
          <span class="voliuz-chat-role">${label}</span>
          <div class="voliuz-chat-text">${formatChatText(message.text)}</div>
        </div>
      `;
    });

    if (chatState.messages.length === 0 && chatState.status !== "loading") {
      pieces.push(`
        <div class="voliuz-chat-empty">
          ${icon("eco", "chat-empty-icon", 18)}
          <p>Aún no hay preguntas. Usa una sugerencia o escribe la tuya.</p>
        </div>
      `);
    }

    if (chatState.status === "loading") {
      pieces.push(`
        <div class="voliuz-chat-msg assistant loading" aria-live="polite">
          <span class="voliuz-chat-role">VOLIUZ IA</span>
          <div class="voliuz-chat-typing">
            <span class="voliuz-chat-dots" aria-hidden="true"><span></span><span></span><span></span></span>
            <span>Revisando el contexto del producto…</span>
          </div>
        </div>
      `);
    }

    if (chatState.status === "error" && chatState.error) {
      pieces.push(`
        <div class="voliuz-chat-error" role="alert">
          ${icon("warning", "chat-error-icon", 13)}
          <span>${escapeHTML(aiErrorMessage(chatState.error))}</span>
        </div>
      `);
    }

    return pieces.join("");
  }

  function renderChatSection() {
    const meta = chatStatusMeta();
    const loading = chatState.status === "loading";
    const noMessages = chatState.messages.length === 0;

    return `
      <section class="voliuz-chat-card" id="vz-chat" aria-label="Asistente ambiental" aria-busy="${loading ? "true" : "false"}">
        <div class="voliuz-chat-header">
          <div class="voliuz-chat-title">
            ${icon("eco", "chat-icon", 15)}
            <span>Asistente ambiental</span>
          </div>
          <span class="voliuz-chat-badge ${meta.className}">${meta.label}</span>
        </div>

        <p class="voliuz-chat-intro">
          Pregunta por los materiales, la estimación o cómo reducir el impacto.
          Responde con el contexto de este producto y la base ambiental de VOLIUZ.
        </p>

        <div class="voliuz-chat-log" id="vz-chat-log" role="log" aria-live="polite">${renderChatLogHtml()}</div>

        <div class="voliuz-chat-suggestions" id="vz-chat-suggestions">${
          noMessages && !loading ? renderChatSuggestionsHtml() : ""
        }</div>

        <form class="voliuz-chat-form" id="vz-chat-form">
          <textarea
            class="voliuz-chat-input"
            id="vz-chat-input"
            rows="2"
            maxlength="500"
            placeholder="Escribe tu pregunta…"
            aria-label="Pregunta para el asistente ambiental"
          ></textarea>
          <button type="submit" class="voliuz-chat-send" id="vz-chat-send" ${loading ? "disabled" : ""}>
            ${icon("arrow_forward", "chat-send-icon", 14)}
            <span>Enviar</span>
          </button>
        </form>

        <div class="voliuz-chat-footer">
          <span class="voliuz-chat-disclaimer">IA generativa · No inventa cifras · No es una certificación</span>
          <button type="button" class="voliuz-chat-clear" id="vz-chat-clear" ${
            noMessages || loading ? "disabled" : ""
          }>Limpiar</button>
        </div>
      </section>
    `;
  }

  /**
   * Actualiza solo el registro y los controles del chat, sin reconstruir el
   * HUD. Así se conservan el foco y el texto del campo de entrada.
   */
  function updateChatUI() {
    if (!shadowRoot) return;
    const scope = shadowRoot.getElementById("voliuz-scope-root");
    if (!scope) return;

    const card = scope.querySelector("#vz-chat");
    if (!card) return;

    const log = card.querySelector("#vz-chat-log");
    if (log) {
      log.innerHTML = renderChatLogHtml();
      log.scrollTop = log.scrollHeight;
    }

    const suggestions = card.querySelector("#vz-chat-suggestions");
    if (suggestions) {
      suggestions.innerHTML =
        chatState.messages.length === 0 && chatState.status !== "loading"
          ? renderChatSuggestionsHtml()
          : "";
    }

    const meta = chatStatusMeta();
    const badge = card.querySelector(".voliuz-chat-badge");
    if (badge) {
      badge.className = `voliuz-chat-badge ${meta.className}`;
      badge.textContent = meta.label;
    }

    const loading = chatState.status === "loading";
    card.setAttribute("aria-busy", loading ? "true" : "false");

    const send = card.querySelector("#vz-chat-send");
    if (send) send.disabled = loading;

    const clear = card.querySelector("#vz-chat-clear");
    if (clear) clear.disabled = loading || chatState.messages.length === 0;
  }

  /**
   * Envía una pregunta al service worker. La respuesta se añade al historial
   * local y nunca se guarda en chrome.storage.
   */
  function sendChatQuestion(rawQuestion) {
    const question = String(rawQuestion ?? "")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 500);

    if (!question || chatState.status === "loading" || !currentProductData) {
      return false;
    }

    const product = currentProductData;
    const signature = aiSignature(product);

    if (chatState.productSignature && chatState.productSignature !== signature) {
      chatState.messages = [];
      chatState.error = null;
      chatState.productSignature = signature;
    }

    if (
      typeof chrome === "undefined" ||
      !chrome.runtime ||
      typeof chrome.runtime.sendMessage !== "function"
    ) {
      chatState.status = "error";
      chatState.error = {
        code: "no_messaging",
        message: "El canal de mensajería de la extensión no está disponible.",
      };
      updateChatUI();
      return false;
    }

    const history = chatState.messages.slice(-8).map((message) => ({
      role: message.role,
      text: message.text,
    }));

    chatState.messages.push({ role: "user", text: question, at: Date.now() });
    trimChatMessages();
    chatState.status = "loading";
    chatState.error = null;

    const input = shadowRoot
      ?.getElementById("voliuz-scope-root")
      ?.querySelector("#vz-chat-input");
    if (input) input.value = "";

    updateChatUI();

    chrome.runtime.sendMessage(
      {
        action: "voliuz:chat",
        payload: {
          question,
          history,
          product: buildAiProductPayload(product),
          impact: buildChatImpactPayload(currentImpactData),
        },
      },
      (response) => {
        if (!currentProductData || aiSignature(currentProductData) !== signature) {
          return;
        }

        if (chrome.runtime.lastError) {
          chatState.status = "error";
          chatState.error = {
            code: "network_error",
            message: "No fue posible comunicarse con el service worker.",
          };
          updateChatUI();
          return;
        }

        if (
          response &&
          response.ok === true &&
          response.data &&
          typeof response.data.answer === "string" &&
          response.data.answer.trim()
        ) {
          chatState.messages.push({
            role: "assistant",
            text: response.data.answer.trim().slice(0, 4000),
            at: Date.now(),
          });
          chatState.status = "idle";
          chatState.error = null;
        } else {
          chatState.status = "error";
          chatState.error =
            (response && response.error) || {
              code: "unknown_error",
              message: "No fue posible obtener una respuesta del chat de IA.",
            };
        }

        trimChatMessages();
        updateChatUI();
      },
    );

    return true;
  }

  /**
   * Obtiene la instancia del Scraper
   */
  function getScraper() {
    return (
      window.VoliuzScraper ||
      (typeof VoliuzScraper !== "undefined" ? VoliuzScraper : null)
    );
  }

  /**
   * Obtiene la instancia del Calculador de CO2
   */
  function getCalculator() {
    return (
      window.VoliuzCO2Calculator ||
      (typeof VoliuzCO2Calculator !== "undefined" ? VoliuzCO2Calculator : null)
    );
  }

  /**
   * Obtiene la instancia del Recomendador
   */
  function getRecommender() {
    return (
      window.VoliuzRecommender ||
      (typeof VoliuzRecommender !== "undefined" ? VoliuzRecommender : null)
    );
  }

  /**
   * Cancela los temporizadores de análisis pendientes.
   * Se invoca al cambiar de ruta para no analizar una ficha obsoleta.
   */
  function clearScheduledWork() {
    if (analysisTimer !== null) {
      clearTimeout(analysisTimer);
      analysisTimer = null;
    }

    if (retryTimer !== null) {
      clearTimeout(retryTimer);
      retryTimer = null;
    }

    moduleRetryCount = 0;
  }

  /**
   * Programa un análisis con debounce para permitir que Mercado Libre
   * termine de montar el DOM de la nueva ficha.
   */
  function scheduleAnalysis(delay = SPA_SETTLE_DELAY) {
    clearScheduledWork();

    analysisTimer = setTimeout(() => {
      analysisTimer = null;
      runTelemetryAnalysis();
    }, delay);
  }

  /**
   * Destruye el HUD, desvincula sus listeners y libera las referencias
   * para que el Shadow DOM pueda ser recolectado por el navegador.
   * Evita HUDs duplicados y fugas de memoria al navegar entre fichas.
   */
  function destroyHUD() {
    // Desvincula todos los listeners DOM del render anterior.
    if (eventController) {
      eventController.abort();
      eventController = null;
    }

    // Elimina cualquier host residual (incluidos duplicados de navegaciones previas).
    document.querySelectorAll("#voliuz-hud-host").forEach((host) => {
      if (host.shadowRoot) {
        const scope = host.shadowRoot.getElementById("voliuz-scope-root");
        if (scope) scope.textContent = "";
      }
      host.remove();
    });

    if (hostElement) hostElement.remove();

    hostElement = null;
    shadowRoot = null;
  }

  /**
   * Descarta el resultado del análisis anterior.
   */
  function resetAnalysisData() {
    currentProductData = null;
    currentImpactData = null;
    currentAlternativeData = null;
    resetChatState();
  }

  /**
   * Inicializa el Host de Shadow DOM.
   * Cada render parte de un Shadow Root nuevo para no reutilizar
   * nodos con listeners previamente vinculados.
   */
  function setupShadowDOM() {
    destroyHUD();

    hostElement = document.createElement("div");
    hostElement.id = "voliuz-hud-host";
    hostElement.style.position = "fixed";
    hostElement.style.top = "0";
    hostElement.style.left = "0";
    hostElement.style.width = "0";
    hostElement.style.height = "0";
    hostElement.style.zIndex = "2147483647";
    hostElement.style.border = "none";
    hostElement.style.margin = "0";
    hostElement.style.padding = "0";

    shadowRoot = hostElement.attachShadow({ mode: "open" });

    // Inyectar hoja de estilos aislada
    const link = document.createElement("link");
    link.rel = "stylesheet";
    const cssUrl =
      typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.getURL
        ? chrome.runtime.getURL("styles/panel.css")
        : "../styles/panel.css";
    link.href = cssUrl;
    shadowRoot.appendChild(link);

    // Contenedor scoped
    const scopeWrapper = document.createElement("div");
    scopeWrapper.className = "voliuz-scope";
    scopeWrapper.id = "voliuz-scope-root";
    shadowRoot.appendChild(scopeWrapper);

    document.body.appendChild(hostElement);
    return shadowRoot;
  }

  /**
   * Construye el HTML completo del HUD flotante y sus modales
   */
  function renderHUD(product, impact, alt) {
    const scope = shadowRoot.getElementById("voliuz-scope-root");
    if (!scope) return;

    // El tema se aplica al contenedor con scope para que las variables CSS
    // cambien sin reescribir toda la hoja de estilos.
    scope.setAttribute("data-theme", currentTheme);

    const productTitle = escapeHTML(product.title || "Producto sin título");
    const productCategory = escapeHTML(product.category || "Categoría no disponible");
    const productStoreName = escapeHTML(product.storeName || "Mercado Libre Colombia");
    const productPrice = escapeHTML(product.formattedPrice || "No disponible");
    const productImage = safeImageURL(product.image);
    const extraction = extractionInfo(product);
    const extractionClass = escapeHTML(extraction.className);
    const extractionLabel = escapeHTML(extraction.label);
    const extractionNoticeHtml = renderExtractionNotice(product);

    const aiSectionHtml = renderAiSection(product, impact);
    const usingInferred = impact.dataBasis === "ai_inferred";
    const partialEstimate = usingInferred && impact.isPartialEstimate === true;

    const impactClass = safeClass(impact.impactClass, ["low", "medium", "high"], "unknown");
    const impactCO2e = impact.available
      ? escapeHTML(impact.formattedCO2e || "—")
      : "No disponible";
    const impactCO2eIsText = !impact.available;
    const impactLevel = escapeHTML(impact.impactLevel || "Datos insuficientes");
    const impactReason = escapeHTML(
      impact.reason ||
        product.environmentalDataReason ||
        "No hay datos suficientes para estimar la huella.",
    );
    const equivalenceIcon = (impact.equivalence && impact.equivalence.icon) || "info";
    const equivalenceText = escapeHTML(
      plainText(impact.equivalence && impact.equivalence.text),
    );

    const weightKg = Number(impact.weightKg);
    const weightKnown = Number.isFinite(weightKg) && weightKg > 0;
    const weightText = weightKnown
      ? `${escapeHTML(impact.weightKg)} kg (${impact.isWeightEstimated ? "peso estimado por categoría" : "peso declarado"})`
      : "peso no disponible";

    const materialSource = escapeHTML(
      sourceLabel(product.fieldSources && product.fieldSources.materials),
    );

    // Segmentos activos para el medidor de CO2
    const isLow = impact.available && impact.impactClass === "low";
    const isMedium = impact.available && impact.impactClass === "medium";
    const isHigh = impact.available && impact.impactClass === "high";

    // Si la estimación no está disponible, se muestran igualmente los
    // materiales declarados (aunque sean parciales) para no ocultar lo obtenido.
    const declaredMaterials = Array.isArray(product.materials) ? product.materials : [];
    const usingDeclaredFallback = impact.materials.length === 0 && declaredMaterials.length > 0;
    const displayMaterials = usingDeclaredFallback
      ? declaredMaterials
          .filter((material) => material && material.name)
          .map((material) => ({
            name: material.name,
            percentage: material.percentage,
            color: "#8ccdff",
          }))
      : impact.materials;

    const materialMentions = Array.isArray(product.materialMentions)
      ? product.materialMentions.filter(Boolean)
      : [];

    // Etiqueta de porcentaje: "s/d" cuando la publicación no lo declara.
    function materialPercentageLabel(value) {
      return Number.isFinite(Number(value))
        ? `${safePercentage(value)}%`
        : "s/d";
    }

    // Desglose de materiales
    const materialsListHtml =
      displayMaterials.length > 0
        ? displayMaterials
          .map(
            (m) => `
      <div class="voliuz-mat-row">
        <span class="voliuz-mat-name" title="${escapeHTML(m.name)}">
          <span class="voliuz-mat-dot" style="--vz-mat-color: ${safeColor(m.color)}; --vz-mat-color-dark: ${darkMaterialColor(m.color)};"></span>
          <span>${escapeHTML(m.name)}</span>
        </span>
        <span class="voliuz-mat-pct">${m.inferred ? "~" : ""}${materialPercentageLabel(m.percentage)}</span>
      </div>
    `,
          )
          .join("")
        : `<p class="voliuz-dim-desc">${
            materialMentions.length > 0
              ? `Materiales mencionados sin porcentaje: ${escapeHTML(materialMentions.join(", "))}.`
              : "Composición no disponible en la publicación."
          }</p>`;

    const declaredKnownTotal = displayMaterials.reduce(
      (total, material) => total + (Number(material.percentage) || 0),
      0,
    );
    const unknownSegmentHtml =
      usingInferred && declaredKnownTotal < 99.5
        ? `<div class="voliuz-mat-segment unknown" style="width: ${Math.max(
            0,
            100 - safePercentage(declaredKnownTotal),
          )}%;" title="Fracción desconocida (no contabilizada)"></div>`
        : "";

    const materialsBarSegmentsHtml =
      displayMaterials.length > 0
        ? displayMaterials
          .map(
            (m) => `
      <div class="voliuz-mat-segment"
        style="width: ${safePercentage(m.percentage)}%; --vz-mat-color: ${safeColor(m.color)}; --vz-mat-color-dark: ${darkMaterialColor(m.color)};"
        title="${escapeHTML(m.name)}: ${safePercentage(m.percentage)}%">
      </div>
    `,
          )
          .join("") + unknownSegmentHtml
        : "";

    const declaredTotal = declaredMaterials.reduce(
      (total, material) => total + (Number(material.percentage) || 0),
      0,
    );

    const hasNumericPercentage = declaredMaterials.some((material) =>
      Number.isFinite(Number(material && material.percentage)),
    );

    const declaredTotalLabel = Number.isFinite(declaredTotal)
      ? Math.max(0, Math.min(100, Math.round(declaredTotal)))
      : 0;

    const materialsNoteHtml = usingDeclaredFallback
      ? `<p class="voliuz-detail-note">${icon("warning", "note-icon")} ${
          hasNumericPercentage
            ? `Composición declarada parcial (${declaredTotalLabel}%). No se usa para calcular la huella.`
            : "Composición declarada sin porcentajes utilizables. No se usa para calcular la huella."
        }</p>`
      : impact.available
        ? usingInferred
          ? `<p class="voliuz-detail-note">${icon("warning", "note-icon")} Composición inferida por IA, no declarada por el vendedor. Porcentajes aproximados.</p>`
          : `<p class="voliuz-detail-note">Fuente de composición: ${materialSource}. Porcentajes declarados por la publicación.</p>`
        : "";

    // Segmentos de reciclabilidad
    let recSegsHtml = "";

    if (
      impact.available &&
      impact.recyclability.level === "Potencialmente alto"
    ) {
      recSegsHtml = `
    <div class="voliuz-rec-seg filled-high"></div>
    <div class="voliuz-rec-seg filled-high"></div>
    <div class="voliuz-rec-seg filled-high"></div>
  `;
    } else if (
      impact.available &&
      impact.recyclability.level === "Potencialmente medio"
    ) {
      recSegsHtml = `
    <div class="voliuz-rec-seg filled-medium-dim"></div>
    <div class="voliuz-rec-seg filled-medium"></div>
    <div class="voliuz-rec-seg"></div>
  `;
    } else if (
      impact.available &&
      impact.recyclability.level === "Potencialmente bajo"
    ) {
      recSegsHtml = `
    <div class="voliuz-rec-seg filled-low"></div>
    <div class="voliuz-rec-seg"></div>
    <div class="voliuz-rec-seg"></div>
  `;
    } else {
      recSegsHtml = `
    <div class="voliuz-rec-seg"></div>
    <div class="voliuz-rec-seg"></div>
    <div class="voliuz-rec-seg"></div>
  `;
    }

    // Clase visual del badge de reciclabilidad (sin colores inline).
    const recLevelClass = !impact.available
      ? "unknown"
      : impact.recyclability.level === "Potencialmente alto"
        ? "high"
        : impact.recyclability.level === "Potencialmente medio"
          ? "medium"
          : impact.recyclability.level === "Potencialmente bajo"
            ? "low"
            : "unknown";

    // Logo URL seguro (identidad original VOLIUZ)
    const logoUrl =
      typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.getURL
        ? chrome.runtime.getURL("assets/VOLIUZ.png")
        : "../assets/VOLIUZ.png";

    scope.innerHTML = `
      <!-- Botón Flotante Disparador (minimizado) -->
      <button class="voliuz-trigger-pill ${isPanelOpen ? "hidden" : ""}" id="vz-trigger-btn" type="button" title="Abrir VOLIUZ HUD">
        <span class="voliuz-pulse-dot"></span>
        <span class="voliuz-trigger-text">VOLIUZ</span>
        <span class="voliuz-trigger-badge">HUD</span>
      </button>

      <!-- Panel Lateral Flotante -->
      <div class="voliuz-panel-container ${isPanelOpen ? "open" : ""}" id="vz-panel">
        
        <!-- HEADER -->
        <header class="voliuz-header">
          <a class="voliuz-header-brand voliuz-brand-link" href="${VOLIUZ_WEB_URL}" target="_blank" rel="noopener noreferrer" title="Abrir la web de VOLIUZ">
            <img src="${logoUrl}" alt="VOLIUZ" class="voliuz-header-logo" />
            <div class="voliuz-header-titles">
              <div class="voliuz-header-titles-row">
                <span class="voliuz-header-title">VOLIUZ</span>
                <span class="voliuz-header-tag">HUD</span>
              </div>
              <span class="voliuz-header-subtitle">Detector Tienda · Compra mejor</span>
            </div>
            ${icon("open_in_new", "brand-external", 12)}
          </a>
          <div class="voliuz-header-controls">
            <button class="voliuz-icon-btn" id="vz-btn-theme" title="${currentTheme === "dark" ? "Cambiar a modo claro" : "Cambiar a modo oscuro"}" aria-label="${currentTheme === "dark" ? "Cambiar a modo claro" : "Cambiar a modo oscuro"}">
              ${icon(currentTheme === "dark" ? "sun" : "moon", "", 16)}
            </button>
            <button class="voliuz-icon-btn" id="vz-btn-minimize" title="Minimizar panel" aria-label="Minimizar panel">
              ${icon("chevron_right", "", 16)}
            </button>
            <button class="voliuz-icon-btn" id="vz-btn-close" title="Ocultar HUD" aria-label="Ocultar HUD">
              ${icon("close", "", 16)}
            </button>
          </div>
        </header>

        <!-- CUERPO TELEMÉTRICO -->
        <div class="voliuz-body">

          <!-- SECCIÓN 1: DETECCIÓN Y PRODUCTO ANALIZADO -->
          <section class="voliuz-detection-status">
            <div class="voliuz-status-pill ${extractionClass}">
              ${icon(extraction.icon, "status-icon", 13)}
              <span>${extractionLabel}</span>
            </div>
            <div class="voliuz-store-tag">
              ${icon("storefront", "store-icon", 13)}
              <span>${productStoreName}</span>
            </div>
          </section>

          ${extractionNoticeHtml}

          <div class="voliuz-product-card">
            <div class="voliuz-product-thumb">
              ${productImage ? `<img src="${escapeHTML(productImage)}" alt="${productTitle}" />` : '<span class="voliuz-dim-desc">Imagen no disponible</span>'}
              <div class="voliuz-product-category-tag">${productCategory}</div>
            </div>
            <div class="voliuz-product-info">
              <h2 class="voliuz-product-title" title="${productTitle}">${productTitle}</h2>
              <span class="voliuz-product-category">${productCategory}</span>
              <div class="voliuz-product-price-row">
                <span class="voliuz-product-price">${productPrice}</span>
                <div class="voliuz-verified-badge ${extractionClass}">
                  ${icon(extraction.icon, "check-icon", 13)}
                  <span>${extractionLabel}</span>
                </div>
              </div>
            </div>
          </div>

          <!-- SECCIÓN 2: HERO TELEMÉTRICO DE IMPACTO AMBIENTAL -->
          <div class="voliuz-section-header">
            <div class="voliuz-section-title">
              ${icon("eco", "icon-accent", 16)}
              <span>Impacto ambiental</span>
            </div>
            <span class="voliuz-section-meta">Cuna a puerta · preliminar</span>
          </div>

          <div class="voliuz-hero-pod">
            <div class="voliuz-hero-glow"></div>

            <div class="voliuz-hero-readout">
              <div class="voliuz-metric-group">
                <div class="voliuz-metric-value-row">
                  <span class="voliuz-metric-big${impactCO2eIsText ? " is-text" : ""}">${impactCO2e}</span>
                  ${impact.available ? '<span class="voliuz-metric-unit">kg CO₂e</span>' : ""}
                </div>
                <span class="voliuz-metric-label">
                  ${impact.available
                    ? partialEstimate
                      ? "Huella parcial estimada con IA (no es una huella completa)"
                      : usingInferred
                        ? "Huella estimada con IA (preliminar)"
                        : "Huella estimada (preliminar)"
                    : "No se puede estimar con los datos disponibles"}
                </span>
              </div>
              <div class="voliuz-impact-pill ${impact.available ? impactClass : "unknown"}">
                <span class="voliuz-impact-dot"></span>
                <span>${impact.available ? (partialEstimate ? "Parcial · IA" : usingInferred ? "IA · estimado" : impactLevel) : "Sin estimación"}</span>
              </div>
            </div>

            ${impact.available
              ? `
            <div class="voliuz-meter-track">
              <div class="voliuz-meter-seg ${isLow ? "active-low" : ""}"></div>
              <div class="voliuz-meter-seg ${isMedium ? "active-medium" : ""}"></div>
              <div class="voliuz-meter-seg ${isHigh ? "active-high" : ""}"></div>
            </div>
            <div class="voliuz-meter-labels">
              <span class="${isLow ? "current low" : ""}">Bajo (&lt; 2 kg)</span>
              <span class="${isMedium ? "current medium" : ""}">Medio (2 - 4 kg)</span>
              <span class="${isHigh ? "current high" : ""}">Alto (&gt; 4 kg)</span>
            </div>
            `
              : `<p class="voliuz-impact-reason">${impactReason}</p>`}

            <!-- Equivalencia humana -->
            <div class="voliuz-equivalence-box">
              ${icon(equivalenceIcon, "eq-icon", 16)}
              <p class="voliuz-equivalence-text">${equivalenceText}</p>
            </div>

            ${impact.available
              ? `
            <p class="voliuz-method-note">
              ${icon("info", "note-icon", 13)}
              <span>${usingInferred ? "Composición inferida por IA · " : ""}${weightText} · Factores provisionales · Estimación preliminar, no es una LCA certificada.</span>
            </p>
            ${impact.co2eRange && impact.co2eRange.label ? `<p class="voliuz-method-note">${icon("info", "note-icon", 13)}<span>Rango de referencia según incertidumbre de la IA: ${escapeHTML(impact.co2eRange.label)} kg CO₂e. No es un intervalo estadístico.</span></p>` : ""}
            `
              : ""}
          </div>

          <!-- SECCIÓN 3: RESULTADO DE IA (si aplica) -->
          ${aiSectionHtml}

          <!-- SECCIÓN 3: GRID DE DIMENSIONES (MATERIALES Y RECICLABILIDAD) -->
          <div class="voliuz-dimensions-grid">
            
            <!-- Bloque Materiales -->
            <div class="voliuz-dim-card">
              <div class="voliuz-dim-header">
                <div class="voliuz-dim-title-row">
                  <div class="voliuz-dim-title">
                    ${icon("layers", "dim-icon", 15)}
                    <span>Materiales</span>
                  </div>
                </div>
                <span class="voliuz-dim-subtitle">${usingInferred ? "Composición inferida por IA" : "Composición declarada"}</span>
              </div>
              <div class="voliuz-materials-bar">
                ${materialsBarSegmentsHtml}
              </div>
              <div class="voliuz-materials-list">
                ${materialsListHtml}
              </div>
              ${materialsNoteHtml}
              ${impact.source ? `<p class="voliuz-detail-note">${icon("info", "note-icon", 12)} Fuente: ${escapeHTML(impact.source)} · Incertidumbre: ${escapeHTML(impact.uncertainty || "n/d")} · Alcance: ${escapeHTML(impact.scope || "n/d")}.</p>` : ""}
            </div>

            <!-- Bloque Reciclabilidad -->
            <div class="voliuz-dim-card">
              <div class="voliuz-dim-header">
                <div class="voliuz-dim-title-row">
                  <div class="voliuz-dim-title">
                    ${icon("autorenew", "dim-icon accent", 15)}
                    <span>Reciclaje</span>
                  </div>
                  <span class="voliuz-dim-badge ${recLevelClass}">${escapeHTML(impact.recyclability.level)}</span>
                </div>
                <span class="voliuz-dim-subtitle">Potencial del material</span>
              </div>
              <div class="voliuz-recycling-meter">
                ${recSegsHtml}
              </div>
              <p class="voliuz-dim-desc">${escapeHTML(impact.recyclability.description)}</p>
              <p class="voliuz-detail-note">${icon("info", "note-icon", 12)} ${escapeHTML(impact.recyclability.localContextNote || "Reciclabilidad efectiva local no verificada.")}</p>
            </div>
          </div>

          

${renderAlternativeSection(alt)}

${renderChatSection()}






         
<section class="voliuz-actions-section">
  <p class="voliuz-guarantee-note">
    VOLIUZ no altera precios ni el contenido de la publicación. Esta
    extensión solo estima y explica; no procesa compras.
  </p>
  <a class="voliuz-alt-web-cta" href="${VOLIUZ_WEB_URL}" target="_blank" rel="noopener noreferrer" style="margin-top:0;">
    ${icon("eco", "alt-web-icon", 14)}
    <span>Explorar la web de VOLIUZ</span>
    ${icon("open_in_new", "alt-web-external", 12)}
  </a>
</section>


        </div>

        <!-- FOOTER -->
        <footer class="voliuz-footer">
          <div class="voliuz-footer-links">
            <span>VOLIUZ v1.3 · Colombia</span>
            <span class="voliuz-footer-dot"></span>
            <a class="voliuz-methodology-btn" href="${VOLIUZ_WEB_URL}" target="_blank" rel="noopener noreferrer">
              ${icon("open_in_new", "footer-icon", 13)}
              <span>Web de VOLIUZ</span>
            </a>
            <span class="voliuz-footer-dot"></span>
            <button class="voliuz-methodology-btn" id="vz-btn-methodology" type="button">
              ${icon("info", "footer-icon", 13)}
              <span>¿Cómo calculamos este impacto?</span>
            </button>
          </div>
        </footer>

        <!-- MODAL: METODOLOGÍA -->
        <div class="voliuz-modal-backdrop" id="vz-modal-methodology">
          <div class="voliuz-modal-box">
            <div class="voliuz-modal-header">
              <h3 class="voliuz-modal-title">Criterios de la estimación</h3>
              <button class="voliuz-icon-btn" id="vz-modal-close-meth" aria-label="Cerrar metodología">
                ${icon("close", "", 16)}
              </button>
            </div>

<div class="voliuz-modal-content">
  <p>
    <strong>VOLIUZ</strong> realiza una estimación preliminar de cuna a
    puerta usando únicamente la composición porcentual declarada en la
    publicación. No es una medición directa ni una LCA certificada.
  </p>

  <p>
    <strong>1. Fórmula aplicada:</strong>
    Impacto (kg CO₂e) = Σ (peso del material en kg × factor de emisión
    kg CO₂e/kg). El peso se estima con un promedio provisional por
    categoría; no lo declara el fabricante. Solo se modela la etapa de
    materiales: no se incluyen transporte, fabricación, uso, empaque ni
    fin de vida.
  </p>

  <p>
    <strong>2. Factores de emisión:</strong>
    Los factores son parámetros provisionales heredados del prototipo.
    No están trazados a un dataset, versión, unidad funcional ni geografía
    verificables. Cualquier cambio de fuente o de límite del sistema
    modificaría el resultado.
  </p>

  <p>
    <strong>3. Materiales y reciclabilidad:</strong>
    Solo se usan porcentajes explícitos que sumen aproximadamente 100 %.
    Si la composición está incompleta, es inválida o contiene materiales
    sin factor, no se genera una estimación. La reciclabilidad mostrada
    es un potencial del material, no una reciclabilidad efectiva local:
    no se verificó la infraestructura de Colombia.
  </p>

  <p>
    <strong>4. Alternativas:</strong>
    No existe todavía un catálogo verificado de alternativas equivalentes.
    La sección de alternativas enlaza rutas externas (segunda mano, reparación,
    evaluación de marcas, certificaciones y reciclaje) que VOLIUZ no controla
    ni verifica. El directorio de emprendimientos se publica en
    <a href="${VOLIUZ_WEB_URL}" target="_blank" rel="noopener noreferrer">${VOLIUZ_WEB_URL}</a>
    y no se presenta como funcionalidad implementada dentro de la extensión.
  </p>

  <p>
    <strong>Importante:</strong>
    Los valores son estimaciones preliminares y no deben interpretarse
    como certificaciones ambientales ni como reducciones verificadas.
  </p>
</div>

            <div class="voliuz-modal-footer">
              <button class="voliuz-cta-primary" style="padding: 8px 16px; font-size: 12px;" id="vz-modal-btn-ok-meth">Entendido</button>
            </div>
          </div>
        </div>

      </div>
    `;

    bindEvents();
  }

  /**
   * Conecta los eventos interactivos dentro del Shadow DOM.
   * Todas las suscripciones comparten un AbortController para que
   * destroyHUD() pueda desvincularlas en bloque.
   */
  function bindEvents() {
    const scope = shadowRoot.getElementById("voliuz-scope-root");
    if (!scope) return;

    if (eventController) eventController.abort();
    eventController = new AbortController();
    const listenerOptions = { signal: eventController.signal };

    const panel = scope.querySelector("#vz-panel");
    const triggerBtn = scope.querySelector("#vz-trigger-btn");
    const btnClose = scope.querySelector("#vz-btn-close");
    const btnMinimize = scope.querySelector("#vz-btn-minimize");
    const btnTheme = scope.querySelector("#vz-btn-theme");

    const btnMethodology = scope.querySelector("#vz-btn-methodology");
    const btnAiRetry = scope.querySelector("#vz-ai-retry");

    const modalMeth = scope.querySelector("#vz-modal-methodology");
    const modalCloseMeth = scope.querySelector("#vz-modal-close-meth");
    const modalOkMeth = scope.querySelector("#vz-modal-btn-ok-meth");

    
  


    // Minimizar / Cerrar panel
    function hidePanel() {
      isPanelOpen = false;
      panel.classList.remove("open");
      triggerBtn.classList.remove("hidden");
    }

    // Expandir panel
    function showPanel() {
      isPanelOpen = true;
      panel.classList.add("open");
      triggerBtn.classList.add("hidden");
    }

    if (btnClose) btnClose.addEventListener("click", hidePanel, listenerOptions);
    if (btnMinimize) btnMinimize.addEventListener("click", hidePanel, listenerOptions);
    if (triggerBtn) triggerBtn.addEventListener("click", showPanel, listenerOptions);

    // Reintento manual de la inferencia: útil después de guardar la clave
    // en el popup, sin necesidad de recargar la ficha ni la extensión.
    if (btnAiRetry) {
      btnAiRetry.addEventListener(
        "click",
        () => {
          if (!currentProductData) return;
          requestAiComposition(currentProductData, { force: true });
        },
        listenerOptions,
      );
    }

    // Sugerencia de alternativa con IA (comando manual).
    const btnAltRetry = scope.querySelector("#vz-ai-alt-retry");
    if (btnAltRetry) {
      btnAltRetry.addEventListener(
        "click",
        () => {
          if (!currentProductData) return;
          requestAlternativeSuggestion(currentProductData, currentImpactData, {
            force: true,
          });
        },
        listenerOptions,
      );
    }

    // Cambio de tema claro/oscuro (se guarda para todas las pestañas).
    if (btnTheme) {
      btnTheme.addEventListener(
        "click",
        () => {
          currentTheme = currentTheme === "dark" ? "light" : "dark";
          scope.setAttribute("data-theme", currentTheme);
          const label =
            currentTheme === "dark"
              ? "Cambiar a modo claro"
              : "Cambiar a modo oscuro";
          btnTheme.innerHTML = icon(
            currentTheme === "dark" ? "sun" : "moon",
            "",
            16,
          );
          btnTheme.title = label;
          btnTheme.setAttribute("aria-label", label);
          if (
            typeof chrome !== "undefined" &&
            chrome.storage &&
            chrome.storage.local
          ) {
            chrome.storage.local.set({ voliuzTheme: currentTheme });
          }
        },
        listenerOptions,
      );
    }

    // Modal Metodología
    if (btnMethodology && modalMeth) {
      btnMethodology.addEventListener("click", () =>
        modalMeth.classList.add("open"),
        listenerOptions,
      );
    }
    if (modalCloseMeth && modalMeth) {
      modalCloseMeth.addEventListener("click", () =>
        modalMeth.classList.remove("open"),
        listenerOptions,
      );
    }
    if (modalOkMeth && modalMeth) {
      modalOkMeth.addEventListener("click", () =>
        modalMeth.classList.remove("open"),
        listenerOptions,
      );
    }

    // Chat ambiental: envío por formulario, Enter (sin Shift) y sugerencias.
    const chatForm = scope.querySelector("#vz-chat-form");
    const chatInput = scope.querySelector("#vz-chat-input");
    const chatClear = scope.querySelector("#vz-chat-clear");
    const chatSuggestions = scope.querySelector("#vz-chat-suggestions");

    if (chatForm) {
      chatForm.addEventListener(
        "submit",
        (event) => {
          event.preventDefault();
          if (chatInput) sendChatQuestion(chatInput.value);
        },
        listenerOptions,
      );
    }

    if (chatInput) {
      chatInput.addEventListener(
        "keydown",
        (event) => {
          if (event.key !== "Enter" || event.shiftKey || event.isComposing) {
            return;
          }
          event.preventDefault();
          sendChatQuestion(chatInput.value);
        },
        listenerOptions,
      );
    }

    if (chatClear) {
      chatClear.addEventListener(
        "click",
        () => {
          clearChatConversation();
          updateChatUI();
          if (chatInput) chatInput.focus();
        },
        listenerOptions,
      );
    }

    if (chatSuggestions) {
      chatSuggestions.addEventListener(
        "click",
        (event) => {
          const target = event.target;
          const button =
            target && typeof target.closest === "function"
              ? target.closest("[data-chat-suggestion]")
              : null;
          if (!button) return;
          sendChatQuestion(button.getAttribute("data-chat-suggestion") || "");
        },
        listenerOptions,
      );
    }
  }

  /**
   * Ejecuta el análisis telemétrico completo sobre la página
   */
  function runTelemetryAnalysis() {
    if (!extensionEnabled) {
      destroyHUD();
      return false;
    }

    const scraper = getScraper();
    const calculator = getCalculator();
    const recommender = getRecommender();

    if (!scraper || !calculator || !recommender) {
      moduleRetryCount += 1;
      if (moduleRetryCount > MAX_MODULE_RETRIES) {
        console.error("[VOLIUZ] No fue posible cargar los módulos requeridos.");
        destroyHUD();
        return false;
      }
      console.warn("[VOLIUZ] Módulos aún no listos, reintentando...");
      retryTimer = setTimeout(() => {
        retryTimer = null;
        runTelemetryAnalysis();
      }, 300);
      return false;
    }
    moduleRetryCount = 0;

    try {
      // Verificar si es página de producto
      if (!scraper.isProductPage()) {
        console.log(
          "[VOLIUZ] La página actual no es una ficha de producto de Mercado Libre.",
        );
        // No dejar visible el HUD de una ficha anterior (portada, listado, etc.).
        resetAnalysisData();
        extractionRetryCount = 0;
        destroyHUD();
        return false;
      }

      const analysisStartedAt =
        typeof performance !== "undefined" && performance.now
          ? performance.now()
          : Date.now();

      console.log("[VOLIUZ] Ficha de producto detectada. Extrayendo datos...");
      currentProductData = scraper.scrapeProduct(document);

      const extractionStatus =
        currentProductData && currentProductData.extractionStatus;
      const isDetected = Boolean(
        currentProductData && currentProductData.isDetected,
      );
      const canRenderExtractionState =
        extractionStatus === "insufficient" || extractionStatus === "error";

      if (!isDetected && !canRenderExtractionState) {
        if (extractionRetryCount < MAX_EXTRACTION_RETRIES) {
          extractionRetryCount += 1;
          console.warn(
            `[VOLIUZ] La ficha aún no expone datos (reintento ${extractionRetryCount}/${MAX_EXTRACTION_RETRIES}).`,
          );
          resetAnalysisData();
          destroyHUD();
          retryTimer = setTimeout(() => {
            retryTimer = null;
            runTelemetryAnalysis();
          }, 400);
          return false;
        }

        console.warn(
          "[VOLIUZ] No se detectaron datos suficientes del producto en esta vista.",
        );
        resetAnalysisData();
        extractionRetryCount = 0;
        destroyHUD();
        return false;
      }

      // Si la ficha existe pero aún no expone datos (o falló la lectura),
      // se reintenta un número acotado de veces. Al agotarse, se muestra el
      // estado real de extracción en lugar de ocultar el problema.
      if (!isDetected && extractionRetryCount < MAX_EXTRACTION_RETRIES) {
        extractionRetryCount += 1;
        console.warn(
          `[VOLIUZ] Extracción "${extractionStatus}" (reintento ${extractionRetryCount}/${MAX_EXTRACTION_RETRIES}).`,
        );
        resetAnalysisData();
        destroyHUD();
        retryTimer = setTimeout(() => {
          retryTimer = null;
          runTelemetryAnalysis();
        }, 400);
        return false;
      }

      extractionRetryCount = 0;

      // El chat pertenece a una ficha concreta: se reinicia al cambiar de
      // producto, pero se conserva si se reanaliza la misma publicación.
      syncChatProduct(currentProductData);

      // Gemini solo se consulta si la publicación no ofrece una composición
      // declarada utilizable. La respuesta llega de forma asíncrona y nunca
      // bloquea el primer render del HUD.
      const needsInference = !hasUsableDeclaredComposition(currentProductData);
      currentProductData.aiComposition = null;
      currentProductData.aiError = null;
      currentProductData.aiStatus = needsInference ? "loading" : "idle";
      const aiProduct = currentProductData;

      currentImpactData = calculator.calculateImpact(currentProductData);
      currentAlternativeData = recommender.findAlternative(
        currentProductData,
        currentImpactData,
      );

      // Cada render reconstruye el Shadow DOM sobre un host limpio.
      setupShadowDOM();
      renderHUD(currentProductData, currentImpactData, currentAlternativeData);

      // Sin alternativa verificada, solicitar la sugerencia de IA aquí también:
      // el primer render del HUD ocurre sin pasar por renderAIUpdate.
      if (
        currentAlternativeData &&
        currentAlternativeData.hasAlternative !== true &&
        !currentAlternativeData.aiSuggestion
      ) {
        const altTimer = setTimeout(() => {
          if (currentProductData === aiProduct) {
            requestAlternativeSuggestion(aiProduct, currentImpactData);
          }
        }, 300);
        if (altTimer && typeof altTimer.unref === "function") altTimer.unref();
      }

      if (needsInference) {
        const aiTimer = setTimeout(() => {
          if (currentProductData === aiProduct) {
            requestAiComposition(aiProduct);
          }
        }, 300);
        // El temporizador no debe impedir que la página se libere.
        if (aiTimer && typeof aiTimer.unref === "function") aiTimer.unref();
      }

      const analysisEndedAt =
        typeof performance !== "undefined" && performance.now
          ? performance.now()
          : Date.now();
      const renderMs = Math.max(0, Math.round(analysisEndedAt - analysisStartedAt));

      console.log(`[VOLIUZ] HUD renderizado en ${renderMs} ms.`);
      console.log("[VOLIUZ] Análisis completado con éxito:", {
        product: currentProductData,
        impact: currentImpactData,
        alternative: currentAlternativeData,
        renderMs,
      });

      // Notificar al background / storage
      if (
        typeof chrome !== "undefined" &&
        chrome.storage &&
        chrome.storage.local
      ) {
        chrome.storage.local.set({
          voliuzLastAnalysis: {
            product: currentProductData,
            impact: currentImpactData,
            alternative: currentAlternativeData,
            url: window.location.href,
            renderMs,
            timestamp: Date.now(),
          },
        }, () => {
          if (chrome.runtime.lastError) {
            console.warn("[VOLIUZ] No se pudo guardar el último análisis.");
          }
        });
      }
      return true;
    } catch (error) {
      console.error("[VOLIUZ] Error controlado durante el análisis:", error);
      resetAnalysisData();
      extractionRetryCount = 0;
      destroyHUD();
      return false;
    }
  }

  // Escuchar mensajes desde el popup o background
  if (
    typeof chrome !== "undefined" &&
    chrome.runtime &&
    chrome.runtime.onMessage
  ) {
    chrome.runtime.onMessage.addListener((message = {}, sender, sendResponse) => {
      try {
      if (message.action === "toggleHUD") {
        const scope = shadowRoot
          ? shadowRoot.getElementById("voliuz-scope-root")
          : null;
        if (scope) {
          const panel = scope.querySelector("#vz-panel");
          const trigger = scope.querySelector("#vz-trigger-btn");
          if (panel) {
            if (panel.classList.contains("open")) {
              panel.classList.remove("open");
              if (trigger) trigger.classList.remove("hidden");
              isPanelOpen = false;
            } else {
              panel.classList.add("open");
              if (trigger) trigger.classList.add("hidden");
              isPanelOpen = true;
            }
          }
        }
        sendResponse({ success: true, isPanelOpen });
      } else if (message.action === "reanalyze") {
        sendResponse({ success: runTelemetryAnalysis() });
      } else if (message.action === "setEnabled") {
        extensionEnabled = message.enabled !== false;
        clearScheduledWork();

        if (!extensionEnabled) {
          resetAnalysisData();
          destroyHUD();
          sendResponse({ success: true });
        } else {
          isPanelOpen = true;
          extractionRetryCount = 0;
          sendResponse({ success: runTelemetryAnalysis() });
        }
        return false;
      } else if (message.action === "getStatus") {
        sendResponse({
          hasAnalysis: !!currentProductData,
          product: currentProductData,
          impact: currentImpactData,
          alternative: currentAlternativeData,
          isPanelOpen,
        });
      } else {
        sendResponse({ success: false, error: "Acción no compatible." });
      }
      } catch (error) {
        console.error("[VOLIUZ] Error al procesar un mensaje:", error);
        sendResponse({ success: false, error: "No fue posible procesar la solicitud." });
      }
      return false;
    });
  }

  // Ejecución inicial tras carga del DOM
  function startIfEnabled() {
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get(["extensionEnabled", "voliuzTheme"], (stored) => {
        if (chrome.runtime.lastError) {
          console.warn("[VOLIUZ] No se pudo leer el estado de la extensión.");
          return;
        }
        extensionEnabled = stored.extensionEnabled !== false;
        currentTheme = stored.voliuzTheme === "dark" ? "dark" : "light";
        if (extensionEnabled) scheduleAnalysis(INITIAL_ANALYSIS_DELAY);
      });
    } else {
      scheduleAnalysis(INITIAL_ANALYSIS_DELAY);
    }
  }

  // Mantiene el HUD sincronizado si el tema cambia desde el popup u otra pestaña.
  if (
    typeof chrome !== "undefined" &&
    chrome.storage &&
    chrome.storage.onChanged
  ) {
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName !== "local" || !changes.voliuzTheme) return;
      currentTheme = changes.voliuzTheme.newValue === "dark" ? "dark" : "light";
      const scope = shadowRoot
        ? shadowRoot.getElementById("voliuz-scope-root")
        : null;
      if (!scope) return;
      scope.setAttribute("data-theme", currentTheme);
      const btnTheme = scope.querySelector("#vz-btn-theme");
      if (!btnTheme) return;
      const label =
        currentTheme === "dark" ? "Cambiar a modo claro" : "Cambiar a modo oscuro";
      btnTheme.innerHTML = icon(currentTheme === "dark" ? "sun" : "moon", "", 16);
      btnTheme.title = label;
      btnTheme.setAttribute("aria-label", label);
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", startIfEnabled, { once: true });
  } else {
    startIfEnabled();
  }

  /**
   * Gestiona una transición de la SPA de Mercado Libre.
   *
   * Mercado Libre no emite un evento propio de cambio de ruta y su
   * historial no es interceptable desde el mundo aislado del content
   * script. Por eso se observa el DOM (que se actualiza junto con la URL)
   * y se cubren además popstate/hashchange para atrás/adelante.
   */
  function handleUrlChange() {
    const url = window.location.href;
    if (url === lastUrl) return;

    // Solo los cambios de ruta implican otra publicación; ignorar
    // query strings de tracking y anclas sobre la misma ficha.
    const previousPath = lastUrl.split(/[?#]/)[0];
    const currentPath = url.split(/[?#]/)[0];
    lastUrl = url;

    if (currentPath === previousPath) return;

    console.log("[VOLIUZ] Navegación SPA detectada:", url);

    // 1. Detener cualquier análisis pendiente de la ruta anterior.
    clearScheduledWork();

    // 2. Destruir el HUD anterior y liberar su Shadow DOM y listeners.
    destroyHUD();
    resetAnalysisData();
    extractionRetryCount = 0;
    isPanelOpen = true;

    if (!extensionEnabled) return;

    // 3. Re-ejecutar scraper -> co2Calculator -> recommender -> renderHUD.
    scheduleAnalysis(SPA_SETTLE_DELAY);
  }

  // El callback solo compara cadenas, por lo que observar todo el árbol
  // tiene un costo despreciable frente al render de la SPA.
  const spaObserver = new MutationObserver(handleUrlChange);
  spaObserver.observe(document.documentElement || document, {
    subtree: true,
    childList: true,
  });

  window.addEventListener("popstate", handleUrlChange);
  window.addEventListener("hashchange", handleUrlChange);
})();
