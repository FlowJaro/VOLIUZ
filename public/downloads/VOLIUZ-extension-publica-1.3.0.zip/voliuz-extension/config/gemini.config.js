self.VOLIUZ_GEMINI_CONFIG = Object.freeze({ apiKey: "", model: "gemini-3.6-flash", useImage: false, backendUrl: "" });
