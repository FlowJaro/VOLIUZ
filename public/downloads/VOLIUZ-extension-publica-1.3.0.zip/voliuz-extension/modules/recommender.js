
/**
 * VOLIUZ - Motor de Recomendación Verde
 *
 * Principio metodológico:
 * No recomendar productos ficticios ni afirmar reducciones
 * ambientales sin datos comparables y verificables.
 *
 * La conexión con el catálogo de emprendimientos corresponde
 * a la Fase 2 de VOLIUZ. Este módulo no simula que ese catálogo
 * ya se encuentra implementado.
 *
 * Lo que sí ofrece hoy son rutas externas de búsqueda y sustitución:
 * plataformas de segunda mano, guías de reparación, evaluaciones de
 * marcas y directorios de certificación o economía circular. Son enlaces
 * a organizaciones reales; no son productos verificados por VOLIUZ ni
 * implican una reducción ambiental cuantificada.
 */

(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.VoliuzRecommender = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  /**
   * Web pública de VOLIUZ (Fase 2). Se usa como destino del logo y
   * como plataforma donde se publicará el directorio de emprendimientos.
   */
  const VOLIUZ_WEB_URL = 'https://voliuz-puce.vercel.app/';

  /**
   * Catálogo de alternativas verificadas.
   *
   * Se mantiene vacío hasta contar con productos reales,
   * fuentes consultables y datos ambientales comparables.
   *
   * No agregar productos de ejemplo como si fueran reales.
   */
  const SUSTAINABLE_CATALOG = [];

  /**
   * Rutas externas de búsqueda y sustitución.
   *
   * `matches` limita la ruta a categorías/materiales donde tiene sentido.
   * `always` la muestra para cualquier producto.
   * Todas las URL son de organizaciones o plataformas reales y se abren
   * fuera de la extensión; VOLIUZ no controla su contenido.
   */
  const EXTERNAL_ROUTES = [
    {
      id: 'second_hand',
      label: 'Segunda mano',
      description:
        'Buscar una unidad usada del mismo producto antes de comprar una nueva. La reducción de impacto no se cuantifica aquí porque depende del estado y del uso previo.',
      source: 'Mercado Libre Colombia',
      always: true,
      buildUrl: (query) =>
        `https://listado.mercadolibre.com.co/${slugify(query) || 'productos'}`,
      note: 'En los resultados, aplicar el filtro de condición "Usado".'
    },
    {
      id: 'brand_ratings',
      label: 'Evaluación de marcas',
      description:
        'Consultar evaluaciones independientes de marcas de moda según trabajo, medio ambiente y bienestar animal.',
      source: 'Good On You',
      url: 'https://www.goodonyou.eco/',
      matches: /moda|ropa|textil|calzado|accesorio|bolso|fashion|apparel|buzo|hoodie|camis|pantal|vestido|chaqueta|sudadera|jean|blusa|deporte/i
    },
    {
      id: 'fashion_transparency',
      label: 'Transparencia de la cadena',
      description:
        'Revisar el índice de transparencia de marcas de moda y sus políticas públicas sobre materiales y derechos laborales.',
      source: 'Fashion Revolution',
      url: 'https://www.fashionrevolution.org/',
      matches: /moda|ropa|textil|calzado|accesorio|bolso|fashion|apparel|buzo|hoodie|camis|pantal|vestido|chaqueta|sudadera|jean|blusa|deporte/i
    },
    {
      id: 'certified_textiles',
      label: 'Textiles certificados',
      description:
        'Buscar prendas con certificación de fibra orgánica y verificar el certificado en el directorio oficial de proveedores.',
      source: 'Global Organic Textile Standard (GOTS)',
      url: 'https://global-standard.org/',
      matches: /algod|textil|ropa|moda|organico|orgánico|buzo|hoodie|camis|pantal|vestido|chaqueta|sudadera|jean|blusa/i
    },
    {
      id: 'recycled_materials',
      label: 'Materiales reciclados',
      description:
        'Consultar estándares de contenido reciclado y proveedores de fibras recicladas verificadas.',
      source: 'Textile Exchange',
      url: 'https://textileexchange.org/',
      matches: /poliester|poliéster|rpet|nailon|poliamida|textil|ropa|moda/i
    },
    {
      id: 'certified_wood',
      label: 'Madera y papel certificados',
      description:
        'Verificar certificaciones forestales del empaque o de la estructura del producto.',
      source: 'Forest Stewardship Council (FSC)',
      url: 'https://fsc.org/',
      matches: /madera|mueble|carton|cartón|papel|celulosa|empaque/i
    },
    {
      id: 'repair',
      label: 'Reparación y repuestos',
      description:
        'Si el producto aún funciona o falla parcialmente, revisar guías de reparación y disponibilidad de repuestos antes de reemplazarlo.',
      source: 'iFixit',
      url: 'https://www.ifixit.com/',
      always: true
    },
    {
      id: 'circular_recycling',
      label: 'Reciclaje en Colombia',
      description:
        'Consultar iniciativas de reciclaje y economía circular disponibles en Colombia y sus puntos de recolección.',
      source: 'CEMPRE Colombia',
      url: 'https://cempre.org.co/',
      always: true
    },
    {
      id: 'circular_economy',
      label: 'Diseño circular',
      description:
        'Revisar criterios de diseño circular, durabilidad, reparabilidad y reciclabilidad aplicables al producto.',
      source: 'Ellen MacArthur Foundation',
      url: 'https://ellenmacarthurfoundation.org/',
      always: true
    }
  ];

  /**
   * Máximo de rutas por producto para no saturar el HUD.
   */
  const MAX_ROUTES = 4;

  /**
   * Ideas de sustitución por tipo de material.
   *
   * Son criterios generales de sustitución, no afirmaciones de que el
   * producto alternativo exista ni de cuánto reduce la huella.
   */
  const MATERIAL_SWAP_STRATEGIES = {
    polyester:
      'Buscar poliéster reciclado (rPET) con certificación de contenido reciclado o prendas monomaterial.',
    polyester_recycled: 'Confirmar el porcentaje de contenido reciclado declarado.',
    polyamide:
      'Buscar poliamida reciclada o prendas monomaterial que faciliten el reciclaje.',
    acrylic:
      'Preferir mezclas con mayor proporción de fibras naturales o recicladas verificadas.',
    elastane:
      'Las mezclas con elastano dificultan el reciclaje: preferir prendas sin elastano o con bajo porcentaje.',
    polyurethane:
      'Buscar sustitutos de cuero con certificación ambiental verificable.',
    cotton_conventional:
      'Buscar algodón orgánico certificado (GOTS) o algodón reciclado.',
    cotton:
      'Buscar algodón orgánico certificado (GOTS) o algodón reciclado.',
    wool:
      'Buscar lana reciclada o con certificación de bienestar animal.',
    viscose:
      'Buscar viscosa de fuentes certificadas (FSC) o lino de bajo insumo.',
    linen: 'Verificar origen y certificación de la fibra.',
    leather_animal:
      'Buscar cuero con certificación de curtido responsable; la sustitución por sintético no siempre reduce el impacto.',
    aluminum_virgin: 'Buscar aluminio reciclado y piezas reemplazables.',
    aluminum_recycled: 'Confirmar el contenido reciclado declarado.',
    plastic_abs:
      'Buscar plásticos reciclados o equipos con piezas y baterías reemplazables.',
    glass: 'Preferir envases retornables o vidrio reciclado.',
    cardboard: 'Preferir cartón reciclado y certificado (FSC Recycled).',
    rubber: 'Buscar caucho reciclado y suelas reparables.'
  };

  /**
   * Convierte un texto en un segmento válido para una URL de búsqueda.
   */
  function slugify(value) {
    return String(value || '')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '')
      .slice(0, 80);
  }

  /**
   * Construye el contexto de búsqueda a partir del producto y su impacto.
   */
  function buildRouteContext(productData = {}, currentImpact = {}) {
    const materials = Array.isArray(currentImpact.materials)
      ? currentImpact.materials
      : [];

    const materialNames = materials
      .map((material) => material && material.name)
      .filter((name) => typeof name === 'string' && name.trim() !== '');

    const rawKeys = materials
      .map((material) => material && material.rawKey)
      .filter((key) => typeof key === 'string' && key.trim() !== '');

    const title = String(productData.title || '').trim();
    const category = String(productData.category || '').trim();
    const query = category || title;

    return {
      title,
      category,
      query,
      materialNames,
      rawKeys,
      haystack: [title, category, materialNames.join(' '), rawKeys.join(' ')]
        .join(' ')
        .toLowerCase()
    };
  }

  /**
   * Devuelve las rutas externas aplicables al producto, sin repetir y
   * con un máximo de MAX_ROUTES.
   */
  function getSustainableRoutes(productData = {}, currentImpact = {}) {
    const context = buildRouteContext(productData, currentImpact);

    const routes = EXTERNAL_ROUTES.filter((route) => {
      if (route.always) return true;
      return route.matches ? route.matches.test(context.haystack) : false;
    });

    return routes.slice(0, MAX_ROUTES).map((route) => ({
      id: route.id,
      label: route.label,
      description: route.description,
      source: route.source,
      note: route.note || '',
      url:
        typeof route.buildUrl === 'function'
          ? route.buildUrl(context.query)
          : route.url
    }));
  }

  /**
   * Devuelve ideas de sustitución de materiales para el producto actual.
   */
  function getMaterialStrategies(productData = {}, currentImpact = {}, limit = 3) {
    const context = buildRouteContext(productData, currentImpact);
    const strategies = [];

    context.rawKeys.forEach((key) => {
      const strategy = MATERIAL_SWAP_STRATEGIES[key];
      if (strategy && !strategies.includes(strategy)) strategies.push(strategy);
    });

    return strategies.slice(0, Math.max(0, Number(limit) || 0));
  }

  /**
   * Estructura uniforme cuando no existe una alternativa
   * real que pueda recomendarse.
   *
   * Se conservan las propiedades esperadas por content.js
   * para evitar errores mientras adaptamos la interfaz.
   */
  function createUnavailableAlternative(reason, extras = {}) {
    return {
      hasAlternative: false,
      status: 'no_verified_alternative',

      title: 'Alternativa no disponible',
      brand: '',
      origin: '',
      materialsSummary: 'Información no disponible',
      co2e: null,
      formattedCO2e: 'No disponible',
      price: 'No disponible',
      currency: '',
      certification: 'No verificada',
      image: '',
      pymeProfileUrl: '',
      description: reason,

      co2Saved: null,
      formattedCO2Saved: 'No disponible',
      reductionPercent: null,
      reductionLabel: 'No calculable',
      badgeLabel: 'Sin alternativa verificada',

      // Rutas externas e ideas de sustitución: no son alternativas
      // verificadas ni implican una reducción cuantificada.
      routes: Array.isArray(extras.routes) ? extras.routes : [],
      strategies: Array.isArray(extras.strategies) ? extras.strategies : [],
      webUrl: VOLIUZ_WEB_URL,
      webLabel: 'Explorar la web de VOLIUZ',

      comparisonAvailable: false,
      verificationStatus: 'pending'
    };
  }

  /**
   * Comprueba si un registro contiene los datos mínimos
   * para considerarse una alternativa verificable.
   *
   * La existencia de estos campos no certifica por sí sola
   * que la información sea verdadera: requiere revisión
   * documental antes de incorporar el producto al catálogo.
   */
  function isValidAlternative(item) {
    if (!item || typeof item !== 'object') return false;

    const requiredFields = [
      'title',
      'brand',
      'category',
      'materialsSummary',
      'sourceUrl',
      'verificationStatus'
    ];

    const hasRequiredFields = requiredFields.every(field =>
      typeof item[field] === 'string' && item[field].trim() !== ''
    );

    return (
      hasRequiredFields &&
      item.verificationStatus === 'verified' &&
      /^https?:\/\//i.test(item.sourceUrl)
    );
  }

  /**
   * Busca una alternativa equivalente dentro del catálogo y, en todos
   * los casos, devuelve rutas externas e ideas de sustitución.
   *
   * Actualmente no hay registros verificados, por lo que el resultado
   * será "no disponible".
   *
   * No se inventan huellas, precios, marcas ni reducciones.
   */
  function findAlternative(productData = {}, currentImpact = {}) {
    const title = String(productData.title || '').trim();
    const category = String(productData.category || '').trim();

    const routes = getSustainableRoutes(productData, currentImpact);
    const strategies = getMaterialStrategies(productData, currentImpact);

    if (!title && !category) {
      return createUnavailableAlternative(
        'No se pudo identificar el producto original para buscar una alternativa equivalente en el catálogo verificado.',
        { routes, strategies }
      );
    }

    if (
      !currentImpact ||
      currentImpact.available !== true ||
      typeof currentImpact.co2e !== 'number' ||
      !Number.isFinite(currentImpact.co2e)
    ) {
      return createUnavailableAlternative(
        'No se puede comparar el impacto ambiental porque la huella del producto original no está disponible. El catálogo de alternativas sigue sin registros verificados.',
        { routes, strategies }
      );
    }

    const candidates = SUSTAINABLE_CATALOG.filter(item => {
      return (
        isValidAlternative(item) &&
        item.category.toLowerCase() === category.toLowerCase()
      );
    });

    if (candidates.length === 0) {
      return createUnavailableAlternative(
        'Aún no hay productos equivalentes verificados en el catálogo de VOLIUZ para esta categoría.',
        { routes, strategies }
      );
    }

    // No seleccionar automáticamente el primer producto:
    // la equivalencia y la comparabilidad requieren revisión.
    return createUnavailableAlternative(
      'Se encontraron registros que requieren una evaluación de equivalencia y comparabilidad antes de recomendarse.',
      { routes, strategies }
    );
  }

  return {
    findAlternative,
    isValidAlternative,
    getSustainableRoutes,
    getMaterialStrategies,
    VOLIUZ_WEB_URL,
    SUSTAINABLE_CATALOG
  };
});
